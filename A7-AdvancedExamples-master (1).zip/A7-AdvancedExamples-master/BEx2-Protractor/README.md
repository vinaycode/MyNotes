# Protractor Tutorial

This project is for demonstration protractor basic tests for application with
"authentication" behavior.

For creating application with authentication behavior tutorial please look
[here](http://jasonwatmore.com/post/2016/08/16/angular-2-jwt-authentication-example-tutorial)

Comments or issues are wellcomed

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app
will automatically reload if you change any of the source files.

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via
[Protractor](http://www.protractortest.org/).
