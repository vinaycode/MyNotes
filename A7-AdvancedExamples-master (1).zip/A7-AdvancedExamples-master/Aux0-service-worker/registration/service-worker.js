// This service worker doesn't actually do anything!
