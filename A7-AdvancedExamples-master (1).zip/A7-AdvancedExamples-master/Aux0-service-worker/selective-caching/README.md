Service Worker Sample: Selective Caching
===
See https://googlechrome.github.io/samples/service-worker/selective-caching/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
