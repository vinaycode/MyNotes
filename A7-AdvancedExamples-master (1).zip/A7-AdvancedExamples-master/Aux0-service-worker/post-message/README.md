Service Worker Sample: Posting Messages
===
See https://googlechrome.github.io/samples/service-worker/post-message/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
