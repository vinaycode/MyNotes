Foreign Fetch Service Worker Sample
===========================
See https://googlechrome.github.io/samples/service-worker/foreign-fetch/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5684130679357440
