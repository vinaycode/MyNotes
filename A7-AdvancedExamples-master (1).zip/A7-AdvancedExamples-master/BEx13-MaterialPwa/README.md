# Creating Beautiful Apps with Angular Material

Learn how to take advantage of Angular Material to create beautiful and modern Angular applications. You will start from scratch, installing Node.js and Angular CLI (in case you don't have them yet), then you will install and configure the dependencies needed to develop with Angular Material.

---

[Read more](https://auth0.com/blog/creating-beautiful-apps-with-angular-material/)
