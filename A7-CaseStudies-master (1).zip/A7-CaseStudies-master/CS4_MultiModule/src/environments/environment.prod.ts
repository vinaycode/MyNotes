export const environment = {
  production: true,
  apiBasePath: 'localhost:4201'
};
