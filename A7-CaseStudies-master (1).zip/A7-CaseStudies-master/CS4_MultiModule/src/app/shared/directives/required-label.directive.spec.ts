import { RequiredLabelDirective } from './required-label.directive';

describe('RequiredLabelDirective', () => {
    
});
