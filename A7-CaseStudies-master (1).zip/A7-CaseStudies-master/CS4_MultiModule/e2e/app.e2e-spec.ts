import { AppPage } from './app.po';

describe('angular6-starter-multi-module App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });
});
