export const environment = {
  production: true,
  version: "1.2 PROD",
  car_info_api_url: "https://www.carqueryapi.com/api/0.3/?callback=?&",
  main_api_url: "http://localhost:9000",
  vapid_public_key: "PUT_HERE_YOUR_PUBLIC_KEY"
};
