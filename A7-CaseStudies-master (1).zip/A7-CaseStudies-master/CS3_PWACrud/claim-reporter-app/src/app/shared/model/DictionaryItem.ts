export interface DictionaryItem {
  code: string;
  name: string;
}
