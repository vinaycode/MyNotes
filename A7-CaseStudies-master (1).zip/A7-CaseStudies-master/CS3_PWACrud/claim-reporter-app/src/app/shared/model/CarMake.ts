export interface CarMake {
  make_id: string;
  make_display: string;
  make_is_common: string;
  make_country: string;
}
