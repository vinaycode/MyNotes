export class Reporter {
  firstName: string;
  lastName: string;
  birthdate: string;
}

