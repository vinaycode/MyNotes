import {Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
    selector: 'app-header',
    templateUrl: './app.component.html'
})

export default class HeaderComponent {

}