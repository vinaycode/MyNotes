export interface LoaderState {
 loaded: boolean;
}