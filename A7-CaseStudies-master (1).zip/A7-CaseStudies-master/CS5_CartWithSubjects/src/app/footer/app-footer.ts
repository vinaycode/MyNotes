import { Component } from '@angular/core';

@Component({
    selector: 'app-footer',
    templateUrl: './app.component.html'
})

export default class FooterComponent {

}