import { product } from './../product';

export interface CartState {
 loaded: boolean;
 products : product[];

}