package com.telefonica.prepaid.frontend.customercare.v24.converter;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.newArrayListWithCapacity;
import static com.telefonica.prepaid.common.util.ValueObjectUtil.getValueOrNull;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.ACTIVATION_FAILED;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.ACTIVATION_IN_PROGRESS;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.ACTIVATION_SUCCESSFUL;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.ORDERED;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.ORDERING_FAILED;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.SHIPMENT_RETURNED;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.SHIPPED;
import static com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum.SHIPPING_FAILED;
import static com.telefonica.prepaid.frontend.customercare.v24.converter.ConfigResponseConverterV24.convertSelectedOptionsVo;
import static java.util.Collections.emptyList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CustomerDataSepaInfoVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ExportAccountContactHistoryResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetChurnCustomerDataResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDSSEntryResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetHandsetDelockDataResponseVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetLastKnownQoSInformationResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPreferredCommunicationChannelResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMInfoResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetTariffChangeHistoryResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.HandsetDelockDataVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.PrepaidITCustomerCareServicesWithAddressResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ProductActionResultVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.QueryCustomerResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.QueryCustomerVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.RegistrationActionResultVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SimValidationResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.TariffInfoVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.TchiboAdditionalInfoVO;
import com.telefonica.prepaid.common.CustomerCareClient;
import com.telefonica.prepaid.common.ProductId;
import com.telefonica.prepaid.common.errorhandling.Reject;
import com.telefonica.prepaid.common.util.DateUtil;
import com.telefonica.prepaid.common.util.ListUtils;
import com.telefonica.prepaid.common.util.ValueObjectUtil;
import com.telefonica.prepaid.communication.permissions.domain.CustomerDneCategoryVo;
import com.telefonica.prepaid.communication.permissions.domain.CustomerDneVo;
import com.telefonica.prepaid.communication.permissions.domain.DneScope;
import com.telefonica.prepaid.crmorder.domain.ShippingAddressVo;
import com.telefonica.prepaid.customer.identification.CustomerCareIdVerificationStatus;
import com.telefonica.prepaid.customer.identification.IdAddressDataVo;
import com.telefonica.prepaid.customer.identification.IdDocumentVo;
import com.telefonica.prepaid.customer.identification.IdVerificationDocumentType;
import com.telefonica.prepaid.customer.identification.IdVerificationReferenceNumber;
import com.telefonica.prepaid.customer.master.CallStorePermission;
import com.telefonica.prepaid.customer.master.domain.AddressDataVo;
import com.telefonica.prepaid.customer.master.domain.CustomerDataVo;
import com.telefonica.prepaid.customer.master.domain.PersonalDataVo;
import com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants;
import com.telefonica.prepaid.customercare.v24.service.domain.AccountContactTypeEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateContractResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateDSSEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateReplacementSimResult;
import com.telefonica.prepaid.customercare.v24.service.domain.AddressData;
import com.telefonica.prepaid.customercare.v24.service.domain.AddressList;
import com.telefonica.prepaid.customercare.v24.service.domain.AddressResult;
import com.telefonica.prepaid.customercare.v24.service.domain.BankAccountCustomerData;
import com.telefonica.prepaid.customercare.v24.service.domain.BankAccountDataForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.BillTypeEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeBankAccountResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCustomerCommChannelResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeSIMInfo;
import com.telefonica.prepaid.customercare.v24.service.domain.ChurnCustomerData;
import com.telefonica.prepaid.customercare.v24.service.domain.ChurnStatusEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.ConfirmSepaMandateResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CreateCrmOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CreditCardData;
import com.telefonica.prepaid.customercare.v24.service.domain.CreditCardDataWithRegistrationState;
import com.telefonica.prepaid.customercare.v24.service.domain.CreditCardRegistrationStatusEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.CrmShippingAddress;
import com.telefonica.prepaid.customercare.v24.service.domain.CustomerAgreementFlags;
import com.telefonica.prepaid.customercare.v24.service.domain.CustomerAgreementFlagsCategory;
import com.telefonica.prepaid.customercare.v24.service.domain.CustomerAgreementReminder;
import com.telefonica.prepaid.customercare.v24.service.domain.CustomerData;
import com.telefonica.prepaid.customercare.v24.service.domain.DSSEntry;
import com.telefonica.prepaid.customercare.v24.service.domain.DSSRequestStatusEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DSSResponseStatusEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DSSUsageEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DataCheckQualityEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DeactivateDSSEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.DeregisterPaymentMethodResult;
import com.telefonica.prepaid.customercare.v24.service.domain.DirectDebitRegistrationStateEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DisallowedReasonEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DisallowedUseCaseElement;
import com.telefonica.prepaid.customercare.v24.service.domain.DisallowedUseCaseEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.DisallowedUseCasesList;
import com.telefonica.prepaid.customercare.v24.service.domain.EGNData;
import com.telefonica.prepaid.customercare.v24.service.domain.EgnDataCategoryEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.EmailAddressWithValidation;
import com.telefonica.prepaid.customercare.v24.service.domain.EmailVerificationStatusEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.EvnDataForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.EvnRecordForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.FetchCustomerHistoryEntriesResult;
import com.telefonica.prepaid.customercare.v24.service.domain.FixedBillCycle;
import com.telefonica.prepaid.customercare.v24.service.domain.FskLevelEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.GenderEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.GetChurnCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCustomerDataForDataPortabilityResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetDSSEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetEGNDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetHandsetDelockDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetKittedProductsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetLastKnownQoSInformationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetNonEECCRelevantProductsForBrandResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPreContractualInformationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPreferredCommunicationChannelResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMHistoryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMInfoResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMStatisticsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetTariffChangeHistoryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetTopUpsAndChargesResult;
import com.telefonica.prepaid.customercare.v24.service.domain.HandsetDelockData;
import com.telefonica.prepaid.customercare.v24.service.domain.HistoryRecord;
import com.telefonica.prepaid.customercare.v24.service.domain.IdAddressData;
import com.telefonica.prepaid.customercare.v24.service.domain.IdDocumentForReading;
import com.telefonica.prepaid.customercare.v24.service.domain.IdDocumentTypeIncludingUnknown;
import com.telefonica.prepaid.customercare.v24.service.domain.IdvFraudStatus;
import com.telefonica.prepaid.customercare.v24.service.domain.IdvReferenceNumber;
import com.telefonica.prepaid.customercare.v24.service.domain.LifeCycleStateEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.MasterDataForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.ModifyRegistrationDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.NotifyAboutSuccessfulReverificationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.PKKTypeEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.PackServiceTypeEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.PackSubscriptionForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.PackSubscriptionsForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.PaymentMethodDirectDebit;
import com.telefonica.prepaid.customercare.v24.service.domain.PermitsCallStoreEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.PersonalData;
import com.telefonica.prepaid.customercare.v24.service.domain.PreferredCommunicationChannelEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.ProductActionResult;
import com.telefonica.prepaid.customercare.v24.service.domain.QoSInformation;
import com.telefonica.prepaid.customercare.v24.service.domain.QueryCustomerData;
import com.telefonica.prepaid.customercare.v24.service.domain.RegisterDirectDebitActionResult;
import com.telefonica.prepaid.customercare.v24.service.domain.RegistrationActionResult;
import com.telefonica.prepaid.customercare.v24.service.domain.RequestEmailAddressPerSmsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ResetRegistrationDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ResultCodeEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.SIMInfo;
import com.telefonica.prepaid.customercare.v24.service.domain.SearchCustomersResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ShipSimActionResult;
import com.telefonica.prepaid.customercare.v24.service.domain.SimChangeStatusEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.SimReplacementReason;
import com.telefonica.prepaid.customercare.v24.service.domain.StoreCustomerHistoryEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.TariffHistory;
import com.telefonica.prepaid.customercare.v24.service.domain.TariffInfo;
import com.telefonica.prepaid.customercare.v24.service.domain.TchiboAdditionalInfo;
import com.telefonica.prepaid.customercare.v24.service.domain.ThirdPartyBankAccountOwner;
import com.telefonica.prepaid.customercare.v24.service.domain.TitleEnum;
import com.telefonica.prepaid.customercare.v24.service.domain.TopUpDataForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.TopUpRecordForDataPortability;
import com.telefonica.prepaid.customercare.v24.service.domain.Transaction;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdateFrontendRegistrationDateResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ValidateCrmOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ValidateSimResult;
import com.telefonica.prepaid.customerchecking.bankdata.LegacyBankDataVo;
import com.telefonica.prepaid.directdebit.domain.ThirdPartyBankAccountOwnerVo;
import com.telefonica.prepaid.domain.billing.BillType;
import com.telefonica.prepaid.domain.churn.ChurnDataVO;
import com.telefonica.prepaid.domain.common.Channel;
import com.telefonica.prepaid.domain.common.ContractStatus;
import com.telefonica.prepaid.domain.common.DirectDebitStatus;
import com.telefonica.prepaid.domain.common.RequestReasonType;
import com.telefonica.prepaid.domain.common.SimChangeStatus;
import com.telefonica.prepaid.domain.directdebit.DirectDebitBankAccountVo;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.response.DisallowedUseCaseElementVo;
import com.telefonica.prepaid.enums.EventContactType;
import com.telefonica.prepaid.external.customercare.converter.CustomerCareConverter;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesResponseVo;
import com.telefonica.prepaid.external.customercare.domain.QoSInformationVo;
import com.telefonica.prepaid.external.customercare.v24.converter.CustomerCareResponseConverterV24;
import com.telefonica.prepaid.external.lapi.domain.TitleForLapi;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.ChangeSimInfoVo;
import com.telefonica.prepaid.frontend.customercare.domain.CustomerCareServicesResponseWithAvailabilityVo;
import com.telefonica.prepaid.frontend.customercare.domain.CustomerCareUseCase;
import com.telefonica.prepaid.frontend.customercare.domain.DataCheckQuality;
import com.telefonica.prepaid.frontend.customercare.domain.DneReminderVo;
import com.telefonica.prepaid.frontend.customercare.domain.EmailVerificationStatusVo;
import com.telefonica.prepaid.frontend.customercare.domain.EvnRecordVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCustomerDataForDataPortabilityResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetEgnDataResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetKittedProductsResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetNonEECCRelevantProductsForBrandResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetPreContractualInformationResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetSimHistoryResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetSimStatisticsResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetTopUpsResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.PackSubscriptionForDataPortabilityVo;
import com.telefonica.prepaid.frontend.customercare.domain.RegisterDirectDebitActionResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.RequestEmailAddressPerSmsResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.ShipSimActionResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.TopUpRecordForDataPortabilityVo;
import com.telefonica.prepaid.frontend.customercare.response.GetCustomerDataResponseVo;
import com.telefonica.prepaid.interfaces.dss.DssResult;
import com.telefonica.prepaid.payment.creditcard.domain.CreditCardDataVo;
import com.telefonica.prepaid.payment.creditcard.domain.CreditCardProvider;
import com.telefonica.prepaid.payment.creditcard.domain.CreditCardRegistrationStatus;
import com.telefonica.prepaid.payment.domain.FixedBillCycleVo;
import com.telefonica.prepaid.payment.domain.PaymentMethod;
import com.telefonica.prepaid.payment.domain.PaymentMethodInfoVo;
import com.telefonica.prepaid.usage.TopUpDataVo;
import com.telefonica.prepaid.usage.domain.EgnDataCategory;
import com.telefonica.prepaid.usage.service.EGNDataUtils;
import com.telefonica.prepaid.usage.service.EgnDataVo;

import de.danet.ta.prepaid.common.applicationserver.common.valueobjects.ContactVO;
import de.danet.ta.prepaid.daogen.vendor.dto.Salutation;
import de.danet.tariffmanager.valueobjects.TariffChangeHistoryEntryVO;

public class CustomerResponseConverterV24 extends CustomerCareResponseConverterV24 {
    private static final Logger log = Logger.getLogger( CustomerResponseConverterV24.class );

    private static final Set<CustomerCareUseCase> SUPPORTED_USECASES = ImmutableSet.of(
        CustomerCareUseCase.REGISTER_FOR_DIRECT_DEBIT, CustomerCareUseCase.CHANGE_BANK_ACCOUNT,
        CustomerCareUseCase.CHANGE_RECHARGE_OPTIONS, CustomerCareUseCase.TOP_UP_ON_DEMAND,
        CustomerCareUseCase.CHANGE_CUSTOMER_DATA, CustomerCareUseCase.SIM_REPLACEMENT,
        CustomerCareUseCase.REGISTER_CREDIT_CARD, CustomerCareUseCase.RESET_REGISTRATION );

    private static final int MAX_ADDRESS_PART_LENGTH = 32;

    public ValidateSimResult convertValidateSimResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        ValidateSimResult simValidationResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO,
            new ValidateSimResult() );

        if( prepaidServicesResponseVO instanceof SimValidationResponseVO ) {
            SimValidationResponseVO resultVO = (SimValidationResponseVO) prepaidServicesResponseVO;

            simValidationResult.setTariffInfo( convertTariffInfo( resultVO.getTariffInfoVo() ) );
            simValidationResult
                .setIdvReferenceNumber( convertIdVerificationReferenceNumber( resultVO.getIdVerificationReferenceNumber() ) );
        }
        return simValidationResult;
    }

    public ChangeCustomerDataResult convertChangeCustomerDataResponse( CustomerCareServicesResponseVo response ) {
        ChangeCustomerDataResult result = fillPPITCustomerCareServicesResponse( response, new ChangeCustomerDataResult() );

        if( response instanceof PrepaidITCustomerCareServicesWithAddressResponseVO ) {
            result.setAddressCheckResult( convertAddressCheckResult( (PrepaidITCustomerCareServicesWithAddressResponseVO) response ) );
        }
        return result;
    }

    public StoreCustomerHistoryEntryResult convertStoreCustomerHistoryEntryResponse(
            CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        return fillPPITCustomerCareServicesResponse( prepaidServicesResponseVO, new StoreCustomerHistoryEntryResult() );
    }

    public FetchCustomerHistoryEntriesResult convertFetchCustomerHistoryEntriesResponse(
            CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        FetchCustomerHistoryEntriesResult exportAccountContactHistoryResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO, new FetchCustomerHistoryEntriesResult() );
        if( prepaidServicesResponseVO instanceof ExportAccountContactHistoryResponseVO ) {
            ExportAccountContactHistoryResponseVO resultVO = (ExportAccountContactHistoryResponseVO) prepaidServicesResponseVO;
            List<HistoryRecord> historyList = newArrayList();
            for( ContactVO contactVO : resultVO.getHistoryList() ) {
                historyList.add( getHistoryRecord( contactVO ) );
            }
            exportAccountContactHistoryResult.getHistoryRecordArrayHolder().addAll( historyList );
        }
        return exportAccountContactHistoryResult;
    }

    public GetSIMInfoResult convertGetSIMInfoResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetSIMInfoResult getSIMInfoResult = fillPPITCustomerCareServicesResponse( prepaidServicesResponseVO,
            new GetSIMInfoResult() );
        if( prepaidServicesResponseVO instanceof GetSIMInfoResponseVO ) {
            GetSIMInfoResponseVO resultVO = (GetSIMInfoResponseVO) prepaidServicesResponseVO;
            SIMInfo simInfo = convertSimInfo( resultVO );
            getSIMInfoResult.setSimInfo( simInfo );
        }
        return getSIMInfoResult;
    }

    private SIMInfo convertSimInfo( GetSIMInfoResponseVO resultVO ) {
        SIMInfo simInfo = new SIMInfo();
        simInfo.setBuPurpose( resultVO.getBuPurpose() );
        simInfo.setIccId( ValueObjectUtil.getValueOrNull( resultVO.getIccID() ) );
        simInfo.setImei( resultVO.getImei().orNull() );
        simInfo.setImsi( resultVO.getImsi() );
        simInfo.setMobileType( resultVO.getMobileType() );
        simInfo.setPin1( resultVO.getPin1() );
        simInfo.setPin2( resultVO.getPin2() );
        simInfo.setPossibleDeletionDate( resultVO.getPossibleDeletionDate() );
        simInfo.setPuk1( resultVO.getPuk1() );
        simInfo.setPuk2( resultVO.getPuk2() );
        simInfo.setRegistrationDate( resultVO.getPurchaseDate() );
        simInfo.setRemainingLifeInDays( resultVO.getRemainingLifeInDays() );
        simInfo.setSimCardStatus( CCSoapConverterV24.convertSimCardStatus( resultVO.getSimCardStatus() ) );
        simInfo.setSimPackagingType( CCSoapConverterV24.convertSimCardType( resultVO.getSimCardType() ) );
        simInfo.setSimLock( resultVO.getSimLock().orNull() );
        return simInfo;
    }

    public GetEGNDataResult convertGetEGNDataResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetEGNDataResult getEGNDataResult = fillPPITCustomerCareServicesResponse( prepaidServicesResponseVO,
            new GetEGNDataResult() );
        if( prepaidServicesResponseVO instanceof GetEgnDataResponseVo ) {
            GetEgnDataResponseVo resultVO = (GetEgnDataResponseVo) prepaidServicesResponseVO;
            assignEgnData( getEGNDataResult, resultVO );
            getEGNDataResult.setServiceResponse( getEGNDataResult.getServiceResponse() );
        }
        return getEGNDataResult;
    }

    public GetTopUpsAndChargesResult convertGetTopUpsAndChargesResponse( CustomerCareServicesResponseVo response ) {
        GetTopUpsAndChargesResult getTopUpsResult = fillPPITCustomerCareServicesResponse( response, new GetTopUpsAndChargesResult() );
        if( response instanceof GetTopUpsResponseVo ) {
            GetTopUpsResponseVo resultVO = (GetTopUpsResponseVo) response;
            assignTopUps( getTopUpsResult, resultVO );
        }
        return getTopUpsResult;
    }

    public GetCustomerDataResult convertGetCustomerDataResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetCustomerDataResult getCustomerDataResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO,
            new GetCustomerDataResult() );
        if( prepaidServicesResponseVO instanceof GetCustomerDataResponseVo ) {
            GetCustomerDataResponseVo resultVO = (GetCustomerDataResponseVo) prepaidServicesResponseVO;
            assignCustomerData( getCustomerDataResult, resultVO );
        }
        return getCustomerDataResult;
    }

    public GetDSSEntryResult convertGetDSSEntryResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetDSSEntryResult getDSSEntryResult = fillPPITCustomerCareServicesResponse( prepaidServicesResponseVO,
            new GetDSSEntryResult() );
        if( prepaidServicesResponseVO instanceof GetDSSEntryResponseVO ) {
            GetDSSEntryResponseVO resultVO = (GetDSSEntryResponseVO) prepaidServicesResponseVO;
            getDSSEntryResult.setDssEntry( setDSSEntryFromResultVO( resultVO ) );
            getDSSEntryResult.setIccid( ValueObjectUtil.getValueOrNull( resultVO.getIccid() ) );
            getDSSEntryResult.setRejectionCode( resultVO.getRejectionCode() );
            getDSSEntryResult.setRejectionDesc( resultVO.getRejectionDesc() );
            getDSSEntryResult.setRequestStatus( DSSRequestStatusEnum.fromValue( resultVO.getRequestStatus().getValue() ) );
            DssResult responseStatus = resultVO.getResponseStatus();
            getDSSEntryResult.setResponseStatus( DSSResponseStatusEnum.fromValue( responseStatus != null ? responseStatus.getValue()
                    : 0 ) );
        }
        return getDSSEntryResult;
    }

    public ActivateDSSEntryResult convertActivateDSSEntryResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        ActivateDSSEntryResult activateDSSEntryResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO, new ActivateDSSEntryResult() );
        return activateDSSEntryResult;
    }

    public GetChurnCustomerDataResult convertGetChurnCustomerDataResponse(
            CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetChurnCustomerDataResult getChurnCustomerDataResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO, new GetChurnCustomerDataResult() );
        if( prepaidServicesResponseVO instanceof GetChurnCustomerDataResponseVO ) {
            GetChurnCustomerDataResponseVO resultVO = (GetChurnCustomerDataResponseVO) prepaidServicesResponseVO;
            getChurnCustomerDataResult.setMsisdn( resultVO.getMsisdn() );
            getChurnCustomerDataResult = assignChurnCustomerData( getChurnCustomerDataResult, resultVO );
        }
        return getChurnCustomerDataResult;
    }

    public GetSIMHistoryResult convertGetSimHistoryResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetSIMHistoryResult simHistoryResult = fillPPITCustomerCareServicesResponse( prepaidServicesResponseVO,
            new GetSIMHistoryResult() );

        if( prepaidServicesResponseVO instanceof GetSimHistoryResponseVo ) {
            GetSimHistoryResponseVo resultVO = (GetSimHistoryResponseVo) prepaidServicesResponseVO;
            ChangeSimInfoVo[] changeSIMInfoVO = resultVO.getChangeSimInfoVos();
            List<ChangeSIMInfo> changeSIMInfoList = newArrayList();
            ChangeSIMInfo changeSIMInfo;
            for( ChangeSimInfoVo aChangeSIMInfoVO : changeSIMInfoVO ) {
                changeSIMInfo = convertChangeSimInfoVo( aChangeSIMInfoVO );
                changeSIMInfoList.add( changeSIMInfo );
            }
            simHistoryResult.getSimHistory().addAll( changeSIMInfoList );
        }
        return simHistoryResult;
    }

    public GetSIMStatisticsResult convertGetSimStatisticsResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetSIMStatisticsResult simStatisticsResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO, new GetSIMStatisticsResult() );

        if( prepaidServicesResponseVO instanceof GetSimStatisticsResponseVo ) {
            GetSimStatisticsResponseVo resultVO = (GetSimStatisticsResponseVo) prepaidServicesResponseVO;
            ChangeSimInfoVo[] changeSIMInfoVO = resultVO.getChangeSimInfoVos();
            List<ChangeSIMInfo> changeSIMInfoList = newArrayList();
            ChangeSIMInfo changeSIMInfo;
            for( ChangeSimInfoVo aChangeSIMInfoVO : changeSIMInfoVO ) {
                changeSIMInfo = convertChangeSimInfoVo( aChangeSIMInfoVO );
                changeSIMInfoList.add( changeSIMInfo );
            }
            simStatisticsResult.getSimStatistics().addAll( changeSIMInfoList );
        }
        return simStatisticsResult;
    }

    private ChangeSIMInfo convertChangeSimInfoVo( ChangeSimInfoVo aChangeSIMInfoVO ) {
        ChangeSIMInfo changeSIMInfo;
        changeSIMInfo = new ChangeSIMInfo();
        changeSIMInfo.setMsisdn( aChangeSIMInfoVO.getMsisdn().getValue() );
        changeSIMInfo.setNewIccid( getValueOrNull( aChangeSIMInfoVO.getNewIccid() ) );
        changeSIMInfo.setOldIccid( aChangeSIMInfoVO.getOldIccid().getValue() );
        changeSIMInfo.setActivationEndDate( aChangeSIMInfoVO.getActivationEndDate() );
        changeSIMInfo.setActivationStartDate( aChangeSIMInfoVO.getActivationStartDate() );
        changeSIMInfo.setStatus( convertSimChangeStatus( aChangeSIMInfoVO.getStatus() ) );
        changeSIMInfo.setLapiExternalOrderId( aChangeSIMInfoVO.getLapiExternalOrderId() );
        changeSIMInfo.setReason( convertSimReplacementReason( aChangeSIMInfoVO.getReason() ) );
        changeSIMInfo.setDefaultFee(
            aChangeSIMInfoVO.getDefaultFee() == null ? null : aChangeSIMInfoVO.getDefaultFee().getExactCentValueAsInt() );
        changeSIMInfo.setActualFee(
            aChangeSIMInfoVO.getActualFee() == null ? null : aChangeSIMInfoVO.getActualFee().getExactCentValueAsInt() );
        changeSIMInfo.setOrderChannel( Channel.getCustomerCareValueOrNull( aChangeSIMInfoVO.getOrderChannel() ) );
        changeSIMInfo.setActivationChannel( Channel.getCustomerCareValueOrNull( aChangeSIMInfoVO.getActivationChannel() ) );
        changeSIMInfo.setOrderDate( aChangeSIMInfoVO.getOrderDate() );
        changeSIMInfo.setShippingDate( aChangeSIMInfoVO.getShippingDate() );
        return changeSIMInfo;
    }

    private SimReplacementReason convertSimReplacementReason( com.telefonica.prepaid.subscription.sim.SimReplacementReason reason ) {
        if( reason == null ) {
            return null;
        }
        switch( reason ) {
            case DEFECT:
                return SimReplacementReason.DEFECT;
            case FORM_FACTOR:
                return SimReplacementReason.FORM_FACTOR;
            case LOSS:
                return SimReplacementReason.LOSS;
            case NONE:
                return SimReplacementReason.NONE;
            case THEFT:
                return SimReplacementReason.THEFT;
            case DEFECT_ESIM:
                return SimReplacementReason.DEFECT;
            case DELETED_OR_NEW_ESIM:
                return SimReplacementReason.FORM_FACTOR;
            case LOSS_ESIM:
                return SimReplacementReason.LOSS;
            case THEFT_ESIM:
                return SimReplacementReason.THEFT;
            default:
                throw new IllegalArgumentException( "Unknown value for SimReplacementReason" );
        }
    }

    private SimChangeStatusEnum convertSimChangeStatus( SimChangeStatus status ) {
        switch( status ) {
            case IN_PROGRESS:
                return ACTIVATION_IN_PROGRESS;
            case FAILED:
                return ACTIVATION_FAILED;
            case SUCCESSFUL:
                return ACTIVATION_SUCCESSFUL;
            case ORDERED:
                return ORDERED;
            case ORDERING_FAILED:
                return ORDERING_FAILED;
            case SHIPPED:
                return SHIPPED;
            case SHIPPING_FAILED:
                return SHIPPING_FAILED;
            case SHIPMENT_RETURNED:
                return SHIPMENT_RETURNED;
            default:
                throw new IllegalArgumentException( "Unknown value for status" );
        }
    }

    public DeactivateDSSEntryResult convertDeactivateDSSEntryResponse(
            CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        return fillPPITCustomerCareServicesResponse( prepaidServicesResponseVO,
            new DeactivateDSSEntryResult() );
    }

    public GetPreferredCommunicationChannelResult convertGetPreferredCommunicationChannelResponse(
            CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        GetPreferredCommunicationChannelResult response = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO, new GetPreferredCommunicationChannelResult() );
        if( prepaidServicesResponseVO instanceof GetPreferredCommunicationChannelResponseVO ) {
            GetPreferredCommunicationChannelResponseVO resultVO = (GetPreferredCommunicationChannelResponseVO) prepaidServicesResponseVO;
            if( resultVO.getPreferredCommunicationChannel().isPresent() ) {
                response.setPreferredCommunicationChannel( PreferredCommunicationChannelEnum.fromValue( resultVO
                    .getPreferredCommunicationChannel().get() ) );
            }
        }
        return response;
    }

    public SearchCustomersResult convertQueryCustomersResponse( CustomerCareServicesResponseVo prepaidServicesResponseVO ) {
        SearchCustomersResult queryCustomersResult = fillPPITCustomerCareServicesResponse(
            prepaidServicesResponseVO, new SearchCustomersResult() );
        if( prepaidServicesResponseVO instanceof QueryCustomerResponseVO ) {
            QueryCustomerResponseVO resultVO = (QueryCustomerResponseVO) prepaidServicesResponseVO;
            List<QueryCustomerData> queryCustomerList = FluentIterable.from( resultVO.getList() ).transform( toQueryCustomerDataFunction )
                .toList();
            queryCustomersResult.getQueryCustomerData().addAll( queryCustomerList );
        }
        return queryCustomersResult;
    }

    private static final Function<QueryCustomerVO, QueryCustomerData> toQueryCustomerDataFunction = new Function<QueryCustomerVO, QueryCustomerData>() {
        @Override
        public QueryCustomerData apply( QueryCustomerVO aQueryCustomer ) {
            return map2QueryCustomerData( aQueryCustomer );
        }
    };

    private static QueryCustomerData map2QueryCustomerData( QueryCustomerVO aQueryCustomer ) {
        QueryCustomerData queryCustomerData = new QueryCustomerData();
        queryCustomerData.setMsisdn( aQueryCustomer.getMSISDN() );
        queryCustomerData.setIccid( aQueryCustomer.getICCID() );
        queryCustomerData.setDob( aQueryCustomer.getBirthDate() );
        queryCustomerData.setEmail( aQueryCustomer.getEmail() );
        queryCustomerData.setFirstName( aQueryCustomer.getFirstname() );
        queryCustomerData.setLastName( aQueryCustomer.getName() );

        AddressData address = new AddressData();
        address.setCity( aQueryCustomer.getCity() );
        address.setCountryCode( aQueryCustomer.getCountryCode() );
        address.setHouseNumber( aQueryCustomer.getHouseNumber() );
        address.setStreet( aQueryCustomer.getStreet() );
        address.setZipCode( aQueryCustomer.getZipCode() );

        queryCustomerData.setAddress( address );
        queryCustomerData.setImei( aQueryCustomer.getImei() );
        queryCustomerData.setPurchaseDate( aQueryCustomer.getPurchaseData() );

        return queryCustomerData;
    }

    @Nullable
    private static AddressResult convertAddressCheckResult( PrepaidITCustomerCareServicesWithAddressResponseVO response ) {
        if( !response.getNormalizedAddress().isPresent() && ListUtils.isNullOrEmpty( response.getProposedAddresses() ) ) {
            return null;
        }

        AddressResult addressResult = new AddressResult();
        if( response.isSuccess() ) {
            // This is actually the normalized address (according to the xsd, the address was "corrected" but then
            // accepted, which is only the case for a normalized address).
            addressResult.setCorrectedAddress( convertAddressData( response.getNormalizedAddress().orNull() ) );
        } else {
            addressResult.setAddressCorrectionCandidates( convertProposedAddresses( response.getProposedAddresses() ) );
        }

        return addressResult;
    }

    @Nullable
    private static AddressList convertProposedAddresses( List<AddressDataVo> customerAddress ) {
        if( ListUtils.isNullOrEmpty( customerAddress ) ) {
            return null;
        }

        return new AddressList().withAddress( Lists.transform( customerAddress,
            new Function<AddressDataVo, AddressData>() {
                @Override
                public AddressData apply( AddressDataVo input ) {
                    return convertAddressData( input ); // NOSONAR
                }
            } ) );
    }

    @Nullable
    private static AddressData convertAddressData( AddressDataVo addressDataVo ) {
        if( addressDataVo == null ) {
            return null;
        }

        AddressData address = new AddressData();
        address.setHouseNumber( addressDataVo.getHouseNumber() );
        address.setStreet( StringUtils.left( addressDataVo.getStreet(), MAX_ADDRESS_PART_LENGTH ) );
        address.setCity( StringUtils.left( addressDataVo.getCity(), MAX_ADDRESS_PART_LENGTH ) );
        address.setCountryCode( addressDataVo.getCountryCode() );
        address.setZipCode( addressDataVo.getZipCode() );
        return address;
    }

    private static HistoryRecord getHistoryRecord( ContactVO contactVO ) {
        HistoryRecord historyRecord = new HistoryRecord();
        Date changeDate = contactVO.getChangeDate();
        historyRecord.setContactDateTime( changeDate );
        historyRecord.setActionCode( contactVO.getActionCode() );
        historyRecord.setAgent( contactVO.getAgent() );
        historyRecord.setCallReason( contactVO.getCallReason() );
        historyRecord.setComment( contactVO.getContComment() );
        historyRecord.setProcess( contactVO.getProcess() );
        historyRecord.setContactType( convertEventContactType( contactVO.getEventContactType() ) );
        return historyRecord;
    }

    private static AccountContactTypeEnum convertEventContactType( EventContactType eventContactType ) {
        if( eventContactType == EventContactType.MANUAL_CONTACT ) {
            return AccountContactTypeEnum.MANUAL_CONTACT;
        } else {
            return AccountContactTypeEnum.AUTOMATIC_EVENT;
        }
    }

    private static void assignEgnData( GetEGNDataResult egnDataResult, GetEgnDataResponseVo responseVO ) {
        List<EgnDataVo> egnDataVos = responseVO.getEgnDataVOList();
        if( egnDataVos == null || egnDataVos.isEmpty() ) {
            return;
        }
        List<EGNData> egnDatas = newArrayListWithCapacity( egnDataVos.size() );
        for( EgnDataVo egnDataVo : egnDataVos ) {
            egnDatas.add( convertEgnDataElement( egnDataVo ) );
        }
        egnDataResult.getEgnData().addAll( egnDatas );
    }

    private static EGNData convertEgnDataElement( EgnDataVo egnDataVo ) {
        EGNData egnDataElement = new EGNData();
        egnDataElement.setBonusAmount( (int) egnDataVo.getBonusAmountOr0() );
        egnDataElement.setCost( (int) egnDataVo.getCost() );
        egnDataElement.setDuration( egnDataVo.getDuration() );
        egnDataElement.setMainAmount( (int) egnDataVo.getMainAmountOr0() );

        if( egnDataVo.getPackDescriptions() != null ) {
            egnDataElement.getPackDescription().addAll( egnDataVo.getPackDescriptions() );
        }

        egnDataElement.setServiceProvider( egnDataVo.getServiceProvider() );
        egnDataElement.setServiceType( PackServiceTypeEnum.fromValue( egnDataVo.getServiceType() ) );
        egnDataElement.setTelephoneNumber( egnDataVo.getTelephoneNumber() );
        egnDataElement.setUsageDate( egnDataVo.getUsageDate() );
        egnDataElement.setIsThresholdBenefitApplied( egnDataVo.isThresholdBenefitApplied() );
        egnDataElement.setComment( egnDataVo.getComment() );
        egnDataElement.setUsageStartDateTimeString( CustomerCareConverter.formatSoapDateTimeString( egnDataVo.getUsageStartDate() ) );
        egnDataElement.setUsageEndDateTimeString( CustomerCareConverter.formatSoapDateTimeString( egnDataVo.getUsageEndDate() ) );
        if( egnDataVo.getSessionCreation() != null ) {
            egnDataElement.setSessionCreation( egnDataVo.getSessionCreation() );
        }
        if( egnDataVo.getSessionId() > 0 ) {
            egnDataElement.setSessionId( egnDataVo.getSessionId() );
        }
        if( egnDataVo.getUsageTime() > 0 ) {
            egnDataElement.setUsageTime( egnDataVo.getUsageTime() );
        }
        if( egnDataVo.getUsageVolume() > 0 ) {
            egnDataElement.setUsageVolume( egnDataVo.getUsageVolume() );
        }
        if( egnDataVo.getBillingOption() != null ) {
            egnDataElement.setBillingOption( egnDataVo.getBillingOption() );
        }
        if( egnDataVo.getRoamingOperator() != null ) {
            egnDataElement.setRoamingOperator( egnDataVo.getRoamingOperator() );
        }
        egnDataElement.setCategory( convertEgnDataCategory( egnDataVo.getCategory() ) );
        return egnDataElement;
    }

    private static EgnDataCategoryEnum convertEgnDataCategory( EgnDataCategory category ) {
        return EgnDataCategoryEnum.fromValue( category.getValue() );
    }

    private static void assignTopUps( GetTopUpsAndChargesResult topUpsResult, GetTopUpsResponseVo responseVO ) {
        List<TopUpDataVo> topUpVos = responseVO.getTransactions();
        List<Transaction> topUps = newArrayListWithCapacity( topUpVos.size() );
        for( TopUpDataVo topUpDataVo : topUpVos ) {
            Transaction topUpInfoElement = new Transaction();
            topUpInfoElement.setActivationCode( topUpDataVo.getActivationCode() );
            topUpInfoElement.setCreditBalance( EGNDataUtils.extractCreditBalanceSafely( topUpDataVo ) );
            topUpInfoElement.setExpiryDate( topUpDataVo.getExpiryDate() );
            topUpInfoElement.setAmount( (int) topUpDataVo.getRechargeAmount() );
            if( topUpDataVo.getRechargeBenefit() != null ) {
                topUpInfoElement.getRechargeBenefit().addAll( topUpDataVo.getRechargeBenefit() );
            }
            topUpInfoElement.setInfo( topUpDataVo.getRechargeInfo() );
            topUpInfoElement.setSerialNumber( topUpDataVo.getSerialNumber() );
            topUpInfoElement.setDate( topUpDataVo.getTopUpDate() );
            topUpInfoElement.setDateTimeString( CustomerCareConverter.formatSoapDateTimeString( topUpDataVo.getTopUpDate() ) );
            topUpInfoElement.setAgent( topUpDataVo.getTopUpAgent() );
            topUpInfoElement.setAgentComment( topUpDataVo.getAgentComment() );
            topUpInfoElement.setDisplayComment( Strings.nullToEmpty( topUpDataVo.getDisplayComment() ) );
            topUps.add( topUpInfoElement );
        }
        topUpsResult.getTransaction().addAll( topUps );
    }

    private static GetCustomerDataResult assignCustomerData( GetCustomerDataResult getCustomerDataResult,
            GetCustomerDataResponseVo resultVO ) {
        CustomerData customerData = null;
        if( resultVO.getCustomerDataVo() != null ) {
            customerData = setCustomerData( resultVO.getCustomerDataVo() );
            getCustomerDataResult.setRegistrationDate( resultVO.getCustomerDataVo().getRegistrationDate() );
            getCustomerDataResult.setPurchaseDate( resultVO.getCustomerDataVo().getPurchaseDate().orNull() );
        }
        TchiboAdditionalInfo tchiboAdditionalInfo = convertTchiboAdditionalInfo( resultVO.getTchiboAdditionalInfoVO() );
        getCustomerDataResult.setTchiboAdditionalInfo( tchiboAdditionalInfo );

        getCustomerDataResult.setCustomerData( customerData );
        getCustomerDataResult.setLifeCycleState( mapLifeCycleValues( resultVO.getLifeCycleState() ) );
        if( resultVO.getChannel() == Channel.ONLINESELFCARE || resultVO.getClientId() == CustomerCareClient.TCHIBO ) {
            getCustomerDataResult.setContractId( resultVO.getContract().getContractId() );
        }
        getCustomerDataResult.setMsisdn( resultVO.getContract().getMsisdn() );
        getCustomerDataResult.setPermitsCallStore( convertCallStorePermission( resultVO.getCallStorePermission() ) );
        if( resultVO.getPreferredCommunicationChannel() != null ) {
            getCustomerDataResult.setPreferredCommunicationChannel( PreferredCommunicationChannelEnum.fromValue(
                resultVO.getPreferredCommunicationChannel().getValue() ) );
        } else {
            getCustomerDataResult.setPreferredCommunicationChannel( PreferredCommunicationChannelEnum.fromValue(
                PrepaidITCustomerCareServicesConstants.PREFERRED_COMMUNICATION_CHANNEL_DEFAULT ) );
        }

        getCustomerDataResult.setTariffInfo( convertTariffInfo( resultVO.getTariffInfoVo() ) );
        if( resultVO.isSuccess() ) {
            getCustomerDataResult.setForwardData( resultVO.isForwardData() );
        }

        if( resultVO.getCustomerDataVo() != null ) {
            getCustomerDataResult.setRegistrationChannel(
                CustomerCareConverter.convertToCustomerCareChannel( resultVO.getCustomerDataVo().getRegistrationChannel() ) );
        }

        boolean barredForIdvFraud = resultVO.isBarredForIdvFraud();
        getCustomerDataResult.setIdvFraudStatus( barredForIdvFraud ? IdvFraudStatus.IDV_FRAUD_BARRED : IdvFraudStatus.NONE );

        if( resultVO.getIdVerificationStatus() != null ) {
            getCustomerDataResult.setIdentityVerificationStatus( convertIdVerificationStatus( resultVO.getIdVerificationStatus(),
                barredForIdvFraud ) );
        }

        getCustomerDataResult
            .setIdvReferenceNumber( convertIdVerificationReferenceNumber( resultVO.getIdVerificationReferenceNumber() ) );
        PaymentMethodInfoVo paymentMethodInfoVo = resultVO.getPaymentMethodInfoVo();
        assignSepaAndDirectDebitStatusInfo( getCustomerDataResult, paymentMethodInfoVo );
        getCustomerDataResult.setCreditCard( convertCreditCardDataWithRegistrationState( paymentMethodInfoVo.getCreditCardData() ) );
        getCustomerDataResult.setActivePaymentMethod( convertPaymentMethod( paymentMethodInfoVo.getActivePaymentMethod().orNull() ) );
        getCustomerDataResult.setExternalContractId( resultVO.getExternalContractId().getValue() );
        if( !resultVO.getDisallowedUseCases().isEmpty() ) {
            DisallowedUseCasesList disallowedUseCasesList = new DisallowedUseCasesList();
            for( DisallowedUseCaseElementVo disallowedUseCaseElementVO : resultVO.getDisallowedUseCases() ) {
                CustomerCareUseCase disalloweUseCase = disallowedUseCaseElementVO.getDisallowedUseCase();
                if( !SUPPORTED_USECASES.contains( disalloweUseCase ) ) {
                    continue;
                }
                DisallowedUseCaseElement disallowedUseCaseElement = new DisallowedUseCaseElement()
                    .withReason( DisallowedReasonEnum.fromValue( disallowedUseCaseElementVO.getDisallowedReason().getValue() ) )
                    .withUseCase( DisallowedUseCaseEnum.fromValue( disalloweUseCase.getValue() ) );
                disallowedUseCasesList.withDisallowedUseCase( disallowedUseCaseElement );
            }
            getCustomerDataResult.setDisallowedUseCases( disallowedUseCasesList );
        }
        getCustomerDataResult.setMigrationDate( resultVO.getMigrationDate().orNull() );
        getCustomerDataResult.setEmailVerificationStatus( convertEmailVerificationStatus( resultVO.getEmailVerificationStatusVo() ) );
        return getCustomerDataResult;
    }

    @VisibleForTesting
    static CreditCardDataWithRegistrationState convertCreditCardDataWithRegistrationState( CreditCardDataVo creditCardDataVo ) {
        if( creditCardDataVo == null ) {
            return null;
        }
        CreditCardDataWithRegistrationState result = new CreditCardDataWithRegistrationState();
        result.setRegistrationState( convertCreditCardRegistrationStatus( creditCardDataVo.getStatus() ) );
        result.setCreditCardData( convertCreditCardData( creditCardDataVo ) );
        return result;
    }

    @VisibleForTesting
    static CreditCardRegistrationStatusEnum convertCreditCardRegistrationStatus( CreditCardRegistrationStatus status ) {
        if( status == null ) {
            return null;
        }
        switch( status ) {
            case REGISTRATION_RECEIVED:
            case CREDIT_CHECK_ONGOING:
            case CREDIT_CHECK_OK:
                return CreditCardRegistrationStatusEnum.REGISTRATION_ONGOING;
            case REGISTERED:
                return CreditCardRegistrationStatusEnum.REGISTERED;
            case CREDIT_CHECK_FAILED:
            case REGISTRATION_FAILED_BEFORE_CREDIT_CHECK:
            case REGISTRATION_FAILED_AFTER_CREDIT_CHECK:
            case DEREGISTERED:
                throw Reject.always( "Unsupported CreditCardRegistrationStatus:" + status );
            default:
                throw Reject.always( "Conversion for CreditCardRegistrationStatus:" + status + " is not yet implemented." );
        }
    }

    @VisibleForTesting
    static CreditCardData convertCreditCardData( CreditCardDataVo creditCardDataVo ) {
        if( creditCardDataVo == null ) {
            return null;
        }
        CreditCardData creditCardData = new CreditCardData();
        creditCardData.setOwner( creditCardDataVo.getOwner().getValue() );
        creditCardData.setMaskedCreditCardNumber( creditCardDataVo.getMaskedCreditCardNumber().getValue() );
        creditCardData.setProvider( convertCreditCardProvider( creditCardDataVo.getProvider() ) );
        creditCardData.setExpiryMonth( creditCardDataVo.getExpiryMonth().getValue() );
        creditCardData.setExpiryYear( creditCardDataVo.getExpiryYear().getValue() );
        creditCardData.setRegistrationDate( creditCardDataVo.getRegistrationDate() );
        creditCardData.setAuthorized( creditCardDataVo.isAuthorized() );
        creditCardData.setLiabilityShift( creditCardDataVo.isLiabilityShift() );
        creditCardData.setReferenceId( creditCardDataVo.getReferenceId().getValue() );
        return creditCardData;
    }

    @VisibleForTesting
    static com.telefonica.prepaid.customercare.v24.service.domain.CreditCardProvider convertCreditCardProvider(
            CreditCardProvider provider ) {
        if( provider == null ) {
            return null;
        }
        switch( provider ) {
            case AMEX:
                return com.telefonica.prepaid.customercare.v24.service.domain.CreditCardProvider.AMEX;
            case MASTERCARD:
                return com.telefonica.prepaid.customercare.v24.service.domain.CreditCardProvider.MASTERCARD;
            case VISA:
                return com.telefonica.prepaid.customercare.v24.service.domain.CreditCardProvider.VISA;
            default:
                throw Reject.always( "Conversion of credit card provider " + provider + " is not yet implemented." );
        }
    }

    @VisibleForTesting
    static String convertPaymentMethod( PaymentMethod paymentMethod ) {
        if( paymentMethod == null ) {
            return null;
        }
        switch( paymentMethod ) {
            case CREDIT_CARD:
                return com.telefonica.prepaid.customercare.v24.service.domain.PaymentMethod.CREDIT_CARD.value();
            case DIRECT_DEBIT:
                return PaymentMethodDirectDebit.DIRECT_DEBIT.value();
            default:
                throw Reject.always( "Conversion of PaymentMethod " + paymentMethod + " is not yet implemented." );
        }
    }

    private static com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus convertIdVerificationStatus(
            CustomerCareIdVerificationStatus idVerificationStatus, boolean barredForIdvFraud ) {
        switch( idVerificationStatus ) {
            case VERIFIED:
                return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.VERIFIED;
            case PENDING:
                return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.PENDING;
            case REVERIFICATION_NECESSARY:
                return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.REVERIFICATION_NECESSARY;
            case NOT_VERIFIED:
                return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.NOT_VERIFIED;
            case NOT_AVAILABLE:
                return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.NOT_AVAILABLE;
            case FINAL_FAILED:
                if( barredForIdvFraud ) {
                    return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.REVERIFICATION_NECESSARY;
                } else {
                    return com.telefonica.prepaid.customercare.v24.service.domain.IdVerificationStatus.PENDING;
                }
            default:
                throw Reject.always( "Cannot convert CustomerCareIdVerificationStatus:" + idVerificationStatus );
        }
    }

    private static IdvReferenceNumber convertIdVerificationReferenceNumber( IdVerificationReferenceNumber idVerificationReferenceNumber ) {
        if( idVerificationReferenceNumber == null ) {
            return null;
        }
        IdvReferenceNumber idvReferenceNumber = new IdvReferenceNumber();
        if( idVerificationReferenceNumber.getType() != null && idVerificationReferenceNumber.getValue() != null ) {
            idvReferenceNumber.setType( idVerificationReferenceNumber.getType().getValue() );
            idvReferenceNumber.setValue( idVerificationReferenceNumber.getValue().getValue() );
        } else {
            throw Reject.always( "Cannot convert IdVerificationReferenceNumber: " + idVerificationReferenceNumber );
        }
        return idvReferenceNumber;
    }

    private static PermitsCallStoreEnum convertCallStorePermission( CallStorePermission value ) {
        if( value == null ) {
            return null;
        }
        switch( value ) {
            case FULL:
                return PermitsCallStoreEnum.FULL;
            case MASKED:
                return PermitsCallStoreEnum.MASKED;
            case NONE:
                return PermitsCallStoreEnum.NONE;
            default:
                throw Reject.always( "Cant convert CallStorePermission." + value );
        }
    }

    private static TariffInfo convertTariffInfo( TariffInfoVO tariffInfoVo ) {
        if( tariffInfoVo == null ) {
            return null;
        }
        TariffInfo tariffInfo = new TariffInfo();
        tariffInfo.setTariffProductId( tariffInfoVo.getTariffProductId() );
        tariffInfo.setTariffDesc( tariffInfoVo.getTariffDesc() );
        tariffInfo.setCustomerTariffDesc( tariffInfoVo.getCustomerTariffDesc() != null ? tariffInfoVo.getCustomerTariffDesc()
                : tariffInfoVo.getTariffDesc() );
        tariffInfo.setAirBagApplicable( tariffInfoVo.isAirBagAllowed() );
        return tariffInfo;
    }

    private static com.telefonica.prepaid.customercare.v24.service.domain.EmailVerificationStatus convertEmailVerificationStatus(
            EmailVerificationStatusVo emalEmailVerificationStatusVo ) {
        if( emalEmailVerificationStatusVo == null ) {
            return null;
        }
        com.telefonica.prepaid.customercare.v24.service.domain.EmailVerificationStatus emailVerificationStatus = new com.telefonica.prepaid.customercare.v24.service.domain.EmailVerificationStatus();
        emailVerificationStatus
            .setEmailVerification(
                EmailVerificationStatusEnum.fromValue( emalEmailVerificationStatusVo.getEmailVerificationStatus().getValue() ) );
        emailVerificationStatus.setIsEmailVerificationRunning( emalEmailVerificationStatusVo.isEmailVerificationRunning() );
        return emailVerificationStatus;
    }

    private static void assignSepaAndDirectDebitStatusInfo( GetCustomerDataResult getCustomerDataResult,
            PaymentMethodInfoVo paymentMethodInfoVo ) {
        if( paymentMethodInfoVo == null ) {
            return;
        }
        getCustomerDataResult.setDirectDebitRegistrationState( convertDirectDebitStatus( paymentMethodInfoVo.getDirectDebitStatus() ) );

        if( paymentMethodInfoVo.getSepaInfo() == null || paymentMethodInfoVo.getSepaInfo().getDirectDebitBankAccount() == null ) {
            return;
        }
        CustomerDataSepaInfoVo customerDataSepaInfoVo = paymentMethodInfoVo.getSepaInfo();
        DirectDebitBankAccountVo directDebitBankAccount = customerDataSepaInfoVo.getDirectDebitBankAccount();
        String creditorId = customerDataSepaInfoVo.getCreditorId();

        BankAccountCustomerData bankAccountCustomerData = convertBankAccount( directDebitBankAccount, creditorId, false );

        Optional<ThirdPartyBankAccountOwnerVo> thirdPartyBankAccountOwnerVo = directDebitBankAccount
            .getThirdPartyBankAccountOwner();
        if( thirdPartyBankAccountOwnerVo.isPresent() ) {
            ThirdPartyBankAccountOwner thirdPartyAccountOwner = convertThirdPartyAccountOwner( thirdPartyBankAccountOwnerVo.get() );
            bankAccountCustomerData.setThirdPartyAccountOwner( thirdPartyAccountOwner );
        }

        getCustomerDataResult.setBankAccount( bankAccountCustomerData );
    }

    private static BankAccountCustomerData convertBankAccount( DirectDebitBankAccountVo directDebitBankAccount, String creditorId,
            boolean forDataPortability ) {
        BankAccountCustomerData bankAccountCustomerData = null;
        if( forDataPortability ) {
            bankAccountCustomerData = createAndSetBankAccountDataForDataPortability( directDebitBankAccount );
        } else {
            bankAccountCustomerData = new BankAccountCustomerData();
        }

        bankAccountCustomerData.setCreditorId( creditorId );
        bankAccountCustomerData.setSepaMandateId( ValueObjectUtil.getValueOrNull( directDebitBankAccount.getSepaMandateId() ) );
        bankAccountCustomerData.setBankAccountOwner( directDebitBankAccount.getAccountOwner() );
        bankAccountCustomerData.setBic( directDebitBankAccount.getBusinessIdentifierCode().get() );
        bankAccountCustomerData.setIban( directDebitBankAccount.getIntBankAccountNumber().getValue() );
        LegacyBankDataVo legacyBankData = directDebitBankAccount.getLegacyBankData();
        if( legacyBankData != null ) {
            bankAccountCustomerData.setBankCode( ValueObjectUtil.getValueOrNull( legacyBankData.getBankCode() ) );
            bankAccountCustomerData.setAccountNumber( ValueObjectUtil.getValueOrNull( legacyBankData.getBankAccount() ) );
        }
        bankAccountCustomerData.setBankName( Strings.emptyToNull( directDebitBankAccount.getBankName() ) );

        return bankAccountCustomerData;
    }

    private static BankAccountCustomerData createAndSetBankAccountDataForDataPortability(
            DirectDebitBankAccountVo directDebitBankAccount ) {
        BankAccountDataForDataPortability bankAccountCustomerData = new BankAccountDataForDataPortability();
        bankAccountCustomerData.setSepaMandateValidFrom( directDebitBankAccount.getSepaMandateCreationDate() );
        bankAccountCustomerData.setSepaMandateValidTo( directDebitBankAccount.getSepaMandateEndDate() );
        return bankAccountCustomerData;
    }

    private static ThirdPartyBankAccountOwner convertThirdPartyAccountOwner( ThirdPartyBankAccountOwnerVo thirdPartyBankAccountOwnerVo ) {
        ThirdPartyBankAccountOwner thirdPartyBankAccountOwner = new ThirdPartyBankAccountOwner();
        thirdPartyBankAccountOwner.setSalutation( getThirdPartyBankAccountOwnerSalutation(
            thirdPartyBankAccountOwnerVo.getSalutation() ) );
        AddressDataVo addressDataVo = thirdPartyBankAccountOwnerVo.getAddressDataVo();
        if( addressDataVo != null && !StringUtils.isBlank( addressDataVo.getHouseNumber() )
                && !StringUtils.isBlank( addressDataVo.getStreet() )
                && !StringUtils.isBlank( addressDataVo.getCity() )
                && !StringUtils.isBlank( addressDataVo.getZipCode() ) ) {
            thirdPartyBankAccountOwner.setAddressData( convertAddressData( addressDataVo ) );
        }
        thirdPartyBankAccountOwner.setEmail( thirdPartyBankAccountOwnerVo.getEmail() );
        return thirdPartyBankAccountOwner;
    }

    private static com.telefonica.prepaid.customercare.v24.service.domain.Salutation getThirdPartyBankAccountOwnerSalutation(
            Salutation salutation ) {
        if( salutation != null ) {
            switch( salutation ) {
                case HERR:
                    return com.telefonica.prepaid.customercare.v24.service.domain.Salutation.HERR;
                case FRAU:
                    return com.telefonica.prepaid.customercare.v24.service.domain.Salutation.FRAU;
                case NONE:
                    return null;
                case FIRMA:
                    return null;
                default:
                    throw new IllegalArgumentException( "Unsupported salutation for ThirdPartyBankAccountOwner. Was " + salutation );
            }
        }
        return null;
    }

    @VisibleForTesting
    protected static DirectDebitRegistrationStateEnum convertDirectDebitStatus( DirectDebitStatus directDebitStatus ) {
        if( directDebitStatus == null ) {
            return null;
        }
        switch( directDebitStatus ) {
            case WAITING_FOR_FIRST_DIRECT_DEBIT:
            case INITIAL_RETENTION:
            case ACTIVE:
                return DirectDebitRegistrationStateEnum.REGISTERED;
            case WAITING_FOR_CUSTOMER_INPUT:
            case CREDIT_CHECK_ONGOING:
                return DirectDebitRegistrationStateEnum.REGISTRATION_IN_PROGRESS;
            case REGISTRATION_FAILED:
            case CREDIT_CHECK_FAILED:
            case UNREGISTERED:
                return DirectDebitRegistrationStateEnum.UNREGISTERED;
            default:
                throw new IllegalArgumentException( "Unknown state for directDebitStatus" );
        }
    }

    private static CustomerData setCustomerData( CustomerDataVo customerDataVo ) {
        CustomerData customerData = new CustomerData();

        customerData.setChurnStatus( ChurnStatusEnum.fromValue( customerDataVo.getChurnStatus() ) );

        Optional<DneReminderVo> customerAgreementReminderVo = customerDataVo.getDneReminder();
        if( customerAgreementReminderVo.isPresent() ) {
            setCustomerAgreementReminder( customerAgreementReminderVo.get() );
        }
        if( customerDataVo.getCustomerDne() != null ) {
            CustomerAgreementFlags customerAgreementFlags = setCustomerAgreementFlag( customerDataVo.getCustomerDne() );
            customerData.setCustomerAgreementFlags( customerAgreementFlags );
        }
        customerData.setDealerCode( customerDataVo.getRegistrationVoId() );
        customerData.setFskLevel( FskLevelEnum.fromValue( customerDataVo.getFskLevel().getValue() ) );

        if( customerDataVo.getPersonalDataVo() != null ) {
            PersonalData perData = setPersonalData( customerDataVo.getPersonalDataVo() );
            customerData.setPersonalData( perData );
        }
        customerData.setPkk( customerDataVo.getPkk() );
        customerData.setPkkType( PKKTypeEnum.fromValue( customerDataVo.getPkkType() ) );
        return customerData;
    }

    private static CustomerAgreementReminder setCustomerAgreementReminder( DneReminderVo customerAgreementReminderVo ) {
        CustomerAgreementReminder customerAgreementReminder = new CustomerAgreementReminder();
        customerAgreementReminder.setAllowsReminder( customerAgreementReminderVo.isAllowsReminder().orNull() );
        customerAgreementReminder.setLastReminderDate( customerAgreementReminderVo.getLastReminderDate().orNull() );
        return customerAgreementReminder;
    }

    private static CustomerAgreementFlags setCustomerAgreementFlag( CustomerDneVo dneVo ) {
        CustomerDneCategoryVo companyDne = dneVo.getCategoryDne( DneScope.COMPANY );
        CustomerDneCategoryVo partnerDne = dneVo.getCategoryDne( DneScope.PARTNER );

        CustomerAgreementFlagsCategory companyFlags = new CustomerAgreementFlagsCategory();
        companyFlags.setEmail( companyDne.isEmailAllowed() );
        companyFlags.setLetter( companyDne.isLetterAllowed() );
        companyFlags.setSms( companyDne.isSmsMmsAllowed() );
        companyFlags.setPhone( companyDne.isPhoneAllowed() );

        CustomerAgreementFlagsCategory partnerFlags = new CustomerAgreementFlagsCategory();
        partnerFlags.setEmail( partnerDne.isEmailAllowed() );
        partnerFlags.setLetter( partnerDne.isLetterAllowed() );
        partnerFlags.setSms( partnerDne.isSmsMmsAllowed() );
        partnerFlags.setPhone( partnerDne.isPhoneAllowed() );

        CustomerAgreementFlags response = new CustomerAgreementFlags();
        response.setUseCustomerInfo( dneVo.isUseCustomerDataAllowed() );
        response.setCompanyUseTrafficData( dneVo.isUseTrafficDataAllowed() );

        response.setCompanyUseCustomerData( companyFlags );
        response.setPartnerUseCustomerAndTrafficData( partnerFlags );
        return response;
    }

    @VisibleForTesting
    protected static DSSEntry setDSSEntryFromResultVO( GetDSSEntryResponseVO resultVO ) {
        DSSEntry dssEntry = new DSSEntry();
        AddressData addressResult = new AddressData();
        addressResult.setCity( resultVO.getCity() );
        addressResult.setCountryCode( resultVO.getCountryCode() );
        addressResult.setHouseNumber( resultVO.getHouseNumber() );
        addressResult.setStreet( resultVO.getStreet() );
        addressResult.setZipCode( resultVO.getZipCode() );
        dssEntry.setAddress( addressResult );
        dssEntry.setCdRomUsage( resultVO.getCdRomUsage() );
        dssEntry.setFirstName( resultVO.getFirstName() );
        dssEntry.setGender( GenderEnum.fromValue( resultVO.getGender().getValue() ) );
        dssEntry.setLastName( resultVO.getLastName() );
        dssEntry.setPrintUsage( resultVO.isUsageInPrintMediaAllowed() );
        dssEntry.setTitle( truncateToMaxLength( resultVO.getTitle(), "Title", 10 ) );
        dssEntry.setUsage( DSSUsageEnum.fromValue( resultVO.getUsage() ) );
        return dssEntry;
    }

    private static GetChurnCustomerDataResult assignChurnCustomerData( GetChurnCustomerDataResult getChurnCustomerDataResult,
            GetChurnCustomerDataResponseVO resultVO ) {
        if( resultVO == null || ListUtils.isNullOrEmpty( resultVO.getList() ) ) {
            return getChurnCustomerDataResult;
        }
        List<ChurnCustomerData> churnCustomerDataList = new ArrayList<>( resultVO.getList().size() );
        for( ChurnDataVO churnDataVo : resultVO.getList() ) {
            getChurnCustomerDataResult.setMsisdn( churnDataVo.getMsisdn() );
            churnCustomerDataList.add( convertChurnCustomerData( churnDataVo ) );
        }
        getChurnCustomerDataResult.getChurnCustomerData().addAll( churnCustomerDataList );
        return getChurnCustomerDataResult;
    }

    private static ChurnCustomerData convertChurnCustomerData( ChurnDataVO churnDataVO ) {
        ChurnCustomerData churnCustomerData = new ChurnCustomerData();
        churnCustomerData.setContractId( churnDataVO.getContract().getContractId() );
        churnCustomerData.setExternalContractId( churnDataVO.getExternalContractId().getValue() );
        churnCustomerData.setDeletionAmount( (int) churnDataVO.getAccountDeletionAmount() );
        churnCustomerData.setFirstName( churnDataVO.getFirstName() );
        churnCustomerData.setLastName( churnDataVO.getLastName() );
        churnCustomerData.setImei( churnDataVO.getImei() );
        churnCustomerData.setIccid( ValueObjectUtil.getValueOrNull( churnDataVO.getIccId() ) );
        churnCustomerData.setImsi( churnDataVO.getImsi() );
        churnCustomerData.setPin( churnDataVO.getPin1() );
        churnCustomerData.setPuk( churnDataVO.getPuk1() );
        churnCustomerData.setDob( churnDataVO.getDob() );
        churnCustomerData.setLifeCycleState( mapLifeCycleValues( churnDataVO.getLifeCycleStatus() ) );
        churnCustomerData.setDelockCode( churnDataVO.getSimDelockCode() );
        churnCustomerData.setDelockDate( churnDataVO.getDelockDate() );

        churnCustomerData.setActivationDate( churnDataVO.getActivationDate() );
        churnCustomerData.setAccountDeletionDate( churnDataVO.getAccountDeletionDate() );
        churnCustomerData.setAddress( convertAddressData( churnDataVO.getAddressDataVo() ) );
        churnCustomerData.setTchiboAdditionalInfo( convertTchiboAdditionalInfo( churnDataVO.getTchiboAdditionalInfoVO() ) );

        List<HistoryRecord> historyRecords = convertHistoryRecords( churnDataVO.getHistoryList() );
        churnCustomerData.getContactHistory().addAll( historyRecords );

        return churnCustomerData;
    }

    private static List<HistoryRecord> convertHistoryRecords( List<ContactVO> historyList ) {
        List<HistoryRecord> historyRecords = newArrayList();
        if( historyList != null ) {
            for( ContactVO contactVo : historyList ) {
                historyRecords.add( getHistoryRecord( contactVo ) );
            }
        }
        return historyRecords;
    }

    private static LifeCycleStateEnum mapLifeCycleValues( ContractStatus contractStatus ) {
        return LifeCycleStateEnum.fromValue( contractStatus.getValue() );
    }

    @Nullable
    private static TchiboAdditionalInfo convertTchiboAdditionalInfo( TchiboAdditionalInfoVO tchiboAdditionalInfoVO ) {
        if( tchiboAdditionalInfoVO == null ) {
            return null;
        }
        TchiboAdditionalInfo tchiboAdditionalInfo = new TchiboAdditionalInfo();
        tchiboAdditionalInfo.setA1( tchiboAdditionalInfoVO.getA1() );
        tchiboAdditionalInfo.setA2( tchiboAdditionalInfoVO.getA2() );
        tchiboAdditionalInfo.setA3( tchiboAdditionalInfoVO.getA3() );
        tchiboAdditionalInfo.setBusinessCustomer( tchiboAdditionalInfoVO.isBusinessCustomer() );
        tchiboAdditionalInfo.setCustomerGroup( tchiboAdditionalInfoVO.getCustomerGroup() );
        tchiboAdditionalInfo.setInverseSearch( tchiboAdditionalInfoVO.isInverseSearch() );
        tchiboAdditionalInfo.setPayMethod( tchiboAdditionalInfoVO.getPayMethod() );
        tchiboAdditionalInfo.setUstID( tchiboAdditionalInfoVO.getUstId() );
        tchiboAdditionalInfo.setBillDay( tchiboAdditionalInfoVO.getBillDay().orNull() );
        Optional<FixedBillCycleVo> fixedBillCycleVo = tchiboAdditionalInfoVO.getFixedBillCycle();
        if( fixedBillCycleVo.isPresent() && fixedBillCycleVo.get().getNextBillDate() != null ) {
            FixedBillCycle fixedBillCycle = new FixedBillCycle();
            fixedBillCycle.setCycleLengthDays( fixedBillCycleVo.get().getCycleLengthDays() );
            fixedBillCycle.setNextBillDate( fixedBillCycleVo.get().getNextBillDate().toDate() );
            tchiboAdditionalInfo.setFixedBillCycle( fixedBillCycle );
        }
        BillType billType = tchiboAdditionalInfoVO.getBillType();
        if( billType != null ) {
            tchiboAdditionalInfo.setBillType( BillTypeEnum.fromValue( billType.getValue() ) );
        }
        return tchiboAdditionalInfo;
    }

    private static PersonalData setPersonalData( PersonalDataVo persoDataVO ) {
        PersonalData personalData = new PersonalData();
        if( persoDataVO.getAddressDataVo() != null ) {
            personalData.setAddressData( convertAddressData( persoDataVO.getAddressDataVo() ) );
        }
        personalData.setBirthDate( persoDataVO.getBirthDate() );
        personalData.setContactPhone( persoDataVO.getContactPhone() );
        personalData.setFirstName( persoDataVO.getFirstName() );
        personalData.setLastName( persoDataVO.getLastName() );

        EmailAddressWithValidation email = new EmailAddressWithValidation();
        email.setValue( persoDataVO.getEmail() );
        email.setValidated( persoDataVO.isEmailValidated().orNull() );
        personalData.setEmail( email );

        if( persoDataVO.getGender() == Salutation.FRAU
                || persoDataVO.getGender() == Salutation.HERR
                || persoDataVO.getGender() == Salutation.FIRMA ) {
            personalData.setGender( GenderEnum.fromValue( persoDataVO.getGender().getValue() ) );
        }
        if( persoDataVO.getNationality() != null ) {
            personalData.setNationality( persoDataVO.getNationality() );
        }
        personalData.setTitle( persoDataVO.getTitle() );
        return personalData;
    }

    /**
     * SR-38007 AC-728 This method is used to set response of ChangeCustomerCommChannelResponse to
     * ChangeCustomerCommChannelResult
     */
    public ChangeCustomerCommChannelResult convertChangeCustomerCommChannelResponse(
            CustomerCareServicesResponseVo responseVO ) {
        return fillPPITCustomerCareServicesResponse( responseVO, new ChangeCustomerCommChannelResult() );
    }

    /**
     * SR-SR38007 AC-AC753 This method is used to set response of convertGetTariffChangeHistoryResponse to
     * GetTariffChangeHistoryResult
     */
    public GetTariffChangeHistoryResult convertGetTariffChangeHistoryResponse( CustomerCareServicesResponseVo responseVO ) {

        List<TariffHistory> tariffHistoryList = convertToTariffHistory( responseVO );
        GetTariffChangeHistoryResult result = fillPPITCustomerCareServicesResponse( responseVO,
            new GetTariffChangeHistoryResult() );
        result.getTariffHistory().addAll( tariffHistoryList );
        return result;
    }

    private static List<TariffHistory> convertToTariffHistory( CustomerCareServicesResponseVo responseVO ) {
        List<TariffHistory> tariffHistoryList = newArrayList();
        if( !( responseVO instanceof GetTariffChangeHistoryResponseVO ) ) {
            return tariffHistoryList;
        }
        GetTariffChangeHistoryResponseVO getTariffChangeHistoryResponseVO = (GetTariffChangeHistoryResponseVO) responseVO;
        for( TariffChangeHistoryEntryVO tariffChangeHistoryEntryVO : getTariffChangeHistoryResponseVO.getTariffHistoryList() ) {
            if( tariffChangeHistoryEntryVO != null && tariffChangeHistoryEntryVO.getNewTariff() != null ) {
                TariffHistory tariffHistory = new TariffHistory();
                tariffHistory.setTariffID( String.valueOf( tariffChangeHistoryEntryVO.getNewTariff().getTariffId() ) );
                tariffHistory.setTariffName( tariffChangeHistoryEntryVO.getNewTariff().getDescription() );
                tariffHistory.setFee( tariffChangeHistoryEntryVO.getFee() );
                tariffHistory.setAgent( tariffChangeHistoryEntryVO.getUserName() );
                tariffHistory.setComment( tariffChangeHistoryEntryVO.getAgentComment() );
                tariffHistory.setAction( RequestReasonType.getDescriptionTruncated( tariffChangeHistoryEntryVO.getType() ) );
                Date createDate = tariffChangeHistoryEntryVO.getCreateDate();
                tariffHistory.setEventDateTime( createDate );
                tariffHistory.setTariffState( CustomerCareConverter.getTariffChangeHistoryStatus( tariffChangeHistoryEntryVO ) );
                tariffHistoryList.add( tariffHistory );
            }
        }
        return tariffHistoryList;
    }

    public GetLastKnownQoSInformationResult convertGetLastKnownQosInformationResponse(
            CustomerCareServicesResponseVo responseVO ) {
        GetLastKnownQoSInformationResult response = fillPPITCustomerCareServicesResponse( responseVO,
            new GetLastKnownQoSInformationResult() );

        if( responseVO instanceof GetLastKnownQoSInformationResponseVO ) {
            QoSInformationVo qoSInformationVo = ( (GetLastKnownQoSInformationResponseVO) responseVO ).getQoSInformation();
            QoSInformation qoSInformation = convertQoSInformation( qoSInformationVo );
            response.setQoSInformation( qoSInformation );
        }

        return response;
    }

    public CreateCrmOrderResult convertCreateCrmOrderResponse( CustomerCareServicesResponseVo responseVO ) {
        CreateCrmOrderResult result = fillPPITCustomerCareServicesResponse( responseVO, new CreateCrmOrderResult() );
        if( responseVO instanceof CrmOrderResponseVO ) {
            CrmOrderResponseVO crmResponseVo = (CrmOrderResponseVO) responseVO;
            result.setOrderId( crmResponseVo.getOrderId() );
            result.setClientOrderId( crmResponseVo.getClientOrderId() );
            result.getProductActionResult().addAll( convertProductActionResult( crmResponseVo.getProductActionResult() ) );
            result.setRegisterCustomerActionResult( convertRegistrationActionResult( crmResponseVo.getRegistrationActionResult() ) );
            result.setRegisterDirectDebitActionResult( convertRegisterDirectDebitActionResult( crmResponseVo
                .getRegisterDirectDebitActionResult() ) );
            result.setShipSimActionResult( convertShipSimActionResult( crmResponseVo.getShipSimActionResultVo() ) );
        }
        return result;
    }

    private AddressResult convertAddressResult( Optional<AddressDataVo> normalizedAddress, List<AddressDataVo> proposedAddresses ) {
        AddressResult addressResult = null;
        if( normalizedAddress.isPresent() ) {
            addressResult = new AddressResult();
            addressResult.setCorrectedAddress( convertAddressData( normalizedAddress.get() ) );
        } else if( !ListUtils.isNullOrEmpty( proposedAddresses ) ) {
            addressResult = new AddressResult();
            addressResult.setAddressCorrectionCandidates( convertProposedAddresses( proposedAddresses ) );
        }
        return addressResult;
    }

    private ShipSimActionResult convertShipSimActionResult( ShipSimActionResultVo shipSimActionResultVo ) {
        if( shipSimActionResultVo == null ) {
            return null;
        }
        ShipSimActionResult result = new ShipSimActionResult();

        AddressResult addressResult = convertAddressResult( shipSimActionResultVo.getNormalizedAddress(),
            shipSimActionResultVo.getProposedAddresses() );
        result.setAddressCheckResult( addressResult );
        result.setActionItemId( shipSimActionResultVo.getActionItemId() );
        result.setResultCode( ResultCodeEnum.fromValue( shipSimActionResultVo.getResultCode().getValue() ) );
        result.setReasonMsg( shipSimActionResultVo.getReasonMsg() );

        return result;
    }

    private RegisterDirectDebitActionResult convertRegisterDirectDebitActionResult(
            RegisterDirectDebitActionResultVo registerDebitActionResult ) {
        if( registerDebitActionResult == null ) {
            return null;
        }
        RegisterDirectDebitActionResult result = new RegisterDirectDebitActionResult();
        convertRegistrationActionResult( registerDebitActionResult, result );

        Optional<AddressDataVo> normalizedThirdPartyAddress = registerDebitActionResult.getNormalizedThirdPartyAddress();
        AddressResult addressResult = null;
        if( normalizedThirdPartyAddress.isPresent() ) {
            addressResult = new AddressResult();
            addressResult.setCorrectedAddress( convertAddressData( normalizedThirdPartyAddress.get() ) );
        } else {
            List<AddressDataVo> proposedThirdPartyAddresses = registerDebitActionResult.getProposedThirdPartyAddresses();
            if( !ListUtils.isNullOrEmpty( proposedThirdPartyAddresses ) ) {
                addressResult = new AddressResult();
                addressResult.setAddressCorrectionCandidates( convertProposedAddresses( proposedThirdPartyAddresses ) );
            }
        }
        result.setThirdPartyAddressCheckResult( addressResult );
        return result;
    }

    private RegistrationActionResult convertRegistrationActionResult( RegistrationActionResultVo registrationActionResult ) {
        if( registrationActionResult == null ) {
            return null;
        }

        return convertRegistrationActionResult( registrationActionResult, new RegistrationActionResult() );
    }

    private RegistrationActionResult convertRegistrationActionResult( RegistrationActionResultVo registrationActionResult,
            RegistrationActionResult result ) {
        result.setActionItemId( registrationActionResult.getActionItemId() );
        result.setReasonMsg( truncateToMaxLength( registrationActionResult.getReasonMsg(), "reasonMsg", 2048 ) );
        result.setResultCode( ResultCodeEnum.fromValue( registrationActionResult.getResultCode().getValue() ) );

        AddressResult addressResult = convertAddressResult( registrationActionResult.getNormalizedAddress(),
            registrationActionResult.getProposedAddresses() );
        result.setAddressCheckResult( addressResult );

        return result;
    }

    public ValidateCrmOrderResult convertValidateCrmOrderResponse( ValidateCrmOrderResponseVo responseVO ) {
        ValidateCrmOrderResult result = fillPPITCustomerCareServicesResponse( responseVO, new ValidateCrmOrderResult() );
        result.setSuggestedProducts( ProductResponseConverterV24.createAvailableProductsList( responseVO.getSuggestedProducts() ) );
        result.getProductActionResult().addAll( convertProductActionResult( responseVO.getProductActionResults() ) );
        return result;
    }

    private List<ProductActionResult> convertProductActionResult( List<ProductActionResultVO> productActionResult ) {
        List<ProductActionResult> convertedActions = Lists.newArrayList();
        if( !ListUtils.isNullOrEmpty( productActionResult ) ) {
            for( ProductActionResultVO innerAction : productActionResult ) {
                ProductActionResult action = new ProductActionResult();
                action.setActionItemId( innerAction.getActionItemId() );
                action.setReasonMsg( truncateToMaxLength( innerAction.getReasonMsg(), "reasonMsg", 2048 ) );
                action.setResultCode( ResultCodeEnum.fromValue( innerAction.getResultCode().getValue() ) );
                convertedActions.add( action );
            }
        }
        return convertedActions;
    }

    private static String truncateToMaxLength( String value, String fieldName, int maxLength ) {
        if( value != null && value.length() > maxLength ) {
            log.warn( String.format(
                "Length of value (%d) exceeds length limit defined in XSD for field '%s', truncating to max length (%d)", value.length(),
                fieldName, maxLength ) );
            return value.substring( 0, maxLength );
        }
        return value;
    }

    public UpdateFrontendRegistrationDateResult convertUpdateFrontendRegistrationDate(
            CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new UpdateFrontendRegistrationDateResult() );
    }

    public GetHandsetDelockDataResult convertGetHandsetDelockDataResult( CustomerCareServicesResponseVo responseVo ) {
        GetHandsetDelockDataResult result = fillPPITCustomerCareServicesResponse( responseVo, new GetHandsetDelockDataResult() );
        if( responseVo instanceof GetHandsetDelockDataResponseVo ) {
            result
                .setHandsetDelockData( convertHandsetDelockData( ( (GetHandsetDelockDataResponseVo) responseVo ).getHandsetDelockData() ) );
        }
        return result;
    }

    private HandsetDelockData convertHandsetDelockData( @Nullable HandsetDelockDataVo data ) {
        if( data == null ) {
            return null;
        }
        Reject.ifNull( data.getSimLockExpiryDate(), "SimLockExpiry date must not be null if handsetDelockData is present." );
        HandsetDelockData result = new HandsetDelockData();
        result.setDelockCode( data.getDelockCode() );
        result.setHandsetModel( data.getHandsetModel() );
        result.setSimLockExpiryDate( data.getSimLockExpiryDate() );
        return result;
    }

    public ChangeBankAccountResult convertChangeBankAccountResponse( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new ChangeBankAccountResult() );
    }

    public ActivateContractResult convertActivateContractResponse( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new ActivateContractResult() );
    }

    public ActivateReplacementSimResult convertActivateReplacementSimResponse( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new ActivateReplacementSimResult() );
    }

    public ConfirmSepaMandateResult convertConfirmSepaMandateResponse( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new ConfirmSepaMandateResult() );
    }

    public DeregisterPaymentMethodResult convertDeregisterPaymentMethodResponse( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new DeregisterPaymentMethodResult() );
    }

    public NotifyAboutSuccessfulReverificationResult convertNotifyAboutSuccessfulReverificationResponse(
            CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new NotifyAboutSuccessfulReverificationResult() );
    }

    public boolean convertVerifyAvailabilityResponse( CustomerCareServicesResponseVo responseVo ) {
        if( responseVo instanceof CustomerCareServicesResponseWithAvailabilityVo ) {
            CustomerCareServicesResponseWithAvailabilityVo customerCareServicesResponseWithAvailabilityVo = (CustomerCareServicesResponseWithAvailabilityVo) responseVo;
            return customerCareServicesResponseWithAvailabilityVo.isAvailable();
        }
        return true;
    }

    public ResetRegistrationDataResult convertResetRegistrationDataResponse( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new ResetRegistrationDataResult() );
    }

    public ModifyRegistrationDataResult convertModifyRegistrationDataResult( CustomerCareServicesResponseVo responseVo ) {
        return fillPPITCustomerCareServicesResponse( responseVo, new ModifyRegistrationDataResult() );
    }

    private IdAddressData convertIdAddress( Optional<IdAddressDataVo> idAddressVo ) {
        if( idAddressVo == null || !idAddressVo.isPresent() ) {
            return null;
        }
        IdAddressData idAddressData = new IdAddressData()
            .withStreet( idAddressVo.get().getStreet() )
            .withCity( idAddressVo.get().getCity() )
            .withCountry( ValueObjectUtil.getValueOrNull( idAddressVo.get().getCountryCode() ) )
            .withHouseNumber( idAddressVo.get().getHouseNumber() )
            .withZipCode( idAddressVo.get().getZipCode() );
        return idAddressData;
    }

    private IdDocumentTypeIncludingUnknown convertIdDocumentType( IdVerificationDocumentType idVerificationDocumentType ) {
        if( idVerificationDocumentType == null ) {
            return null;
        }
        switch( idVerificationDocumentType ) {
            case BLUE_CARD_EU:
                return IdDocumentTypeIncludingUnknown.BLUE_CARD_EU;
            case DIPLOMATIC_PASSPORT:
                return IdDocumentTypeIncludingUnknown.DIPLOMATIC_PASSPORT;
            case FOREIGN_ID_CARD:
                return IdDocumentTypeIncludingUnknown.FOREIGN_ID_CARD;
            case FOREIGN_PASSPORT:
                return IdDocumentTypeIncludingUnknown.FOREIGN_PASSPORT;
            case GERMAN_ID_CARD:
                return IdDocumentTypeIncludingUnknown.GERMAN_ID_CARD;
            case GERMAN_PASSPORT:
                return IdDocumentTypeIncludingUnknown.GERMAN_PASSPORT;
            case OFFICIAL_PASSPORT:
                return IdDocumentTypeIncludingUnknown.OFFICIAL_PASSPORT;
            case PERMANENT_EC_RESIDENCE:
                return IdDocumentTypeIncludingUnknown.PERMANENT_EC_RESIDENCE;
            case REGISTRATION_FOR_ASYLUM:
                return IdDocumentTypeIncludingUnknown.REGISTRATION_FOR_ASYLUM;
            case REPLACEMENT_ID_CARD:
                return IdDocumentTypeIncludingUnknown.REPLACEMENT_ID_CARD;
            case RESIDENCE_PERMIT:
                return IdDocumentTypeIncludingUnknown.RESIDENCE_PERMIT;
            case SUSPENSION_OF_DEPORTATION:
                return IdDocumentTypeIncludingUnknown.SUSPENSION_OF_DEPORTATION;
            case TEMPORARY_DIPLOMATIC_PASSPORT:
                return IdDocumentTypeIncludingUnknown.TEMPORARY_DIPLOMATIC_PASSPORT;
            case TEMPORARY_ID_CARD:
                return IdDocumentTypeIncludingUnknown.TEMPORARY_ID_CARD;
            case TEMPORARY_OFFICIAL_PASSPORT:
                return IdDocumentTypeIncludingUnknown.TEMPORARY_OFFICIAL_PASSPORT;
            case TEMPORARY_PASSPORT:
                return IdDocumentTypeIncludingUnknown.TEMPORARY_PASSPORT;
            case TEMPORARY_RESIDENCE_PERMIT:
                return IdDocumentTypeIncludingUnknown.TEMPORARY_RESIDENCE_PERMIT;
            case UNLIMITED_SETTLEMENT_PERMIT:
                return IdDocumentTypeIncludingUnknown.UNLIMITED_SETTLEMENT_PERMIT;
            case VISA:
                return IdDocumentTypeIncludingUnknown.VISA;
            case ID_CARD:
                return IdDocumentTypeIncludingUnknown.GENERIC_ID_CARD;
            case PASSPORT:
                return IdDocumentTypeIncludingUnknown.GENERIC_PASSPORT;
            case OTHER_PASSPORT:
                return IdDocumentTypeIncludingUnknown.GENERIC_OTHER_PASSPORT;
            case FOREIGN_DOCUMENT:
                return IdDocumentTypeIncludingUnknown.GENERIC_FOREIGN_DOCUMENT;
            case RESIDENCE_DOCUMENT:
                return IdDocumentTypeIncludingUnknown.GENERIC_RESIDENCE_PERMIT;
            case UNKNOWN:
                return IdDocumentTypeIncludingUnknown.UNKNOWN;
            default:
                throw Reject.always( "Unknown idVerificationDocumentType: " + idVerificationDocumentType );
        }
    }

    private IdDocumentForReading convertIdDocument( IdDocumentVo idDocumentVo ) {
        if( idDocumentVo == null ) {
            return null;
        }
        IdDocumentForReading idDocument = new IdDocumentForReading();
        idDocument.setAddress( convertIdAddress( idDocumentVo.getIdAddressData() ) );
        idDocument.setDocumentNumber( ValueObjectUtil.getValueOrNull( idDocumentVo.getDocumentNumber() ) );
        idDocument.setDocumentType( convertIdDocumentType( idDocumentVo.getDocumentType() ) );
        idDocument.setIssuingBody( ValueObjectUtil.getValueOrNull( idDocumentVo.getIdIssuingBody() ) );
        return idDocument;
    }

    public GetCustomerDataForDataPortabilityResult convertGetCustomerDataForDataPortabilityResponse(
            CustomerCareServicesResponseVo responseVo ) {
        GetCustomerDataForDataPortabilityResult result = fillPPITCustomerCareServicesResponse( responseVo,
            new GetCustomerDataForDataPortabilityResult() );
        if( responseVo instanceof GetCustomerDataForDataPortabilityResponseVo ) {
            GetCustomerDataForDataPortabilityResponseVo resultVO = (GetCustomerDataForDataPortabilityResponseVo) responseVo;

            MasterDataForDataPortability masterData = createMasterDataForDataPortability( resultVO );
            result.setMasterData( masterData );

            EvnDataForDataPortability evnData = createEvnDataForDataPortability( resultVO );
            result.setEvnData( evnData );
            TopUpDataForDataPortability topUpData = createTopUpDataForDataPortability( resultVO );
            result.setTopUpData( topUpData );
        } else {
            result.setTopUpData( new TopUpDataForDataPortability() );
        }
        return result;
    }

    private MasterDataForDataPortability createMasterDataForDataPortability( GetCustomerDataForDataPortabilityResponseVo resultVO ) {
        MasterDataForDataPortability masterData = new MasterDataForDataPortability();
        masterData.setTariffInfo( convertTariffInfoForDataPortability( resultVO.getTariffInfo() ) );
        masterData.setSelectedOptions( resultVO.getSelectedRechargeOptions() == null ? null
                : convertSelectedOptionsVo( resultVO
                    .getSelectedRechargeOptions() ) );
        masterData.setDirectDebitRegistrationState( convertDirectDebitStatus( resultVO.getDirectDebitStatus() ) );
        masterData.setPersonalData( resultVO.getPersonalDataVo() == null ? null : setPersonalData( resultVO.getPersonalDataVo() ) );
        masterData.setIdDocument( convertIdDocument( resultVO.getIdDocumentVo() ) );

        BankAccountDataForDataPortability bankAccountCustomerData = resultVO.getDirectDebitBankAccountVo() == null ? null
                : (BankAccountDataForDataPortability) convertBankAccount( resultVO.getDirectDebitBankAccountVo(), resultVO.getCreditorId(),
                    true );
        if( bankAccountCustomerData != null && resultVO.getThirdPartyBankAccountOwnerVo() != null ) {
            bankAccountCustomerData.setThirdPartyAccountOwner( convertThirdPartyAccountOwner( resultVO
                .getThirdPartyBankAccountOwnerVo() ) );
        }
        masterData.setBankAccount( bankAccountCustomerData );

        masterData.setPermitsCallStore( convertCallStorePermission( resultVO.getCallStorePermission() ) );
        masterData.setShippingAddress( convertShippingAddressVo( resultVO.getShippingAddress() ) );
        masterData.setPackSubscriptions( convertPackSubscriptionsVo( resultVO.getPackSubscriptions() ) );
        masterData.setEmailVerificationStatus( convertEmailVerificationStatus( resultVO.getEmailVerificationStatusVo() ) );

        return masterData;
    }

    private EvnDataForDataPortability createEvnDataForDataPortability( GetCustomerDataForDataPortabilityResponseVo resultVO ) {
        EvnDataForDataPortability evnData = new EvnDataForDataPortability();
        List<EvnRecordForDataPortability> evnRecords = emptyList();
        if( resultVO.getEvnData() != null ) {
            evnRecords = FluentIterable.from( resultVO.getEvnData() )
                .transform( new Function<EvnRecordVo, EvnRecordForDataPortability>() {
                    @Override
                    public EvnRecordForDataPortability apply( EvnRecordVo input ) {
                        return convertEvnRecordVo( input );
                    }
                } ).toList();
        }
        return evnData.withEvnRecord( evnRecords );
    }

    private EvnRecordForDataPortability convertEvnRecordVo( EvnRecordVo evnRecordVo ) {
        EvnRecordForDataPortability evnRecordForDataPortability = new EvnRecordForDataPortability();
        evnRecordForDataPortability.setDuration( evnRecordVo.getDuration() );
        evnRecordForDataPortability.setServiceType( PackServiceTypeEnum.fromValue( evnRecordVo.getServiceType().getValue() ) );
        evnRecordForDataPortability.setTelephoneNumber( evnRecordVo.getTelephoneNumber() );
        evnRecordForDataPortability.setUsageDateTimeString( DateUtil.formatXsDateTime( evnRecordVo.getUsageDateTime() ) );
        return evnRecordForDataPortability;
    }

    private PackSubscriptionsForDataPortability convertPackSubscriptionsVo( List<PackSubscriptionForDataPortabilityVo> packSubscriptions ) {
        if( packSubscriptions == null ) {
            return null;
        }
        PackSubscriptionsForDataPortability packSubscriptionsForDataPortability = new PackSubscriptionsForDataPortability();
        List<PackSubscriptionForDataPortability> packSubscription = FluentIterable.from( packSubscriptions ).transform(
            new Function<PackSubscriptionForDataPortabilityVo, PackSubscriptionForDataPortability>() {
                @Override
                public PackSubscriptionForDataPortability apply( PackSubscriptionForDataPortabilityVo input ) {
                    PackSubscriptionForDataPortability packSubscriptionForDataPortability = new PackSubscriptionForDataPortability();
                    packSubscriptionForDataPortability.setProductId( input.getProductId().getId() );
                    packSubscriptionForDataPortability.setCustomerPackDesc( input.getCustomerPackDescription() );
                    return packSubscriptionForDataPortability;
                }
            } ).toList();
        packSubscriptionsForDataPortability.withPackSubscription( packSubscription );
        return packSubscriptionsForDataPortability;
    }

    private CrmShippingAddress convertShippingAddressVo( ShippingAddressVo shippingAddressVo ) {
        if( shippingAddressVo == null ) {
            return null;
        }
        return new CrmShippingAddress()
            .withAddressQuality( convertDataCheckQuality( shippingAddressVo.getAddressQuality() ) )
            .withFirstName( shippingAddressVo.getFirstName() )
            .withLastName( shippingAddressVo.getLastName() )
            .withGender( convertSalutation( shippingAddressVo.getGender().orNull() ) )
            .withTitle( convertTitle( shippingAddressVo.getTitle().orNull() ) )
            .withCompany( shippingAddressVo.getCompany().orNull() )
            .withBranch( shippingAddressVo.getBranch().orNull() )
            .withStreet( shippingAddressVo.getStreet() )
            .withHouseNumber( shippingAddressVo.getHouseNumber() )
            .withCity( shippingAddressVo.getCity() )
            .withZipCode( shippingAddressVo.getZipCode() )
            .withCountry( shippingAddressVo.getCountryCode() );
    }

    private TopUpDataForDataPortability createTopUpDataForDataPortability( GetCustomerDataForDataPortabilityResponseVo resultVO ) {
        TopUpDataForDataPortability topUpData = new TopUpDataForDataPortability();

        if( resultVO.getTopUpData() == null ) {
            return topUpData.withTopUpRecord( Collections.<TopUpRecordForDataPortability>emptyList() );
        }

        List<TopUpRecordForDataPortability> topUpRecords = FluentIterable.from( resultVO.getTopUpData() )
            .transform( new Function<TopUpRecordForDataPortabilityVo, TopUpRecordForDataPortability>() {
                @Override
                public TopUpRecordForDataPortability apply( TopUpRecordForDataPortabilityVo input ) {
                    return convertTopUpRecordVo( input );
                }
            } ).toList();

        return topUpData.withTopUpRecord( topUpRecords );
    }

    private TopUpRecordForDataPortability convertTopUpRecordVo( TopUpRecordForDataPortabilityVo topUpRecordVo ) {
        TopUpRecordForDataPortability topUpRecordForDataPortability = new TopUpRecordForDataPortability();
        topUpRecordForDataPortability.setChargeAmount( (int) topUpRecordVo.getChargeAmount() );
        topUpRecordForDataPortability.setMsisdn( topUpRecordVo.getMsisdn().getValue() );
        topUpRecordForDataPortability.setRequestDate( topUpRecordVo.getRequestDate() );
        return topUpRecordForDataPortability;
    }

    private DataCheckQualityEnum convertDataCheckQuality( DataCheckQuality dataCheckQuality ) {
        if( dataCheckQuality == null ) {
            return null;
        }

        switch( dataCheckQuality ) {
            case UNCHECKED:
                return DataCheckQualityEnum.UNCHECKED;
            case CHECKED_VALID:
                return DataCheckQualityEnum.CHECKED_VALID;
            case CHECKED_UNKNOWN:
                return DataCheckQualityEnum.CHECKED_UNKNOWN;
            default:
                throw Reject.always( "Unknown dataCheckQuality :" + dataCheckQuality );
        }
    }

    private GenderEnum convertSalutation( Salutation salutation ) {
        if( salutation == null ) {
            return null;
        }

        switch( salutation ) {
            case HERR:
            case FRAU:
            case FIRMA:
                return GenderEnum.fromValue( salutation.getValue() );
            case NONE:
                return null;
            default:
                throw Reject.always( "Unknown salutation :" + salutation );
        }
    }

    private TitleEnum convertTitle( TitleForLapi title ) {
        if( title == null ) {
            return null;
        }

        switch( title ) {
            case DOCTOR:
                return TitleEnum.DOCTOR;
            case PROFESSOR:
                return TitleEnum.PROFESSOR;
            case NONE:
                return null;
            default:
                throw Reject.always( "Unknown title :" + title );
        }
    }

    private static TariffInfo convertTariffInfoForDataPortability( TariffInfoVO tariffInfoVo ) {
        TariffInfo tariffInfo = convertTariffInfo( tariffInfoVo );

        if( tariffInfo != null && tariffInfo.getTariffProductId() == null ) {
            tariffInfo.setTariffProductId( "" );
        }

        return tariffInfo;
    }

    public GetPreContractualInformationResult convertGetPreContractualInformationResult( CustomerCareServicesResponseVo responseVo ) {
        GetPreContractualInformationResult result = fillPPITCustomerCareServicesResponse( responseVo,
            new GetPreContractualInformationResult() );
        if( responseVo instanceof GetPreContractualInformationResultVo ) {
            GetPreContractualInformationResultVo resultVO = (GetPreContractualInformationResultVo) responseVo;
            result.setServiceResponse( createServiceResponse( resultVO ) );
            result.setResultCode( ResultCodeEnum.fromValue( resultVO.getResultCodeValue() ) );
            result.setReasonMsg( resultVO.getReasonMsg() );
            GetPreContractualInformationResult.Products products = new GetPreContractualInformationResult.Products();
            result.setProducts( products.withProductId( convertProductIdtoString( resultVO.getProducts() ) ) );
        }
        return result;
    }

    private List<String> convertProductIdtoString( List<ProductId> listOfProductId ) {
        List<String> pId = new ArrayList<>();
        if( listOfProductId != null ) {
            for( ProductId productId : listOfProductId ) {
                if( productId != null )
                    pId.add( productId.getId() );
            }
        }
        return pId;
    }

    public GetKittedProductsResult convertGetKittedProductsResult( CustomerCareServicesResponseVo responseVo ) {
        GetKittedProductsResult result = fillPPITCustomerCareServicesResponse( responseVo, new GetKittedProductsResult() );
        if( responseVo instanceof GetKittedProductsResultVo ) {
            GetKittedProductsResultVo resultVO = (GetKittedProductsResultVo) responseVo;
            result.setServiceResponse( createServiceResponse( resultVO ) );
            result.setResultCode( ResultCodeEnum.fromValue( resultVO.getResultCodeValue() ) );
            result.setReasonMsg( resultVO.getReasonMsg() );

            result.setPacks( convertPacks( resultVO.getPackId() ) );
            result.setTariffID( resultVO.getTariffID() );
        }
        return result;
    }

    private GetKittedProductsResult.Packs convertPacks( List<String> listOfPackIds ) {
        GetKittedProductsResult.Packs packs = new GetKittedProductsResult.Packs();
        List<String> packIds = new ArrayList<>( listOfPackIds );
        packs.withPackId( packIds );
        return packs;
    }

    public GetNonEECCRelevantProductsForBrandResult convertGetNonEECCRelevantProductsForBrandResult(
            CustomerCareServicesResponseVo responseVo ) {
        GetNonEECCRelevantProductsForBrandResult result = fillPPITCustomerCareServicesResponse( responseVo,
            new GetNonEECCRelevantProductsForBrandResult() );
        if( responseVo instanceof GetNonEECCRelevantProductsForBrandResultVo ) {
            GetNonEECCRelevantProductsForBrandResultVo resultVO = (GetNonEECCRelevantProductsForBrandResultVo) responseVo;
            result.setServiceResponse( createServiceResponse( resultVO ) );
            result.setResultCode( ResultCodeEnum.fromValue( resultVO.getResultCodeValue() ) );
            result.setReasonMsg( resultVO.getReasonMsg() );

            GetNonEECCRelevantProductsForBrandResult.Products products = new GetNonEECCRelevantProductsForBrandResult.Products();
            result.setProducts( products.withProductId( convertProductIdtoString( resultVO.getProductId() ) ) );
        }
        return result;
    }

    public RequestEmailAddressPerSmsResult convertRequestEmailAddressPerSmsResult( CustomerCareServicesResponseVo responseVo ) {
        RequestEmailAddressPerSmsResult result = fillPPITCustomerCareServicesResponse( responseVo, new RequestEmailAddressPerSmsResult() );
        if( responseVo instanceof RequestEmailAddressPerSmsResultVo ) {
            RequestEmailAddressPerSmsResultVo resultVO = (RequestEmailAddressPerSmsResultVo) responseVo;

            result.setServiceResponse( createServiceResponse( resultVO ) );
            result.setResultCode( ResultCodeEnum.fromValue( resultVO.getResultCodeValue() ) );
            result.setReasonMsg( resultVO.getReasonMsg() );
        }

        return result;
    }
}