package com.telefonica.prepaid.frontend.customercare.service;

import com.techmahindra.prepaid.prepaiditcustomercareservices.ActivateDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.BarUnbarAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelFailedPortingOutOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelPortingInOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeBankAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCLIPorCLIRRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerCommChannelRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeSIMRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeTariffRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeVoiceMailboxPINRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeWhoCalledServiceRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreateCrmOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreatePortingDeclarationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeactivateAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeactivateDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeleteBundleRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeletePackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ExportAccountContactHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAccountBalanceRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailableBundlesRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailablePacksRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailableTariffRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetChurnCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentOrAvailableProductsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentPacksRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentTariffRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDirectDebitRechargeOptionsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetHandsetDelockDataRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetLastKnownQoSInformationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPackCounterStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPackHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPartnerBenefitPackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortInStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortingOutStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPreferredCommunicationChannelRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMStatisticsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetTariffChangeHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ImportAccountContactHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.NotifyAboutBankTransactionLegacyRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.PrepareClawbackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.QueryCustomersRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResetAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResubmitPortingDateRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SimValidationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.StoreFailedRechargeAttemptRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SubscribeBundleRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SubscribePackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UnsubscribePackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdateFrontendRegistrationDateRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingDeclarationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingInOrderRequestVO;

import com.telefonica.prepaid.external.customercare.domain.ApplyCreditDebitRequestVo;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesRequestVo;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesResponseVo;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderRequestVo;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.ActivateReplacementSimRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ConfirmSepaMandateRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.DeregisterPaymentMethodRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCrdInformationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCustomerDataForDataPortabilityRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetDynamicCustomerDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetEGNDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ModifyRegistrationDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.NotifyAboutSuccessfulReverificationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.NotifyCustomerDirectDebitLimitExceededLegacyRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.RequestEmailAddressPerSmsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetKittedProductsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetNonEECCRelevantProductsForBrandRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetPreContractualInformationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ResetRegistrationDataRequestVo;
import com.telefonica.prepaid.prepaiditcustomercareservices.ActivateContractRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetBrandConfigurationRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetCurrentBundleRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.SearchTenantBrandAssignmentRequestVO;
import com.telefonica.prepaid.usage.GetTopUpsRequestVo;

public interface CustomerCareServices {
    CustomerCareServicesResponseVo importAccountContactHistory( ImportAccountContactHistoryRequestVO requestVO );

    CustomerCareServicesResponseVo exportAccountContactHistory( ExportAccountContactHistoryRequestVO requestVO );

    CustomerCareServicesResponseVo getSIMInfo( CustomerCareServicesRequestVo requestVO );

    CustomerCareServicesResponseVo applyCreditDebit( ApplyCreditDebitRequestVo requestVO );

    CustomerCareServicesResponseVo getAccountBalance( GetAccountBalanceRequestVO requestVO );

    CustomerCareServicesResponseVo getAvailablePacks( GetAvailablePacksRequestVO requestVO );

    CustomerCareServicesResponseVo validateSim( SimValidationRequestVO requestVO );

    /**
     * @deprecated can only be used for CC versions < 11
     */
    @Deprecated
    CustomerCareServicesResponseVo deletePack( DeletePackRequestVO requestVO );

    CustomerCareServicesResponseVo getPackHistory( GetPackHistoryRequestVO requestVO );

    /**
     * @deprecated can only be used for CC versions < 11
     */
    @Deprecated
    CustomerCareServicesResponseVo subscribePack( SubscribePackRequestVO requestVO );

    /**
     * @deprecated can only be used for CC versions < 11
     */
    @Deprecated
    CustomerCareServicesResponseVo unsubscribePack( UnsubscribePackRequestVO requestVO );

    CustomerCareServicesResponseVo changeCLIPorCLIR( ChangeCLIPorCLIRRequestVO requestVO );

    CustomerCareServicesResponseVo changeVoiceMailboxPIN( ChangeVoiceMailboxPINRequestVO changeVoiceMailboxPINRequestVO );

    CustomerCareServicesResponseVo changeWhoCalledService( ChangeWhoCalledServiceRequestVO changeWhoCalledServiceRequestVO );

    CustomerCareServicesResponseVo barUnbarAccount( BarUnbarAccountRequestVO requestVO );

    CustomerCareServicesResponseVo getPackCounterStatus( GetPackCounterStatusRequestVO getPackCounterStatusRequestVO );

    CustomerCareServicesResponseVo getPortingOutStatus( GetPortingOutStatusRequestVO requestVO );

    CustomerCareServicesResponseVo createPortingDeclaration( CreatePortingDeclarationRequestVO requestVO );

    CustomerCareServicesResponseVo updatePortingDeclaration( UpdatePortingDeclarationRequestVO requestVO );

    CustomerCareServicesResponseVo removePortingDeclaration( CustomerCareServicesRequestVo requestVO );

    CustomerCareServicesResponseVo getPortingDeclaration( CustomerCareServicesRequestVo requestVO );

    CustomerCareServicesResponseVo resubmitPortingDate( ResubmitPortingDateRequestVO requestVO );

    CustomerCareServicesResponseVo resetAccount( ResetAccountRequestVO requestVO );

    CustomerCareServicesResponseVo getPortingInStatus( GetPortInStatusRequestVO requestVO );

    CustomerCareServicesResponseVo updatePortInRequest( UpdatePortingInOrderRequestVO requestVO );

    CustomerCareServicesResponseVo cancelPortInRequest( CancelPortingInOrderRequestVO requestVO,
            boolean performAdditionalValidation );

    CustomerCareServicesResponseVo getEGNData( GetEGNDataRequestVo requestVO );

    CustomerCareServicesResponseVo getTopUps( GetTopUpsRequestVo requestVO );

    CustomerCareServicesResponseVo changeCustomerData( ChangeCustomerDataRequestVO requestVO );

    CustomerCareServicesResponseVo getCustomerData( GetCustomerDataRequestVO requestVO );

    CustomerCareServicesResponseVo showVoicemailboxPINStatus( CustomerCareServicesRequestVo requestVO );

    CustomerCareServicesResponseVo getNetworkServiceStatus( CustomerCareServicesRequestVo requestVO );

    CustomerCareServicesResponseVo getDSSEntry( GetDSSEntryRequestVO requestVO );

    CustomerCareServicesResponseVo activateDSSEntry( ActivateDSSEntryRequestVO requestVO );

    CustomerCareServicesResponseVo getChurnCustomerData( GetChurnCustomerDataRequestVO requestVO );

    CustomerCareServicesResponseVo searchCustomers( QueryCustomersRequestVO requestVO );

    CustomerCareServicesResponseVo changeSIM( ChangeSIMRequestVO changeSIMRequestVO );

    CustomerCareServicesResponseVo getAvailablePacks1( GetAvailablePacksRequestVO requestVO );

    CustomerCareServicesResponseVo getCurrentPacks( GetCurrentPacksRequestVO requestVO );

    CustomerCareServicesResponseVo getSIMHistory( GetSIMHistoryRequestVO getSIMHistoryRequestVO );

    CustomerCareServicesResponseVo getSIMStatistics( GetSIMStatisticsRequestVO simStatisticsRequestVO );

    CustomerCareServicesResponseVo deactivateDSSEntry( DeactivateDSSEntryRequestVO requestVO );

    CustomerCareServicesResponseVo getPreferredCommunicationChannel( GetPreferredCommunicationChannelRequestVO requestVO );

    CustomerCareServicesResponseVo getPartnerBenefitPack( GetPartnerBenefitPackRequestVO requestVO );

    CustomerCareServicesResponseVo deactivateAccount( DeactivateAccountRequestVO requestVO );

    CustomerCareServicesResponseVo changeCustomerCommChannel( ChangeCustomerCommChannelRequestVO requestVO );

    CustomerCareServicesResponseVo changeTariff( ChangeTariffRequestVO changeTariffRequestVO );

    CustomerCareServicesResponseVo getAvailableTariff( GetAvailableTariffRequestVO getAvailableTariffRequestVO );

    CustomerCareServicesResponseVo getTariffChangeHistory( GetTariffChangeHistoryRequestVO getTariffChangeHistoryRequestVO );

    CustomerCareServicesResponseVo cancelFailedPortingOutOrder( CancelFailedPortingOutOrderRequestVO requestVO );

    CustomerCareServicesResponseVo getLastKnownQoSInformation( GetLastKnownQoSInformationRequestVO requestVO );

    CustomerCareServicesResponseVo getCurrentTariff( GetCurrentTariffRequestVO getCurrentTariffRequestVO );

    CustomerCareServicesResponseVo subscribeBundle( SubscribeBundleRequestVo subscribeBundleRequestVO );

    CustomerCareServicesResponseVo getCurrentBundle( GetCurrentBundleRequestVO requestVo );

    CustomerCareServicesResponseVo deleteBundle( DeleteBundleRequestVo deleteBundleRequestVO );

    CustomerCareServicesResponseVo getAvailableBundles( GetAvailableBundlesRequestVo getAvailableBundlesRequestVo );

    CustomerCareServicesResponseVo getAvailableProducts( GetCurrentOrAvailableProductsRequestVO requestVo );

    CustomerCareServicesResponseVo getProductList( GetCurrentOrAvailableProductsRequestVO requestVo );

    /**
     * @deprecated can only be used for CC versions < 19
     */
    @Deprecated
    CustomerCareServicesResponseVo storeFailedRechargeAttempt( StoreFailedRechargeAttemptRequestVO requestVO );

    CustomerCareServicesResponseVo getDynamicCustomerData( GetDynamicCustomerDataRequestVo requestVo );

    CustomerCareServicesResponseVo getCurrentProducts( GetCurrentOrAvailableProductsRequestVO requestVo );

    ValidateCrmOrderResponseVo validateCrmOrder( ValidateCrmOrderRequestVo requestVo );

    CustomerCareServicesResponseVo createCrmOrder( CreateCrmOrderRequestVO requestVo );

    CustomerCareServicesResponseVo updateFrontendRegistrationDate( UpdateFrontendRegistrationDateRequestVo requestVo );

    CustomerCareServicesResponseVo getHandsetDelockData( GetHandsetDelockDataRequestVo requestVo );

    /**
     * @deprecated can only be used for CC versions < 19
     */
    @Deprecated
    CustomerCareServicesResponseVo notifyCustomerDirectDebitLimitExceeded(
            NotifyCustomerDirectDebitLimitExceededLegacyRequestVo requestVo );

    /**
     * @deprecated can only be used for CC versions < 19
     */
    @Deprecated
    CustomerCareServicesResponseVo notifyAboutBankTransaction( NotifyAboutBankTransactionLegacyRequestVo requestVo );

    CustomerCareServicesResponseVo getRechargeOptions( GetDirectDebitRechargeOptionsRequestVO requestVo );

    /**
     * @deprecated can only be used for CC versions < 19
     */
    @Deprecated
    CustomerCareServicesResponseVo prepareClawback( PrepareClawbackRequestVO requestVo );

    CustomerCareServicesResponseVo changeBankAccount( ChangeBankAccountRequestVO requestVo );

    CustomerCareServicesResponseVo getBrandConfiguration( GetBrandConfigurationRequestVO requestVo );

    CustomerCareServicesResponseVo searchTenantBrandAssignment( SearchTenantBrandAssignmentRequestVO requestVo );

    CustomerCareServicesResponseVo activateContract( ActivateContractRequestVO requestVo );

    CustomerCareServicesResponseVo activateReplacementSim( ActivateReplacementSimRequestVo requestVo );

    CustomerCareServicesResponseVo confirmSepaMandate( ConfirmSepaMandateRequestVo requestVo );

    CustomerCareServicesResponseVo verifyAvailability( CustomerCareServicesRequestVo requestVo );

    CustomerCareServicesResponseVo deregisterPaymentMethod( DeregisterPaymentMethodRequestVo requestVo );

    CustomerCareServicesResponseVo resetRegistrationData( ResetRegistrationDataRequestVo requestVO );

    CustomerCareServicesResponseVo notifyAboutSuccessfulReverification( NotifyAboutSuccessfulReverificationRequestVo requestVo );

    CustomerCareServicesResponseVo modifyRegistrationData( ModifyRegistrationDataRequestVo requestVo );

    CustomerCareServicesResponseVo getCrdInformation( GetCrdInformationRequestVo requestVo );

    CustomerCareServicesResponseVo getCustomerDataForDataPortability( GetCustomerDataForDataPortabilityRequestVo requestVo );

    CustomerCareServicesResponseVo getPreContractualInformation( GetPreContractualInformationRequestVo requestVo );

    CustomerCareServicesResponseVo getKittedProducts( GetKittedProductsRequestVo requestVo );

    CustomerCareServicesResponseVo getNonEECCRelevantProductsForBrand( GetNonEECCRelevantProductsForBrandRequestVo requestVo );

    CustomerCareServicesResponseVo requestEmailAddressPerSms( RequestEmailAddressPerSmsRequestVo requestVo );

}
