package com.telefonica.prepaid.customercare;

import de.danet.ta.prepaid.daogen.vendor.dto.Salutation;

public final class PrepaidITCustomerCareServicesConstants {

    public static final String PREPAID_IT_CUSTOMER_CARE_SERVICES_MODULE = "PrepaidITCustomerCareServices";

    public static final String SAS_DISPLAY_PARAM_REQ_TYPE = "1";

    public static final String SAS_SUCCESS_TEXT = "(99999)";

    public static final String SAS_DISPLAY_PARAM_ACTION1_VALUE = "GET_VMS_SETTINGS";

    public static final int STATUS_ON = 1;
    public static final int STATUS_OFF = 0;

    public static final int MAX_DATA_DAYS = 90;
    public static final int MAX_DATA_DAYS_IN_NEGATIVE = -MAX_DATA_DAYS;

    public static final int BARRED = 0;
    public static final int UNBARRED = 1;

    public static final int ENABLE = 0;
    public static final int DISABLE = 1;

    public static final String PARAM_CLIENT_ID = "ClientID";
    public static final String PARAM_TRANSACTION_ID = "TransactionID";
    public static final String PARAM_MSISDN = "MSISDN";
    public static final String PARAM_END_DATE = "EndDate";
    public static final String PARAM_CUST_DATA_PERMIT_CALL_STORE = "Customer data or PermitsCallStore";
    public static final String PARAM_PKK = "PKK";
    public static final String PARAM_EMAIL_ID = "EmailID";
    public static final String PARAM_VO_ID = "VoID";
    public static final String PARAM_PORTING_MSISDN = "PortingMSISDN";
    public static final String PARAM_DONATING_NETWORK_OPERATOR = "DonatingNO";
    public static final String PARAM_DONATING_SERVICE_PROVIDER = "DonatingSP";
    public static final String PARAM_CUST_TYPE = "CustomerType";
    public static final String PARAM_AGENT = "Agent";
    public static final String PARAM_CONTENT_CARD_CODE = "Content Card Code";
    public static final String PARAM_THIRD_PART_ACCOUNT_OWNER = "Third Party Account Owner";
    public static final String PARAM_ACCOUNT_OWNER = "Account Owner";
    public static final String PARAM_SUBSCRIPTION_FEE = "Fee";
    public static final String PARAM_BILL_DAY = "Bill Day";
    public static final String PARAM_BILL_CYCLE = "Bill cycle";
    public static final String PARAM_BILL_DAY_NOT_ALLOWED = "Bill day not allowed if no bill requested";
    public static final String PARAM_BILL_CYCLE_NOT_ALLOWED = "Bill cycle not allowed if no bill requested";
    public static final String PARAM_BILL_CYCLE_AND_BILL_DAY = "Bill cycle and bill day may not be given simultaneously";
    public static final String PARAM_BILL_CYCLE_OR_BILL_DAY_REQUIRED = "Bill cycle or bill day required";
    public static final String PARAM_NEXT_BILL_DATE_MUST_BE_AFTER_LAST_BILL = "Next bill date must be after most recent bill";
    public static final String PARAM_NEXT_BILL_DATE_TOO_FAR_FROM_LAST_BILL = "Next bill date too far from last bill";
    public static final String PARAM_NEXT_BILL_DATE_TOO_FAR_IN_FUTURE = "Next bill too far in future";
    public static final String PARAM_BILL_CYCLE_TOO_SHORT = "Next bill date must be less than bill cycle length in the past";
    public static final String PARAM_SALUTATION = "salutation";
    public static final String PARAM_PRODUCTID = "Product Id";
    public static final int PREFERRED_COMMUNICATION_CHANNEL_DEFAULT = 0;
    public static final String PARAM_CAMPAIGN_NAME = "CampaignName";
    public static final String PARAM_PACK_SERVICE_TYPE = "PackServiceType";
    public static final String PACK_SERVICE_TYPE_SMS = "sms";
    public static final String PACK_SERVICE_TYPE_VOICE = "min";
    public static final String PACK_SERVICE_TYPE_DATA = "mb";
    public static final String REASON = "Reason";
    public static final String PACK_NAME = "PackName";
    public static final String PAYMENT_USE_CASE = "PaymentUseCase";
    public static final String REASON_CODE = "ReasonCode";
    public static final String CLAWBACK_CATEGORY = "ClawbackCategory";

    public static final String QUANTITY = "Quantity";
    public static final String MONETARY = "Monetary";

    public static final String PEPS_SYSTEM_NAME = "PEPS";
    public static final String TCHIBO_SYSTEM_NAME = "HERMES";
    public static final String ICCID = "ICCID";
    public static final String QUESTION = "?";
    public static final String STAR = "*";
    public static final Salutation DEFAULT_GENDER = Salutation.HERR;

    public static final int LENGTH_FOUR = 4;
    public static final int LENGTH_SIX = 6;
    public static final int MIN_AGENT_LENGTH = 3;
    public static final int MAX_AGENT_LENGTH = 24;

    public static final String PARAM_REGISTRATION_CHANNEL = "registrationChannel";
    public static final String PARAM_NATIONALITY = "nationality";
    public static final String PARAM_COUNTRY_CODE = "countryCode";

    public static final String INACTIVE_MSISDN_AFTER_PORTING_IN = "Inactive MSISDN of contract, likely after porting-in";

    private PrepaidITCustomerCareServicesConstants() {}
}
