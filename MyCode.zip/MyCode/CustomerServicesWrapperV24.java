package com.telefonica.prepaid.frontend.customercare.v24;

import static com.telefonica.prepaid.common.tags.UseCaseTags.DeleteBundle;
import static com.telefonica.prepaid.common.tags.UseCaseTags.GetAvailableBundles;
import static com.telefonica.prepaid.common.tags.UseCaseTags.GetAvailableProducts;
import static com.telefonica.prepaid.common.tags.UseCaseTags.GetCurrentBundle;
import static com.telefonica.prepaid.common.tags.UseCaseTags.GetCurrentProducts;
import static com.telefonica.prepaid.common.tags.UseCaseTags.GetProductList;
import static com.telefonica.prepaid.common.tags.UseCaseTags.SubscribeBundle;

import com.techmahindra.prepaid.prepaiditcustomercareservices.ActivateDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.BarUnbarAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelFailedPortingOutOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelPortingInOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeBankAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCLIPorCLIRRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerCommChannelRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeSIMRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeVoiceMailboxPINRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeWhoCalledServiceRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreateCrmOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreatePortingDeclarationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeactivateAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeactivateDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeleteBundleRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ExportAccountContactHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAccountBalanceRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailableBundlesRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetChurnCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentOrAvailableProductsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDirectDebitRechargeOptionsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetHandsetDelockDataRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetLastKnownQoSInformationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPackCounterStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPackHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPartnerBenefitPackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortInStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortingOutStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPreferredCommunicationChannelRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMStatisticsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetTariffChangeHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ImportAccountContactHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.QueryCustomersRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResetAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResubmitPortingDateRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SimValidationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SubscribeBundleRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdateFrontendRegistrationDateRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingDeclarationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingInOrderRequestVO;

import com.telefonica.prepaid.common.db.Daos;
import com.telefonica.prepaid.common.tags.UseCase;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateContractRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateContractResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateDSSEntryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateDSSEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateReplacementSimRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ActivateReplacementSimResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ApplyCreditDebitRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ApplyCreditDebitResult;
import com.telefonica.prepaid.customercare.v24.service.domain.BarUnbarAccountRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.BarUnbarAccountResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CancelFailedPortingOutOrderRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.CancelFailedPortingOutOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CancelPortingInOrderRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.CancelPortingInOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeBankAccountRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeBankAccountResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCLIPorCLIRRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCLIPorCLIRResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCustomerCommChannelRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCustomerCommChannelResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCustomerDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeSIMRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeSIMResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeVoiceMailboxPINRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeVoiceMailboxPINResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeWhoCalledServiceRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ChangeWhoCalledServiceResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ConfirmSepaMandateRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ConfirmSepaMandateResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CreateCrmOrderRequestType;
import com.telefonica.prepaid.customercare.v24.service.domain.CreateCrmOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CreatePortingDeclarationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.CreatePortingDeclarationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.CustomerCareVerifyAvailabilityRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.DeactivateAccountRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.DeactivateAccountResult;
import com.telefonica.prepaid.customercare.v24.service.domain.DeactivateDSSEntryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.DeactivateDSSEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.DeleteBundleRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.DeleteBundleResult;
import com.telefonica.prepaid.customercare.v24.service.domain.DeregisterPaymentMethodRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.DeregisterPaymentMethodResult;
import com.telefonica.prepaid.customercare.v24.service.domain.FetchCustomerHistoryEntriesRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.FetchCustomerHistoryEntriesResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetAccountBalanceRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetAccountBalanceResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetAvailableBundlesRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetAvailableBundlesResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetAvailableProductsRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetAvailableProductsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetBrandConfigurationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetBrandConfigurationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetChurnCustomerDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetChurnCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCrdInformationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCrdInformationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCurrentBundleRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCurrentBundleResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCurrentProductsRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCurrentProductsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCustomerDataForDataPortabilityRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCustomerDataForDataPortabilityResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCustomerDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetDSSEntryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetDSSEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetDynamicCustomerDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetDynamicCustomerDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetEGNDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetEGNDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetHandsetDelockDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetHandsetDelockDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetLastKnownQoSInformationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetLastKnownQoSInformationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetNetworkServiceStatusRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetNetworkServiceStatusResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPackCounterStatusRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPackCounterStatusResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPackHistoryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPackHistoryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPartnerBenefitPackRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPartnerBenefitPackResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPortingDeclarationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPortingDeclarationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPortingInStatusRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPortingInStatusResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPortingOutStatusRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPortingOutStatusResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPreferredCommunicationChannelRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPreferredCommunicationChannelResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetProductListRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetProductListResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetRechargeOptionsRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetRechargeOptionsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMHistoryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMHistoryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMInfoRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMInfoResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMStatisticsRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetSIMStatisticsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetTariffChangeHistoryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetTariffChangeHistoryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetTopUpsAndChargesRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetTopUpsAndChargesResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ModifyRegistrationDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ModifyRegistrationDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.NotifyAboutSuccessfulReverificationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.NotifyAboutSuccessfulReverificationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.RemovePortingDeclarationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.RemovePortingDeclarationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ResetAccountRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ResetAccountResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ResetRegistrationDataRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ResetRegistrationDataResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ResubmitPortingDateRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ResubmitPortingDateResult;
import com.telefonica.prepaid.customercare.v24.service.domain.SearchCustomersRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.SearchCustomersResult;
import com.telefonica.prepaid.customercare.v24.service.domain.SearchTenantBrandAssignmentRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.SearchTenantBrandAssignmentResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ShowVoiceMailboxPINStatusRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ShowVoiceMailboxPINStatusResult;
import com.telefonica.prepaid.customercare.v24.service.domain.StoreCustomerHistoryEntryRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.StoreCustomerHistoryEntryResult;
import com.telefonica.prepaid.customercare.v24.service.domain.SubscribeBundleRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.SubscribeBundleResult;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdateFrontendRegistrationDateRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdateFrontendRegistrationDateResult;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdatePortingDeclarationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdatePortingDeclarationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdatePortingInOrderRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.UpdatePortingInOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ValidateCrmOrderRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ValidateCrmOrderResult;
import com.telefonica.prepaid.customercare.v24.service.domain.ValidateSimRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.ValidateSimResult;
import com.telefonica.prepaid.external.customercare.domain.ApplyCreditDebitRequestVo;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesRequestVo;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesResponseVo;
import com.telefonica.prepaid.external.customercare.v24.converter.AccountResponseConverterV24;
import com.telefonica.prepaid.external.customercare.v24.converter.BundleResponseConverterV24;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderRequestVo;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.ActivateReplacementSimRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ConfirmSepaMandateRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.DeregisterPaymentMethodRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCrdInformationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCustomerDataForDataPortabilityRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetDynamicCustomerDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetEGNDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ModifyRegistrationDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.NotifyAboutSuccessfulReverificationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ResetRegistrationDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.service.CustomerCareServicesLocal;
import com.telefonica.prepaid.frontend.customercare.v24.converter.AccountRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.BundleRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.ConfigResponseConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.CrmOrderRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.CustomerRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.CustomerResponseConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.NetworkRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.NetworkResponseConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.PackRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.PackResponseConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.PortingRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.PortingResponseConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.ProductRequestConverterV24;
import com.telefonica.prepaid.frontend.customercare.v24.converter.ProductResponseConverterV24;
import com.telefonica.prepaid.frontend.prepaidapi.common.EnrichedRequest;
import com.telefonica.prepaid.prepaiditcustomercareservices.ActivateContractRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetBrandConfigurationRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetCurrentBundleRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.SearchTenantBrandAssignmentRequestVO;
import com.telefonica.prepaid.usage.GetTopUpsRequestVo;
import com.telefonica.prepaid.customercare.v24.service.domain.RequestEmailAddressPerSmsRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.RequestEmailAddressPerSmsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPreContractualInformationRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetPreContractualInformationResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetKittedProductsRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetKittedProductsResult;
import com.telefonica.prepaid.customercare.v24.service.domain.GetNonEECCRelevantProductsForBrandRequest;
import com.telefonica.prepaid.customercare.v24.service.domain.GetNonEECCRelevantProductsForBrandResult;
import com.telefonica.prepaid.frontend.customercare.domain.RequestEmailAddressPerSmsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetKittedProductsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetNonEECCRelevantProductsForBrandRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetPreContractualInformationRequestVo;

public class CustomerServicesWrapperV24 {
    private final CustomerCareServicesLocal customerCareService;
    private final CustomerRequestConverterV24 requestConverter;
    private final CustomerResponseConverterV24 responseConverter;
    private final BundleResponseConverterV24 bundleResponseConverter = new BundleResponseConverterV24();
    private final PackRequestConverterV24 packRequestConverter;
    private final AccountRequestConverterV24 accountRequestConverter;
    private final PortingRequestConverterV24 portingRequestConverter;
    private final BundleRequestConverterV24 bundleRequestConverter;
    private final AccountResponseConverterV24 accountResponseConverter;
    private final PackResponseConverterV24 packSubscriptionStatusNotificationConverter;
    private final NetworkRequestConverterV24 networkRequestConverter;
    private final NetworkResponseConverterV24 networkResponseConverter;
    private final PortingResponseConverterV24 portingResponseConverter;
    private final CrmOrderRequestConverterV24 crmRequestConverter;
    private final ProductRequestConverterV24 productRequestConverter;
    private final ProductResponseConverterV24 productResponseConverter;
    private final ConfigResponseConverterV24 configResponseConverter;

    public CustomerServicesWrapperV24( Daos daos, CustomerCareServicesLocal customerCareService ) {
        this.customerCareService = customerCareService;
        requestConverter = new CustomerRequestConverterV24( daos );
        responseConverter = new CustomerResponseConverterV24();
        bundleRequestConverter = new BundleRequestConverterV24( daos );
        networkRequestConverter = new NetworkRequestConverterV24( daos );
        packRequestConverter = new PackRequestConverterV24( daos );
        accountRequestConverter = new AccountRequestConverterV24( daos );
        packSubscriptionStatusNotificationConverter = new PackResponseConverterV24();
        accountResponseConverter = new AccountResponseConverterV24();
        portingRequestConverter = new PortingRequestConverterV24( daos );
        networkResponseConverter = new NetworkResponseConverterV24();
        portingResponseConverter = new PortingResponseConverterV24();
        crmRequestConverter = new CrmOrderRequestConverterV24( daos );
        productRequestConverter = new ProductRequestConverterV24( daos );
        productResponseConverter = new ProductResponseConverterV24();
        configResponseConverter = new ConfigResponseConverterV24();
    }

    public GetCustomerDataResult getCustomerData( EnrichedRequest<GetCustomerDataRequest> getCustomerDataRequest ) {
        GetCustomerDataRequestVO requestVO = requestConverter.convertGetCustomerDataRequest( getCustomerDataRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getCustomerData( requestVO );
        return responseConverter.convertGetCustomerDataResponse( prepaidServiceResponseVO );
    }

    public GetPreferredCommunicationChannelResult getPreferredCommunicationChannel(
            EnrichedRequest<GetPreferredCommunicationChannelRequest> request ) {
        GetPreferredCommunicationChannelRequestVO requestVO = requestConverter.convertGetPreferredCommunicationChannelRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService
            .getPreferredCommunicationChannel( requestVO );
        return responseConverter.convertGetPreferredCommunicationChannelResponse( prepaidServicesResponseVO );
    }

    public DeactivateDSSEntryResult deactivateDSSEntry(
            EnrichedRequest<DeactivateDSSEntryRequest> enrichedRequest ) {
        DeactivateDSSEntryRequestVO requestVO = networkRequestConverter.convertDeactivateDSSEntryRequest( enrichedRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.deactivateDSSEntry( requestVO );
        return responseConverter.convertDeactivateDSSEntryResponse( prepaidServiceResponseVO );
    }

    public GetSIMStatisticsResult getSIMStatistics( EnrichedRequest<GetSIMStatisticsRequest> simStatisticsRequest ) {
        GetSIMStatisticsRequestVO simStatisticsRequestVO = requestConverter.convertGetSIMStatisticsRequest( simStatisticsRequest );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getSIMStatistics( simStatisticsRequestVO );
        return responseConverter.convertGetSimStatisticsResponse( prepaidServicesResponseVO );
    }

    public GetSIMHistoryResult getSIMHistory( EnrichedRequest<GetSIMHistoryRequest> getSIMHistoryRequest ) {
        GetSIMHistoryRequestVO getSIMHistoryRequestVO = requestConverter.convertGetSIMHistoryRequest( getSIMHistoryRequest );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getSIMHistory( getSIMHistoryRequestVO );
        return responseConverter.convertGetSimHistoryResponse( prepaidServicesResponseVO );
    }

    public ActivateDSSEntryResult activateDSSEntry( EnrichedRequest<ActivateDSSEntryRequest> request ) {
        ActivateDSSEntryRequestVO requestVO = networkRequestConverter.convertActivateDSSEntryRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.activateDSSEntry( requestVO );
        return responseConverter.convertActivateDSSEntryResponse( prepaidServiceResponseVO );
    }

    public SearchCustomersResult searchCustomers( EnrichedRequest<SearchCustomersRequest> request ) {
        QueryCustomersRequestVO requestVO = requestConverter.convertQueryCustomersRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.searchCustomers( requestVO );
        return responseConverter.convertQueryCustomersResponse( prepaidServicesResponseVO );
    }

    public GetChurnCustomerDataResult getChurnCustomerData( EnrichedRequest<GetChurnCustomerDataRequest> request ) {
        GetChurnCustomerDataRequestVO requestVO = requestConverter.convertGetChurnCustomerDataRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getChurnCustomerData( requestVO );
        return responseConverter.convertGetChurnCustomerDataResponse( prepaidServicesResponseVO );
    }

    public GetDSSEntryResult getDSSEntry( EnrichedRequest<GetDSSEntryRequest> request ) {
        GetDSSEntryRequestVO requestVO = networkRequestConverter.convertGetDSSEntryRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getDSSEntry( requestVO );
        return responseConverter.convertGetDSSEntryResponse( prepaidServiceResponseVO );
    }

    public ChangeCustomerDataResult changeCustomerData( EnrichedRequest<ChangeCustomerDataRequest> request ) {
        ChangeCustomerDataRequestVO requestVO = requestConverter.convertChangeCustomerDataRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.changeCustomerData( requestVO );
        return responseConverter.convertChangeCustomerDataResponse( prepaidServicesResponseVO );
    }

    public GetEGNDataResult getEGNData( EnrichedRequest<GetEGNDataRequest> request ) {
        GetEGNDataRequestVo requestVO = packRequestConverter.convertGetEGNDataRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getEGNData( requestVO );
        return responseConverter.convertGetEGNDataResponse( prepaidServicesResponseVO );
    }

    public GetTopUpsAndChargesResult getTopUps( EnrichedRequest<GetTopUpsAndChargesRequest> request ) {
        GetTopUpsRequestVo requestVO = packRequestConverter.convertGetTopUpsAndChargesRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getTopUps( requestVO );
        return responseConverter.convertGetTopUpsAndChargesResponse( prepaidServicesResponseVO );
    }

    public GetRechargeOptionsResult getRechargeOptions( EnrichedRequest<GetRechargeOptionsRequest> request ) {
        GetDirectDebitRechargeOptionsRequestVO requestVo = requestConverter.convertDirectDebitRechargeOptions( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.getRechargeOptions( requestVo );
        return configResponseConverter.convertDirectDebitRechargeOptionsResponse( responseVo );
    }

    public StoreCustomerHistoryEntryResult storeCustomerHistoryEntry( EnrichedRequest<StoreCustomerHistoryEntryRequest> request ) {
        ImportAccountContactHistoryRequestVO requestVO = accountRequestConverter.convertImportAccountContactHistoryRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.importAccountContactHistory( requestVO );
        return responseConverter.convertStoreCustomerHistoryEntryResponse( prepaidServiceResponseVO );
    }

    public FetchCustomerHistoryEntriesResult fetchCustomerHistoryEntries( EnrichedRequest<FetchCustomerHistoryEntriesRequest> request ) {
        ExportAccountContactHistoryRequestVO requestVO = accountRequestConverter.convertExportAccountContactHistoryRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.exportAccountContactHistory( requestVO );
        return responseConverter.convertFetchCustomerHistoryEntriesResponse( prepaidServiceResponseVO );
    }

    public GetSIMInfoResult getSIMInfo( EnrichedRequest<GetSIMInfoRequest> request ) {
        CustomerCareServicesRequestVo requestVO = requestConverter.convertGetSIMInfoRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getSIMInfo( requestVO );
        return responseConverter.convertGetSIMInfoResponse( prepaidServiceResponseVO );
    }

    public ValidateSimResult validateSim( EnrichedRequest<ValidateSimRequest> simValidationRequest ) {
        SimValidationRequestVO requestVO = requestConverter.convertValidateSimRequest( simValidationRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.validateSim( requestVO );
        return responseConverter.convertValidateSimResponse( prepaidServiceResponseVO );
    }

    public ChangeCustomerCommChannelResult changeCustomerCommChannel(
            EnrichedRequest<ChangeCustomerCommChannelRequest> changeCustomerCommChannelRequest ) {
        ChangeCustomerCommChannelRequestVO requestVO = requestConverter
            .convertChangeCustomerCommChannelRequest( changeCustomerCommChannelRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.changeCustomerCommChannel( requestVO );
        return responseConverter.convertChangeCustomerCommChannelResponse( prepaidServiceResponseVO );
    }

    public GetTariffChangeHistoryResult getTariffChangeHistory(
            EnrichedRequest<GetTariffChangeHistoryRequest> getTariffChangeHistoryRequest ) {
        GetTariffChangeHistoryRequestVO requestVO = requestConverter.convertGetTariffChangeHistoryRequest( getTariffChangeHistoryRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getTariffChangeHistory( requestVO );
        return responseConverter.convertGetTariffChangeHistoryResponse( prepaidServiceResponseVO );
    }

    public GetPartnerBenefitPackResult getPartnerBenefitPack( EnrichedRequest<GetPartnerBenefitPackRequest> request ) {
        GetPartnerBenefitPackRequestVO requestVO = packRequestConverter.convertGetPartnerBenefitPackRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getPartnerBenefitPack( requestVO );
        return packSubscriptionStatusNotificationConverter.convertGetPartnerBenefitPackResponse( prepaidServiceResponseVO );
    }

    public GetPackHistoryResult getPackHistory( EnrichedRequest<GetPackHistoryRequest> getPackHistoryRequest ) {
        GetPackHistoryRequestVO requestVO = packRequestConverter.convertGetPackHistoryRequest( getPackHistoryRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getPackHistory( requestVO );
        return packSubscriptionStatusNotificationConverter.convertGetPackHistoryResponse( prepaidServiceResponseVO );
    }

    public GetPackCounterStatusResult getPackCounterStatus( EnrichedRequest<GetPackCounterStatusRequest> request ) {
        GetPackCounterStatusRequestVO getPackCounterStatusRequestVO = packRequestConverter.convertGetPackCounterStatusRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService
            .getPackCounterStatus( getPackCounterStatusRequestVO );
        return packSubscriptionStatusNotificationConverter.convertGetPackCounterStatusResponse( prepaidServicesResponseVO );
    }

    public DeactivateAccountResult deactivateAccount( EnrichedRequest<DeactivateAccountRequest> request ) {
        DeactivateAccountRequestVO requestVO = accountRequestConverter.convertDeactivateAccountRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.deactivateAccount( requestVO );
        return accountResponseConverter.convertDeactivateAccountResponse( prepaidServicesResponseVO );
    }

    public ApplyCreditDebitResult applyCreditDebit( EnrichedRequest<ApplyCreditDebitRequest> request ) {
        ApplyCreditDebitRequestVo requestVO = accountRequestConverter.convertApplyCreditDebitRequestVO( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.applyCreditDebit( requestVO );
        return accountResponseConverter.convertApplyCreditDebitResponse( prepaidServiceResponseVO );
    }

    public GetAccountBalanceResult getAccountBalance( EnrichedRequest<GetAccountBalanceRequest> request ) {
        GetAccountBalanceRequestVO requestVO = accountRequestConverter.convertGetAccountBalanceRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getAccountBalance( requestVO );
        return accountResponseConverter.convertGetAccountBalanceResponse( prepaidServiceResponseVO );
    }

    public ResetAccountResult resetAccount( EnrichedRequest<ResetAccountRequest> request ) {
        ResetAccountRequestVO requestVO = accountRequestConverter.convertResetAccountRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.resetAccount( requestVO );
        return accountResponseConverter.convertResetAccountResponse( prepaidServicesResponseVO );
    }

    public ChangeSIMResult changeSIM( EnrichedRequest<ChangeSIMRequest> changeSIMRequest ) {
        ChangeSIMRequestVO changeSIMRequestVO = networkRequestConverter.convertChangeSIMRequest( changeSIMRequest );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.changeSIM( changeSIMRequestVO );
        return networkResponseConverter.convertChangeSIMResponse( prepaidServicesResponseVO );
    }

    public GetNetworkServiceStatusResult getNetworkServiceStatus( EnrichedRequest<GetNetworkServiceStatusRequest> request ) {
        CustomerCareServicesRequestVo requestVO = networkRequestConverter.convertGetNetworkServiceStatusRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getNetworkServiceStatus( requestVO );
        return networkResponseConverter.convertGetNetworkServiceStatusResponse( prepaidServicesResponseVO );
    }

    public ShowVoiceMailboxPINStatusResult showVoicemailboxPINStatus( EnrichedRequest<ShowVoiceMailboxPINStatusRequest> request ) {
        CustomerCareServicesRequestVo requestVO = networkRequestConverter.convertShowVoiceMailboxPINStatusRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.showVoicemailboxPINStatus( requestVO );
        return networkResponseConverter.convertShowVoiceMailboxPINStatusResponse( prepaidServicesResponseVO );
    }

    public ChangeCLIPorCLIRResult changeCLIPorCLIR( EnrichedRequest<ChangeCLIPorCLIRRequest> changeCLIPorCLIRRequest ) {
        ChangeCLIPorCLIRRequestVO requestVO = networkRequestConverter.convertChangeCLIPorCLIRRequest( changeCLIPorCLIRRequest );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.changeCLIPorCLIR( requestVO );
        return networkResponseConverter.convertChangeCLIPorCLIRResultResponse( prepaidServicesResponseVO );
    }

    public ChangeVoiceMailboxPINResult changeVoiceMailboxPIN( EnrichedRequest<ChangeVoiceMailboxPINRequest> request ) {
        ChangeVoiceMailboxPINRequestVO changeVoiceMailboxPINRequestVO = networkRequestConverter.convertChangeVoiceMailboxPINRequest(
            request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService
            .changeVoiceMailboxPIN( changeVoiceMailboxPINRequestVO );
        return networkResponseConverter.convertChangeVoiceMailboxPINResponse( prepaidServicesResponseVO );
    }

    public ChangeWhoCalledServiceResult changeWhoCalledService( EnrichedRequest<ChangeWhoCalledServiceRequest> request ) {
        ChangeWhoCalledServiceRequestVO requestVO = networkRequestConverter.convertChangeWhoCalledServiceRequestVO( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.changeWhoCalledService( requestVO );
        return networkResponseConverter.convertChangeWhoCalledServiceResponse( prepaidServicesResponseVO );
    }

    public BarUnbarAccountResult barUnbarAccount( EnrichedRequest<BarUnbarAccountRequest> request ) {
        BarUnbarAccountRequestVO requestVO = accountRequestConverter.convertBarUnbarAccountRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.barUnbarAccount( requestVO );
        return networkResponseConverter.convertBarUnbarAccountRespose( prepaidServicesResponseVO );
    }

    public GetPortingInStatusResult getPortingInStatus( EnrichedRequest<GetPortingInStatusRequest> request ) {
        GetPortInStatusRequestVO requestVO = portingRequestConverter.convertGetPortInStatusRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.getPortingInStatus( requestVO );
        return portingResponseConverter.responseConverterForGetPortInStatus( prepaidServicesResponseVO );
    }

    public UpdatePortingInOrderResult updatePortingInOrder( EnrichedRequest<UpdatePortingInOrderRequest> request ) {
        UpdatePortingInOrderRequestVO requestVO = portingRequestConverter.updatePortInRequestConverter( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.updatePortInRequest( requestVO );
        return portingResponseConverter.responseConverterForUpdatePortingInOrderRequest( prepaidServicesResponseVO );
    }

    public CancelPortingInOrderResult cancelPortingInOrder( EnrichedRequest<CancelPortingInOrderRequest> request ) {
        CancelPortingInOrderRequestVO requestVO = portingRequestConverter.convertCancelPortInRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.cancelPortInRequest(
            requestVO, true );
        return portingResponseConverter.responseConverterForCancelPortingInOrderRequest( prepaidServicesResponseVO );
    }

    public GetPortingOutStatusResult getPortingOutStatus( EnrichedRequest<GetPortingOutStatusRequest> request ) {
        GetPortingOutStatusRequestVO requestVO = portingRequestConverter.convertGetPortingOutStatusRequest( request );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.getPortingOutStatus( requestVO );
        return portingResponseConverter.convertGetPortingOutStatusResponse( prepaidServiceResponseVO );
    }

    public CancelFailedPortingOutOrderResult cancelFailedPortingOutOrder( EnrichedRequest<CancelFailedPortingOutOrderRequest> request ) {
        CancelFailedPortingOutOrderRequestVO requestVO = portingRequestConverter.convertCancelFailedPortingOutRequest( request );
        CustomerCareServicesResponseVo responseVO = customerCareService.cancelFailedPortingOutOrder( requestVO );
        return portingResponseConverter.convertCancelFailedPortingOutOrderRequest( responseVO );
    }

    public CreatePortingDeclarationResult createPortingDeclaration( EnrichedRequest<CreatePortingDeclarationRequest> request ) {
        CreatePortingDeclarationRequestVO requestVO = portingRequestConverter.convertCreatePortingRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.createPortingDeclaration( requestVO );
        return portingResponseConverter.convertCreatePortingDeclarationResponse( responseVo );
    }

    public UpdatePortingDeclarationResult updatePortingDeclaration( EnrichedRequest<UpdatePortingDeclarationRequest> request ) {
        UpdatePortingDeclarationRequestVO requestVO = portingRequestConverter.convertUpdatePortingRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.updatePortingDeclaration( requestVO );
        return portingResponseConverter.convertUpdatePortingDeclarationResponse( responseVo );
    }

    public GetPortingDeclarationResult getPortingDeclaration( EnrichedRequest<GetPortingDeclarationRequest> request ) {
        CustomerCareServicesRequestVo requestVO = portingRequestConverter.convertGetPortingRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.getPortingDeclaration( requestVO );
        return portingResponseConverter.convertGetPortingDeclarationResponse( responseVo );
    }

    public RemovePortingDeclarationResult removePortingDeclaration( EnrichedRequest<RemovePortingDeclarationRequest> request ) {
        CustomerCareServicesRequestVo removePortingDeclarationRequestVO = portingRequestConverter.convertRemovePortingRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService
            .removePortingDeclaration( removePortingDeclarationRequestVO );
        return portingResponseConverter.convertRemovePortingDeclarationResponse( prepaidServicesResponseVO );
    }

    public ResubmitPortingDateResult resubmitPortingDate( EnrichedRequest<ResubmitPortingDateRequest> request ) {
        ResubmitPortingDateRequestVO resubmitPortingDateRequestVO = portingRequestConverter.convertResubmitPortingDateRequest( request );
        CustomerCareServicesResponseVo prepaidServicesResponseVO = customerCareService.resubmitPortingDate( resubmitPortingDateRequestVO );
        return portingResponseConverter.convertResubmitPortingDateResponse( prepaidServicesResponseVO );
    }

    public GetLastKnownQoSInformationResult getLastKnownQoSInformation(
            EnrichedRequest<GetLastKnownQoSInformationRequest> getLastKnownQoSInformationRequest ) {
        GetLastKnownQoSInformationRequestVO requestVO = requestConverter
            .convertGetLastKnownQoSInformationRequest( getLastKnownQoSInformationRequest );
        CustomerCareServicesResponseVo responseVO = customerCareService.getLastKnownQoSInformation( requestVO );
        return responseConverter.convertGetLastKnownQosInformationResponse( responseVO );
    }

    @UseCase( SubscribeBundle )
    public SubscribeBundleResult subscribeBundle( EnrichedRequest<SubscribeBundleRequest> subscribeBundleRequest ) {
        SubscribeBundleRequestVo bundleRequestVO = bundleRequestConverter.convertSubscribeBundleRequest( subscribeBundleRequest );
        CustomerCareServicesResponseVo responseVO = customerCareService.subscribeBundle( bundleRequestVO );
        return bundleResponseConverter.convertSubscribeBundleResponse( responseVO );
    }

    @UseCase( GetCurrentBundle )
    public GetCurrentBundleResult getCurrentBundle( EnrichedRequest<GetCurrentBundleRequest> request ) {
        GetCurrentBundleRequestVO requestVo = requestConverter.convertGetCurrentBundleRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.getCurrentBundle( requestVo );
        return bundleResponseConverter.convertGetCurrentBundleResponse( responseVo );
    }

    @UseCase( DeleteBundle )
    public DeleteBundleResult deleteBundle( EnrichedRequest<DeleteBundleRequest> deleteBundleRequest ) {
        DeleteBundleRequestVo bundleVO = bundleRequestConverter.convertDeleteBundleRequest( deleteBundleRequest );
        CustomerCareServicesResponseVo responseVO = customerCareService.deleteBundle( bundleVO );
        return bundleResponseConverter.convertDeleteBundleResponse( responseVO );
    }

    @UseCase( GetAvailableBundles )
    public GetAvailableBundlesResult getAvailableBundles( EnrichedRequest<GetAvailableBundlesRequest> getAvailableBundlesRequest ) {
        GetAvailableBundlesRequestVo getAvailableBundlesRequestVo = bundleRequestConverter
            .convertGetAvailableBundleRequest( getAvailableBundlesRequest );
        CustomerCareServicesResponseVo responseVO = customerCareService.getAvailableBundles( getAvailableBundlesRequestVo );
        return new BundleResponseConverterV24().convertGetAvailableBundlesResponse( responseVO );
    }

    public CreateCrmOrderResult createCrmOrder( EnrichedRequest<CreateCrmOrderRequestType> request ) {
        CreateCrmOrderRequestVO requestVO = crmRequestConverter.convertCreateCrmOrderRequest( request );
        CustomerCareServicesResponseVo responseVO = customerCareService.createCrmOrder( requestVO );
        return responseConverter.convertCreateCrmOrderResponse( responseVO );
    }

    public ValidateCrmOrderResult validateCrmOrder( EnrichedRequest<ValidateCrmOrderRequest> request ) {
        ValidateCrmOrderRequestVo requestVO = crmRequestConverter.convertValidateCrmOrderRequest( request );
        ValidateCrmOrderResponseVo responseVO = customerCareService.validateCrmOrder( requestVO );
        return responseConverter.convertValidateCrmOrderResponse( responseVO );
    }

    public GetDynamicCustomerDataResult getDynamicCustomerData( EnrichedRequest<GetDynamicCustomerDataRequest> request ) {
        GetDynamicCustomerDataRequestVo requestVo = productRequestConverter.convertGetDynamicCustomerDataRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.getDynamicCustomerData( requestVo );
        return productResponseConverter.convertGetDynamicCustomerDataResponse( responseVo );
    }

    @UseCase( GetCurrentProducts )
    public GetCurrentProductsResult getCurrentProducts( EnrichedRequest<GetCurrentProductsRequest> request ) {
        GetCurrentOrAvailableProductsRequestVO requestVO = productRequestConverter.convertGetCurrentProductsRequest( request );
        CustomerCareServicesResponseVo responseVO = customerCareService.getCurrentProducts( requestVO );
        return productResponseConverter.convertGetCurrentProductsResponse( responseVO );
    }

    @UseCase( GetAvailableProducts )
    public GetAvailableProductsResult getAvailableProducts( EnrichedRequest<GetAvailableProductsRequest> request ) {
        GetCurrentOrAvailableProductsRequestVO requestVO = productRequestConverter.convertGetAvailableProductsRequest( request );
        CustomerCareServicesResponseVo responseVO = customerCareService.getAvailableProducts( requestVO );
        return productResponseConverter.convertGetAvailableProductsResponse( responseVO );
    }

    @UseCase( GetProductList )
    public GetProductListResult getProductList( EnrichedRequest<GetProductListRequest> request ) {
        GetCurrentOrAvailableProductsRequestVO requestVO = productRequestConverter.convertGetProductListRequest( request );
        CustomerCareServicesResponseVo responseVO = customerCareService.getProductList( requestVO );
        return productResponseConverter.convertGetProductListResponse( responseVO );
    }

    public UpdateFrontendRegistrationDateResult updateFrontendRegistrationDate(
            EnrichedRequest<UpdateFrontendRegistrationDateRequest> request ) {
        UpdateFrontendRegistrationDateRequestVo requestVo = requestConverter.convertUpdateFrontendRegistrationDate( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.updateFrontendRegistrationDate( requestVo );
        return responseConverter.convertUpdateFrontendRegistrationDate( responseVo );
    }

    public GetHandsetDelockDataResult getHandsetDelockData( EnrichedRequest<GetHandsetDelockDataRequest> request ) {
        GetHandsetDelockDataRequestVo requestVo = requestConverter.convertGetHandsetDelockData( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.getHandsetDelockData( requestVo );
        return responseConverter.convertGetHandsetDelockDataResult( responseVo );
    }

    public ChangeBankAccountResult changeBankAccount( EnrichedRequest<ChangeBankAccountRequest> changeBankAccountRequest ) {
        ChangeBankAccountRequestVO requestVO = requestConverter.convertChangeBankAccountRequest( changeBankAccountRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.changeBankAccount( requestVO );
        return responseConverter.convertChangeBankAccountResponse( prepaidServiceResponseVO );
    }

    public GetBrandConfigurationResult getBrandConfiguration( EnrichedRequest<GetBrandConfigurationRequest> request ) {
        GetBrandConfigurationRequestVO requestVo = requestConverter.getBrandConfigurationRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.getBrandConfiguration( requestVo );
        return configResponseConverter.convertGetBrandConfigurationResponse( responseVo );
    }

    public SearchTenantBrandAssignmentResult searchTenantBrandAssignment( EnrichedRequest<SearchTenantBrandAssignmentRequest> request ) {
        SearchTenantBrandAssignmentRequestVO requestVo = requestConverter.searchTenantBrandAssignmentRequest( request );
        CustomerCareServicesResponseVo responseVo = customerCareService.searchTenantBrandAssignment( requestVo );
        return configResponseConverter.convertSearchTenantBrandAssignmentResponse( responseVo );
    }

    public ActivateContractResult activateContract( EnrichedRequest<ActivateContractRequest> activateContractRequest ) {
        ActivateContractRequestVO requestVO = requestConverter.activateContractRequest( activateContractRequest );
        CustomerCareServicesResponseVo activateContractResponseVO = customerCareService.activateContract( requestVO );
        return responseConverter.convertActivateContractResponse( activateContractResponseVO );
    }

    public ActivateReplacementSimResult activateReplacementSim(
            EnrichedRequest<ActivateReplacementSimRequest> activateReplacementSimRequest ) {
        ActivateReplacementSimRequestVo requestVo = requestConverter.convertActivateReplacementSimRequest( activateReplacementSimRequest );
        CustomerCareServicesResponseVo activateReplacementSimResponseVo = customerCareService.activateReplacementSim( requestVo );
        return responseConverter.convertActivateReplacementSimResponse( activateReplacementSimResponseVo );
    }

    public ConfirmSepaMandateResult confirmSepaMandate( EnrichedRequest<ConfirmSepaMandateRequest> confirmSepaMandateRequest ) {
        ConfirmSepaMandateRequestVo requestVo = requestConverter.convertConfirmSepaMandateRequest( confirmSepaMandateRequest );
        CustomerCareServicesResponseVo confirmSepaMandateResponseVo = customerCareService.confirmSepaMandate( requestVo );
        return responseConverter.convertConfirmSepaMandateResponse( confirmSepaMandateResponseVo );
    }

    public DeregisterPaymentMethodResult deregisterPaymentMethod(
            EnrichedRequest<DeregisterPaymentMethodRequest> deregisterPaymentMethodRequest ) {
        DeregisterPaymentMethodRequestVo requestVo = requestConverter
            .convertDeregisterPaymentMethodRequest( deregisterPaymentMethodRequest );
        return responseConverter.convertDeregisterPaymentMethodResponse( customerCareService.deregisterPaymentMethod( requestVo ) );
    }

    public NotifyAboutSuccessfulReverificationResult notifyAboutSuccessfulReverification(
            EnrichedRequest<NotifyAboutSuccessfulReverificationRequest> request ) {
        NotifyAboutSuccessfulReverificationRequestVo requestVo = requestConverter
            .convertNotifyAboutSuccessfulReverificationRequest( request );
        return responseConverter.convertNotifyAboutSuccessfulReverificationResponse(
            customerCareService.notifyAboutSuccessfulReverification( requestVo ) );
    }

    public boolean verifyAvailability( EnrichedRequest<CustomerCareVerifyAvailabilityRequest> customerCareVerifyAvailabilityRequest ) {
        CustomerCareServicesRequestVo requestVo = requestConverter
            .convertVerifyAvailabilityRequest( customerCareVerifyAvailabilityRequest );
        CustomerCareServicesResponseVo verifyAvailabilityResponseVo = customerCareService.verifyAvailability( requestVo );
        return responseConverter.convertVerifyAvailabilityResponse( verifyAvailabilityResponseVo );
    }

    public ResetRegistrationDataResult resetRegistrationData( EnrichedRequest<ResetRegistrationDataRequest> resetRegistrationDataRequest ) {
        ResetRegistrationDataRequestVo requestVO = requestConverter.convertResetRegistrationDataRequest( resetRegistrationDataRequest );
        CustomerCareServicesResponseVo prepaidServiceResponseVO = customerCareService.resetRegistrationData( requestVO );
        return responseConverter.convertResetRegistrationDataResponse( prepaidServiceResponseVO );
    }

    public ModifyRegistrationDataResult modifyRegistrationData(
            EnrichedRequest<ModifyRegistrationDataRequest> modifyRegistrationDataRequest ) {
        ModifyRegistrationDataRequestVo requestVo = requestConverter.convertModifyRegistrationDataRequest( modifyRegistrationDataRequest );
        CustomerCareServicesResponseVo customerCareServicesResponseVo = customerCareService.modifyRegistrationData( requestVo );
        return responseConverter.convertModifyRegistrationDataResult( customerCareServicesResponseVo );
    }

    public GetCrdInformationResult getCrdInformation( EnrichedRequest<GetCrdInformationRequest> getCrdInformationRequest ) {
        GetCrdInformationRequestVo requestVo = requestConverter.convertGetCrdInformationRequest( getCrdInformationRequest );
        return productResponseConverter.convertGetCrdInformationResponse( customerCareService.getCrdInformation( requestVo ) );
    }

    public GetCustomerDataForDataPortabilityResult getCustomerDataForDataPortability(
            EnrichedRequest<GetCustomerDataForDataPortabilityRequest> getCustomerDataForDataPortabilityRequest ) {
        GetCustomerDataForDataPortabilityRequestVo requestVo = requestConverter
            .convertGetCustomerDataForDataPortabilityRequest( getCustomerDataForDataPortabilityRequest );
        return responseConverter
            .convertGetCustomerDataForDataPortabilityResponse( customerCareService.getCustomerDataForDataPortability( requestVo ) );
    }

    public GetPreContractualInformationResult getPreContractualInformation(
            EnrichedRequest<GetPreContractualInformationRequest> getPreContractualInformationRequest ) {
        GetPreContractualInformationRequestVo requestVo = requestConverter
            .convertGetPreContractualInformationRequest( getPreContractualInformationRequest );
        CustomerCareServicesResponseVo customerCareServicesResponseVo = customerCareService.getPreContractualInformation( requestVo );
        return responseConverter.convertGetPreContractualInformationResult( customerCareServicesResponseVo );
    }

    public GetKittedProductsResult getKittedProducts( EnrichedRequest<GetKittedProductsRequest> getKittedProductsRequest ) {
        GetKittedProductsRequestVo requestVo = requestConverter.convertGetKittedProductsRequest( getKittedProductsRequest );
        CustomerCareServicesResponseVo customerCareServicesResponseVo = customerCareService.getKittedProducts( requestVo );
        return responseConverter.convertGetKittedProductsResult( customerCareServicesResponseVo );
    }

    public GetNonEECCRelevantProductsForBrandResult getNonEECCRelevantProductsForBrand(
            EnrichedRequest<GetNonEECCRelevantProductsForBrandRequest> getNonEECCRelevantProductsForBrandRequest ) {
        GetNonEECCRelevantProductsForBrandRequestVo requestVo = requestConverter
            .convertGetNonEECCRelevantProductsForBrandRequest( getNonEECCRelevantProductsForBrandRequest );
        CustomerCareServicesResponseVo customerCareServicesResponseVo = customerCareService.getNonEECCRelevantProductsForBrand( requestVo );
        return responseConverter.convertGetNonEECCRelevantProductsForBrandResult( customerCareServicesResponseVo );
    }

    public RequestEmailAddressPerSmsResult requestEmailAddressPerSms(
            EnrichedRequest<RequestEmailAddressPerSmsRequest> requestEmailAddressPerSmsRequest ) {
        RequestEmailAddressPerSmsRequestVo requestVo = requestConverter
            .convertRequestEmailAddressPerSmsRequest( requestEmailAddressPerSmsRequest );
        CustomerCareServicesResponseVo customerCareServicesResponseVo = customerCareService.requestEmailAddressPerSms( requestVo );
        return responseConverter.convertRequestEmailAddressPerSmsResult( customerCareServicesResponseVo );
    }

}
