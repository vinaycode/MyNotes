package com.telefonica.prepaid.frontend.customercare.common;

import static com.telefonica.prepaid.common.log.Log.debug;
import static com.telefonica.prepaid.common.util.StringUtils.isNullOrBlank;
import static com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants.PARAM_COUNTRY_CODE;
import static com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants.PARAM_MSISDN;
import static com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants.PARAM_NATIONALITY;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.BRAND_DOES_NOT_MATCH;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.CUSTOMER_AGREEMENT_FLAG_REMINDER_NOT_SUPPORTED;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.GENERAL_SYSTEM_ERROR;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_AND_ACTIVATION_CODE_MAPPING_NOT_VALID;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_AND_PUK2_NOT_ALLOWED;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_NOT_AVAILABLE_OR_CUSTOMER_NOT_PROVISIONED;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_NOT_REGISTERED;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.PUK2_MISSING;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.REQUEST_SUCCESSFUL;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.UNMAPPED_ERROR;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.WRONG_OR_MISSING_MANDATORY_PARAMETERS;
import static com.telefonica.prepaid.frontend.customercare.validator.PrepaidITCustomerCareServicesBaseValidator.getValidator;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.apache.log4j.Logger;

import com.google.common.base.CharMatcher;
import com.google.common.base.Optional;
import com.google.common.base.Strings;

import de.danet.prepaid.domain.valueobjects.Vendor;
import de.danet.ta.prepaid.daogen.vendor.dto.Salutation;

import com.techmahindra.prepaid.prepaiditcustomercareservices.AbstractCrmOrderRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeBankAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CheckSimVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderRegisterCustomerActionVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.HasAddressDataVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.HasCustomerDataVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.MsisdnActionVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResultVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SimValidationRequestVO;

import com.telefonica.prepaid.common.CustomerCareClient;
import com.telefonica.prepaid.common.Validator;
import com.telefonica.prepaid.common.country.CountryCodeValidationService;
import com.telefonica.prepaid.common.errorhandling.Reject;
import com.telefonica.prepaid.common.errorhandling.exception.ApplicationException;
import com.telefonica.prepaid.common.log.Log;
import com.telefonica.prepaid.common.util.IntegerUtil;
import com.telefonica.prepaid.common.util.OptionalUtils;
import com.telefonica.prepaid.config.SpVendorConfigParameter;
import com.telefonica.prepaid.contract.domain.Contract;
import com.telefonica.prepaid.crmorder.domain.CrmOrderAssignMsisdnVo;
import com.telefonica.prepaid.customer.master.domain.AddressDataVo;
import com.telefonica.prepaid.customer.master.domain.CustomerDataVo;
import com.telefonica.prepaid.customercare.CustomerCareVersion;
import com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants;
import com.telefonica.prepaid.domain.common.ContractStatus;
import com.telefonica.prepaid.domain.common.CountryCode;
import com.telefonica.prepaid.domain.common.Iban;
import com.telefonica.prepaid.domain.common.IccId;
import com.telefonica.prepaid.domain.precom.HasContract;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesRequestVo;
import com.telefonica.prepaid.external.prepaidapi.common.HasClientId;
import com.telefonica.prepaid.external.prepaidapi.common.HasVendor;
import com.telefonica.prepaid.frontend.customercare.domain.CustomerCareWithMsisdnOrIccIdRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.DataCheckQuality;
import com.telefonica.prepaid.frontend.customercare.domain.ModifyRegistrationDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.service.CustomerManagementUtils;
import com.telefonica.prepaid.frontend.customercare.validator.PrepaidITCustomerCareServicesBaseValidator;
import com.telefonica.prepaid.vendor.config.VendorConfigService;
import com.telefonica.prepaid.kitting.KittedDataRepository;
import com.telefonica.prepaid.kitting.domain.KittedData;
import com.telefonica.prepaid.frontend.customercare.domain.GetKittedProductsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetPreContractualInformationRequestVo;

/**
 * Collection of <em>trivial</em> validators.
 *
 * Note that each validator in this class should focus on <em>one</em> thing only.
 */
public class CustomerCareValidatorBuildingBlocks {

    private static final Logger log = Logger.getLogger( CustomerCareValidatorBuildingBlocks.class );

    private CustomerCareValidatorBuildingBlocks() {}

    /**
     * checks that the contract is not null
     */
    public static Validator<HasContract, ResultVO, RuntimeException> checkContractNotNull(
            final CustomerCareResultCode errorResultCode ) {
        return checkContractNotNull( errorResultCode, null );
    }

    /**
     * checks that the contract is not null
     */
    public static Validator<HasContract, ResultVO, RuntimeException> checkContractNotNull(
            final CustomerCareResultCode errorResultCode, @Nullable final String suffixToReasonMessage ) {
        return new Validator<HasContract, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( HasContract input ) {
                Contract contract = input.getContract();
                if( contract == null ) {
                    debug( log, "MSISDN does not exist." );
                    String reasonMsg = Strings.isNullOrEmpty( suffixToReasonMessage ) ? errorResultCode.getDocumentation()
                            : ( errorResultCode.getDocumentation() + suffixToReasonMessage );
                    return new ResultVO( errorResultCode, reasonMsg );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the contractId is not null
     */
    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkContractIdNotNull(
            final CustomerCareResultCode errorResultCode ) {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                Contract contract = input.getContract();
                if( contract.getContractId() == null ) {
                    return new ResultVO( errorResultCode );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the contract is not null
     */
    public static Validator<HasContract, ResultVO, RuntimeException> checkContractNotNull() {
        return checkContractNotNull( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM );
    }

    /**
     * checks that the contract is not null or IccId is not null
     */
    public static Validator<CustomerCareWithMsisdnOrIccIdRequestVo, ResultVO, RuntimeException> checkContractOrIccIdNotNull() {
        return new Validator<CustomerCareWithMsisdnOrIccIdRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareWithMsisdnOrIccIdRequestVo input ) throws RuntimeException {
                boolean isContractIdNull = input.getContract() == null;
                boolean isIccIdAbsent = !input.getIccId().isPresent();

                if( isContractIdNull && isIccIdAbsent ) {
                    debug( log, "Neither MSISDN nor ICCID is present in the request", input );
                    return ResultVO.forWrongOrMissingMandatoryParameter( PrepaidITCustomerCareServicesConstants.PARAM_MSISDN + " or "
                            + PrepaidITCustomerCareServicesConstants.ICCID );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkContractNotTerminatedByOwnerChange() {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                Contract contract = input.getContract();
                if( contract != null && contract.getContractStatus() == ContractStatus.TERMINATED_BY_OWNER_CHANGE
                        && !contract.getVendor().isTchibo() ) {
                    return new ResultVO( UNMAPPED_ERROR );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the PUK2 is not null
     */
    public static Validator<SimValidationRequestVO, ResultVO, RuntimeException> checkPuk2NotNull() {
        return new Validator<SimValidationRequestVO, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( SimValidationRequestVO input ) {
                if( input.getPuk2() == null ) {
                    return new ResultVO( PUK2_MISSING );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the PUK2 is null
     */
    public static Validator<SimValidationRequestVO, ResultVO, RuntimeException> checkPuk2IsNull() {
        return new Validator<SimValidationRequestVO, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( SimValidationRequestVO input ) {
                if( input.getPuk2() != null ) {
                    return new ResultVO( MSISDN_AND_PUK2_NOT_ALLOWED );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the ICCID is not null
     */
    public static Validator<SimValidationRequestVO, ResultVO, RuntimeException> checkIccidNotNull() {
        return new Validator<SimValidationRequestVO, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( SimValidationRequestVO input ) {
                if( input.getIccId() == null ) {
                    return ResultVO.forWrongOrMissingMandatoryParameter( "ICCID" );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * If DNE reminder info is requested to be changed it checks that the reminder feature is enabled for the customer's brand
     */
    public static Validator<ChangeCustomerDataRequestVO, ResultVO, RuntimeException> checkDneReminder(
            final VendorConfigService vendorConfigService ) {
        return new Validator<ChangeCustomerDataRequestVO, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( ChangeCustomerDataRequestVO input ) {
                if( input.getCustomerDataVo() != null
                        && input.getCustomerDataVo().getDneReminder().isPresent()
                        && vendorConfigService.getVendorConfigValueAsLongValueOrDefault( input.getVendor(),
                            SpVendorConfigParameter.CUSTOMER_AGREEMENT_REMINDER_INTERVAL ) == CustomerManagementUtils.DNE_REMINDER_FEATURE_DISABLED_FOR_BRAND ) {
                    return new ResultVO( CUSTOMER_AGREEMENT_FLAG_REMINDER_NOT_SUPPORTED );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the msisdn is valid by calling {@link CustomerCareValidatorBuildingBlocks#checkParameterIsSet(String)}
     * @param errorCodeToReturn
     */
    public static Validator<HasContract, ResultVO, RuntimeException> checkMsisdnString(
            final Optional<CustomerCareResultCode> errorCodeToReturn ) {
        return new Validator<HasContract, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( HasContract input ) {
                Contract contract = input.getContract();
                Reject.ifNull( contract, "Contract is null. Combine this validator with checkContractMSISDNVoNotNull()" );
                if( !checkParameterIsSet( contract.getMsisdn() ) ) {
                    log.error( "MSISDN is a mandatory parameter which is null or blank" );
                    CustomerCareResultCode errorCode = errorCodeToReturn.or( WRONG_OR_MISSING_MANDATORY_PARAMETERS );
                    if( errorCode == WRONG_OR_MISSING_MANDATORY_PARAMETERS ) {
                        return ResultVO.forWrongOrMissingMandatoryParameter( PARAM_MSISDN );
                    }
                    return new ResultVO( errorCode );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<MsisdnActionVO, ResultVO, ApplicationException> validateMsisdnAvailable() {
        return new Validator<MsisdnActionVO, ResultVO, ApplicationException>() {
            @Override
            public ResultVO validate( MsisdnActionVO input ) {
                PrepaidITCustomerCareServicesBaseValidator baseValidator = getValidator();
                boolean msisdnValidForClient = input.getVersionInfo().isGreaterThanVersion( CustomerCareVersion.VERSION_8 )
                        || baseValidator.isMsisdnValidForClient( input, true );
                if( !msisdnValidForClient
                        || input.getContract() == null
                        || input.getContract().getContractId() == null
                        || input.getContract().getMsisdn() == null ) {
                    return new ResultVO( MSISDN_NOT_AVAILABLE_OR_CUSTOMER_NOT_PROVISIONED );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<MsisdnActionVO, ResultVO, ApplicationException> validateMsisdnActive( final boolean withRegistration ) {
        return new Validator<MsisdnActionVO, ResultVO, ApplicationException>() {
            @Override
            public ResultVO validate( MsisdnActionVO input ) {

                PrepaidITCustomerCareServicesBaseValidator baseValidator = getValidator();
                if( !withRegistration && !baseValidator.isMsisdnActiveOrWaitingForActivation( input.getContract() ) ) {
                    return new ResultVO( MSISDN_NOT_REGISTERED );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the transactionId is valid by calling {@link CustomerCareValidatorBuildingBlocks#checkParameterIsSet(String)}
     */
    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkTransactionId() {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                if( !checkParameterIsSet( input.getTransactionId() ) ) {
                    return new ResultVO( WRONG_OR_MISSING_MANDATORY_PARAMETERS,
                        WRONG_OR_MISSING_MANDATORY_PARAMETERS.getDocumentation() +
                                " - " + PrepaidITCustomerCareServicesConstants.PARAM_TRANSACTION_ID );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the tenantId of the request equals the one of the customer's vendor
     */
    public static <T extends HasContract & HasVendor> Validator<T, ResultVO, RuntimeException> checkTenantIdMatchesCustomersVendor(
            final Optional<CustomerCareResultCode> errorCodeToReturn ) {
        return new Validator<T, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( T input ) {
                Contract contract = input.getContract();
                Reject.ifNull( contract, "Contract is null. Combine this validator with checkContractMSISDNVoNotNull()" );

                Vendor customerVendor = contract.getVendor();
                Vendor requestVendor = input.getVendor();
                if( customerVendor != null && requestVendor != null &&
                        IntegerUtil.equalsNullSafe( requestVendor.getTenantId(), customerVendor.getTenantId() ) ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                }

                return new ResultVO( errorCodeToReturn.or( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM ) );
            }
        };
    }

    public static <T extends HasContract & HasVendor> Validator<T, ResultVO, RuntimeException> checkTenantIdMatchesCustomersVendor() {
        return checkTenantIdMatchesCustomersVendor( Optional.<CustomerCareResultCode>absent() );
    }

    /**
     * checks that the brandId of the request equals the one of the customer's vendor
     */
    public static <T extends HasContract & HasVendor> Validator<T, ResultVO, RuntimeException> checkBrandIdMatchesCustomersVendor(
            final Optional<CustomerCareResultCode> errorCodeToReturn ) {
        return new Validator<T, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( T input ) {
                Contract contract = input.getContract();
                Reject.ifNull( contract, "Contract is null. Combine this validator with checkContractMSISDNVoNotNull()" );

                Vendor customerVendor = contract.getVendor();
                Vendor requestVendor = input.getVendor();
                if( customerVendor != null && requestVendor != null &&
                        IntegerUtil.equalsNullSafe( requestVendor.getBrandId(), customerVendor.getBrandId() ) ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                }

                return new ResultVO( errorCodeToReturn.or( BRAND_DOES_NOT_MATCH ) );
            }
        };
    }

    public static <T extends HasContract & HasVendor> Validator<T, ResultVO, RuntimeException> checkBrandIdMatchesCustomersVendor() {
        return checkBrandIdMatchesCustomersVendor( Optional.<CustomerCareResultCode>absent() );
    }

    public static Validator<? super CheckSimVO, ResultVO, ApplicationException> validateActivationCodeFromCheckSimAgainstIccIdFromAssignMsisdnAction(
            final IccId iccId ) {
        return new Validator<CheckSimVO, ResultVO, ApplicationException>() {
            @Override
            public ResultVO validate( CheckSimVO input ) throws ApplicationException {
                if( input.getActivationCode() == null ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                }
                String activationCode = iccId.getActivationCode();
                if( !input.getActivationCode().equals( activationCode ) ) {
                    return new ResultVO( MSISDN_AND_ACTIVATION_CODE_MAPPING_NOT_VALID );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<? super CheckSimVO, ResultVO, ApplicationException> validateIccIdFromCheckSimAgainstIccIdFromAssignMsisdnAction(
            final IccId iccId ) {
        return new Validator<CheckSimVO, ResultVO, ApplicationException>() {
            @Override
            public ResultVO validate( CheckSimVO input ) throws ApplicationException {
                if( input.getIccId() == null ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                }
                if( !input.getIccId().equals( iccId ) ) {
                    return ResultVO.forWrongOrMissingMandatoryParameter( "ICCID" );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the clientId is known
     */
    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkClientIsKnownAsGeneralSystemError() {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                if( CustomerCareClient.KNOWN_CUSTOMER_CARE_CLIENTS.contains( input.getClientId() ) ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                }

                debug( log, "ClientId does not exist." );
                return new ResultVO( GENERAL_SYSTEM_ERROR );
            }
        };
    }

    /**
     * checks that the clientId is known
     */
    public static Validator<HasClientId, ResultVO, RuntimeException> checkClientIsKnown() {
        return new Validator<HasClientId, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( HasClientId input ) {
                if( CustomerCareClient.KNOWN_CUSTOMER_CARE_CLIENTS.contains( input.getClientId() ) ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                }

                debug( log, "ClientId does not exist." );
                return new ResultVO( WRONG_OR_MISSING_MANDATORY_PARAMETERS,
                    WRONG_OR_MISSING_MANDATORY_PARAMETERS.getDocumentation() + " - ClientId" );
            }
        };
    }

    /**
     * checks that the salutation is either HERR or FRAU
     */
    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkSalutationIsValid() {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                if( input instanceof ModifyRegistrationDataRequestVo ) {
                    Salutation salutation = ( (ModifyRegistrationDataRequestVo) input ).getSalutation();
                    if( !Salutation.HERR_AND_FRAU.contains( salutation ) ) {
                        debug( log, "Received modifyRegistrationData with invalid salutation ", salutation );
                        return ResultVO.forWrongOrMissingMandatoryParameter( PrepaidITCustomerCareServicesConstants.PARAM_SALUTATION );
                    }
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkAgent() {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {

            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) throws RuntimeException {
                String agent = input.getAgent();
                if( agent != null
                        && ( agent.length() < PrepaidITCustomerCareServicesConstants.MIN_AGENT_LENGTH
                                || agent.length() > PrepaidITCustomerCareServicesConstants.MAX_AGENT_LENGTH ) ) {
                    return new ResultVO( WRONG_OR_MISSING_MANDATORY_PARAMETERS,
                        WRONG_OR_MISSING_MANDATORY_PARAMETERS.getDocumentation() +
                                " - " + PrepaidITCustomerCareServicesConstants.PARAM_AGENT );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the vendor is valid for the client
     *
     * Note: for CC versions since {@link CustomerCareVersion} version 10 a check is performed in the interceptors,
     *  but this does not include the match of the MSISDN to the client vendor
     */
    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkVendorIsAllowedForClient() {
        return checkVendorIsAllowedForClient( CustomerCareResultCode.MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM );
    }

    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkVendorIsAllowedForClient(
            final CustomerCareResultCode errorCode ) {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                PrepaidITCustomerCareServicesBaseValidator validator = getValidator();
                if( !validator.isMsisdnValidForClient( input ) ) {
                    return new ResultVO( errorCode );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkClientIsOneOf(
            final List<CustomerCareClient> allowedClients ) {
        return new Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( CustomerCareServicesRequestVo input ) {
                if( !allowedClients.contains( input.getClientId() ) ) {
                    return ResultVO.forWrongOrMissingMandatoryParameter( PrepaidITCustomerCareServicesConstants.PARAM_CLIENT_ID );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException> checkFrontendOrderIdAndFrontendSubscriptionIdArePresent() {
        return new Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( AbstractCrmOrderRequestVo input ) {
                if( isNullOrBlank( input.getFrontendOrderId() ) ) {
                    return ResultVO.forWrongOrMissingMandatoryParameter( "frontendOrderId" );
                } else if( isNullOrBlank( input.getFrontendSubscriptionId() ) ) {
                    return ResultVO.forWrongOrMissingMandatoryParameter( "frontendSubscriptionId" );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException> checkDataQualityIsNotCheckedUnknown() {
        return new Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( AbstractCrmOrderRequestVo input ) {
                if( input.getRegisterCustomerAction().isPresent()
                        && input.getRegisterCustomerAction().get().getAddressCheckQuality() == DataCheckQuality.CHECKED_UNKNOWN ) {
                    return new ResultVO( WRONG_OR_MISSING_MANDATORY_PARAMETERS,
                        "The address data quality check of CHECKED_UNKNOWN is not allowed when no SHIP_SIM CRM order action is present." );
                }

                if( input.getRegisterForDirectDebitAction().isPresent()
                        && input.getRegisterForDirectDebitAction().get().getBankAccount()
                            .getDataCheckQuality() == DataCheckQuality.CHECKED_UNKNOWN ) {
                    return new ResultVO( WRONG_OR_MISSING_MANDATORY_PARAMETERS,
                        "The bank data quality check of CHECKED_UNKNOWN is not allowed when no SHIP_SIM CRM order action is present." );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException> checkPostponeActivationIsSetForRegisterCustomer() {
        return new Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( AbstractCrmOrderRequestVo input ) {
                if( input.getRegisterCustomerAction().isPresent() ) {
                    CrmOrderRegisterCustomerActionVO crmOrderRegisterCustomerActionVO = input.getRegisterCustomerAction().get();
                    if( !crmOrderRegisterCustomerActionVO.isPostponeActivation() ) {
                        return ResultVO.forWrongOrMissingMandatoryParameter( "postponeActivation" );
                    }
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException> checkPuk2IsPresent() {
        return new Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( AbstractCrmOrderRequestVo input ) {
                boolean puk2OnDemandValidationForClient = input.getVersionInfo().isGreaterThanVersion( CustomerCareVersion.VERSION_15 );
                if( puk2OnDemandValidationForClient && input.getAssignMsisdnAction().isPresent() ) {
                    CrmOrderAssignMsisdnVo action = input.getAssignMsisdnAction().get();
                    return action.getPuk2().isPresent() ? new ResultVO( REQUEST_SUCCESSFUL ) : new ResultVO( PUK2_MISSING );
                }

                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException> checkAllowSyncCustomerDataValidationResponseIsNotPresent() {
        return new Validator<AbstractCrmOrderRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( AbstractCrmOrderRequestVo input ) {
                if( input.getAllowSyncCustomerDataValidationResponse().isPresent() ) {
                    return new ResultVO( WRONG_OR_MISSING_MANDATORY_PARAMETERS,
                        "The parameter allowSyncCustomerDataValidationResponse is only allowed when a SHIP_SIM CRM order action is present." );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<ChangeBankAccountRequestVO, ResultVO, RuntimeException> validateAccountOwner() {
        return new Validator<ChangeBankAccountRequestVO, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( ChangeBankAccountRequestVO request ) {
                String accountOwner = request.getDirectDebitBankAccountVO().getAccountOwner();
                if( !Strings.isNullOrEmpty( accountOwner ) ) {
                    return ResultVO.forWrongOrMissingMandatoryParameter( PrepaidITCustomerCareServicesConstants.PARAM_ACCOUNT_OWNER );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static Validator<ChangeBankAccountRequestVO, ResultVO, RuntimeException> validateNonGermanBankAccount() {
        return new Validator<ChangeBankAccountRequestVO, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( ChangeBankAccountRequestVO requestVo ) {
                Iban newIban = requestVo.getDirectDebitBankAccountVO().getIntBankAccountNumber();
                if( newIban != null && !newIban.isGermanIban() ) {
                    log.error( "Changing the bank account to a non german IBAN is not allowed. Affected contract: "
                            + requestVo.getContract() );
                    return new ResultVO( UNMAPPED_ERROR, "Changing to a non-german bank account is not allowed." );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    public static boolean checkParameterIsSet( String parameter ) {
        String trimmedParameter = CharMatcher.whitespace().trimFrom( Strings.nullToEmpty( parameter ) );
        return !( trimmedParameter.isEmpty() || "?".equals( trimmedParameter ) );
    }

    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkCustomerNationalityHasKnownCode(
            final CountryCodeValidationService validationService ) {
        return new CountryCodeValidator( validationService, PARAM_NATIONALITY ) {

            @Override
            protected Optional<CountryCode> getCountryCodeFromRequest( @Nonnull CustomerCareServicesRequestVo input ) {
                if( input instanceof HasCustomerDataVO ) {
                    HasCustomerDataVO request = (HasCustomerDataVO) input;
                    CustomerDataVo customerDataVo = request.getCustomerDataVo();
                    if( customerDataVo == null || customerDataVo.getPersonalDataVo() == null ) {
                        return Optional.absent();
                    }
                    return CountryCode.fromNullable( customerDataVo.getPersonalDataVo().getNationality() );
                }
                Log.debug( log, "Nationality validator called with invalid request ", input );
                return Optional.absent();
            }
        };
    }

    public static Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> checkCustomerContactAddressHasKnownCode(
            final CountryCodeValidationService validationService ) {
        return new CountryCodeValidator( validationService, PARAM_COUNTRY_CODE ) {

            @Override
            protected Optional<CountryCode> getCountryCodeFromRequest( @Nonnull CustomerCareServicesRequestVo input ) {
                Optional<AddressDataVo> addressDataVo = getAddressDataVo( input );
                return OptionalUtils.flatMap( addressDataVo, AddressDataVo.toCountryCode );
            }

            private Optional<AddressDataVo> getAddressDataVo( CustomerCareServicesRequestVo input ) {
                if( input instanceof HasCustomerDataVO ) {
                    HasCustomerDataVO request = (HasCustomerDataVO) input;
                    CustomerDataVo customerDataVo = request.getCustomerDataVo();
                    if( customerDataVo == null
                            || customerDataVo.getPersonalDataVo() == null
                            || customerDataVo.getPersonalDataVo().getAddressDataVo() == null ) {
                        return Optional.absent();
                    }
                    return Optional.of( customerDataVo.getPersonalDataVo().getAddressDataVo() );
                }
                if( input instanceof HasAddressDataVo ) {
                    return Optional.fromNullable( ( (HasAddressDataVo) input ).getAddressDataVo() );
                }
                Log.debug( log, "Contact Address country code validator called with invalid request ", input );
                return Optional.absent();
            }
        };
    }

    public static abstract class CountryCodeValidator extends Validator<CustomerCareServicesRequestVo, ResultVO, RuntimeException> {
        private final CountryCodeValidationService validationService;
        private final String parameterName;

        public CountryCodeValidator( CountryCodeValidationService validationService, String parameterName ) {
            this.validationService = validationService;
            this.parameterName = parameterName;
        }

        @Override
        public ResultVO validate( @Nonnull CustomerCareServicesRequestVo input ) {
            Optional<CountryCode> countryCode = getCountryCodeFromRequest( input );
            return validationService.isCountryCodeKnown( countryCode )
                    ? new ResultVO( REQUEST_SUCCESSFUL )
                    : ResultVO.forWrongOrMissingMandatoryParameter( parameterName );
        }

        protected abstract Optional<CountryCode> getCountryCodeFromRequest( @Nonnull CustomerCareServicesRequestVo input );
    }

    /**
     * checks that the ProductId is not null
     */
    public static Validator<GetPreContractualInformationRequestVo, ResultVO, RuntimeException> checkProductIdNotNull(
            final CustomerCareResultCode errorResultCode, @Nullable final String suffixToReasonMessage ) {
        return new Validator<GetPreContractualInformationRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( @Nonnull GetPreContractualInformationRequestVo input ) {
                if( input.getProducts() == null ) {
                    debug( log, "Product Id does not exist." );
                    String reasonMsg = Strings.isNullOrEmpty( suffixToReasonMessage ) ? errorResultCode.getDocumentation()
                            : ( errorResultCode.getDocumentation() + suffixToReasonMessage );
                    return new ResultVO( errorResultCode, reasonMsg );
                }
                return new ResultVO( REQUEST_SUCCESSFUL );
            }
        };
    }

    /**
     * checks that the NO_KITTED_PRODUCTS_FOUND
     */
    public static Validator<GetKittedProductsRequestVo, ResultVO, RuntimeException> checkKittedProduct(
            final CustomerCareResultCode errorResultCode ) {
        return new Validator<GetKittedProductsRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( @Nonnull GetKittedProductsRequestVo input ) {
                if( input.getIccId().isPresent() ) {
                    Optional<KittedData> kittedData = new KittedDataRepository().findLastKittedDataForIccId( input.getIccId().get() );
                    if( !kittedData.isPresent() ) {
                        debug( log, "No Kitted Product found." );
                        String reasonMsg = errorResultCode.getDocumentation();
                        return new ResultVO( errorResultCode, reasonMsg );
                    } else {
                        return new ResultVO( REQUEST_SUCCESSFUL );
                    }
                } else {
                    debug( log, "No Kitted Product found." );
                    String reasonMsg = errorResultCode.getDocumentation();
                    return new ResultVO( errorResultCode, reasonMsg );
                }
            }
        };
    }

    /**
     * checks that the ICCID_DOES_NOT_EXIST_IN_THE_SYSTEM
     */
    public static Validator<GetKittedProductsRequestVo, ResultVO, RuntimeException> checkIccid(
            final CustomerCareResultCode errorResultCode ) {
        return new Validator<GetKittedProductsRequestVo, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( @Nonnull GetKittedProductsRequestVo input ) {
                if( input.getIccId().isPresent() ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                } else {
                    debug( log, "Product Id does not exist." );
                    String reasonMsg = errorResultCode.getDocumentation();
                    return new ResultVO( errorResultCode, reasonMsg );
                }
            }
        };
    }

    /**
     * checks that the Customer is Active
     */
    public static <T extends HasContract & HasVendor> Validator<T, ResultVO, RuntimeException> checkCustomerActive(
            final CustomerCareResultCode errorResultCode ) {
        return new Validator<T, ResultVO, RuntimeException>() {
            @Override
            public ResultVO validate( @Nonnull T input ) {
                Contract contract = input.getContract();
                if( contract.isActive() ) {
                    return new ResultVO( REQUEST_SUCCESSFUL );
                } else {
                    debug( log, "Customer is not Active." );
                    String reasonMsg = errorResultCode.getDocumentation();
                    return new ResultVO( errorResultCode, reasonMsg );
                }
            }
        };
    }

}
