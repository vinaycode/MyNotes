package com.telefonica.prepaid.frontend.customercare.service;

import static com.google.common.collect.Lists.newArrayList;
import static com.telefonica.prepaid.common.log.Log.debug;
import static com.telefonica.prepaid.common.tags.ApplicationInterfaceTags.CustomerCare;
import static com.telefonica.prepaid.common.tags.UseCaseTags.DeleteBundle;
import static com.telefonica.prepaid.common.tags.UseCaseTags.GetCurrentProducts;
import static com.telefonica.prepaid.common.tags.UseCaseTags.SubscribeBundle;
import static com.telefonica.prepaid.common.tags.UseCaseTags.TopUp;
import static com.telefonica.prepaid.config.SpVendorChannelConfigParameter.ON_DEMAND_PUK2_REQUIRED;
import static com.telefonica.prepaid.config.SpVendorConfigParameter.CUSTOMER_AGREEMENT_REMINDER_INTERVAL;
import static com.telefonica.prepaid.config.SpVendorConfigParameter.MONTHLY_LIMIT_PERIOD;
import static com.telefonica.prepaid.config.SpVendorConfigParameter.SIM_SWAP_WARNING_SHOW_LAST_SIM_ORDERED_WITHIN_X_DAYS;
import static com.telefonica.prepaid.config.SpVendorConfigParameter.THIRD_PARTY_BARRINGS_ENABLED;
import static com.telefonica.prepaid.config.SpVendorConfigParameter.USE_EMAIL_VALIDATION;
import static com.telefonica.prepaid.crmorder.processing.CrmOrderProcessingBean.createCrmOrderResponseFromActionResults;
import static com.telefonica.prepaid.crmorder.processing.CrmOrderProcessingBean.createResponseForCrmRequestWithErrorForOneItem;
import static com.telefonica.prepaid.customercare.CustomerCareVersion.VERSION_8;
import static com.telefonica.prepaid.customercare.CustomerCareVersion.isPreviousVersion;
import static com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants.PARAM_MSISDN;
import static com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult.CrmOrderStep.BALANCE_VALIDATION;
import static com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult.CrmOrderStep.ITEM_COMPOSITION;
import static com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult.CrmOrderStep.ITEM_VALIDATION;
import static com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult.CrmOrderStep.TRIGGERING;
import static com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult.CrmOrderStep.VALIDATION_COMPLETE;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.BUNDLE_PROMOTION_NOT_OFFERED;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.CURRENT_IDV_FRAUD_STATUS_PROHIBITS_OPERATION;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.CURRENT_IDV_STATUS_PROHIBITS_OPERATION;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.CUSTOMER_DOES_NOT_HAVE_ANY_BUNDLE_SUBSCRIPTIONS;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.CUSTOMER_HAS_NO_PACK_SUBSCRIPTIONS;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.CUSTOMER_IS_NOT_ACTIVE;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.ELIGIBILITY_ERROR;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.GENERAL_SYSTEM_ERROR;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.IDENTITY_DATA_NOT_PRESENT;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.INSUFFICIENT_BALANCE;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.INVALID_COMBINATION_OF_PRODUCT_ACTIONS;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.INVALID_LIFECYCLE_STATE;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.INVALID_PAYMENT_METHOD_STATE;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.NO_PENDING_SEPA_MANDATE_FOUND;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.OPERATION_REJECTED_BY_CUSTOMER_CHECKING;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.PERMANENT_BACKEND_SYSTEM_ERROR;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.PRODUCT_DOES_NOT_EXIST;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.REQUEST_SUCCESSFUL;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.UNMAPPED_ERROR;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.USE_CASE_NOT_ALLOWED_FOR_CUSTOMER;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.WRONG_OR_MISSING_MANDATORY_PARAMETERS;
import static com.telefonica.prepaid.frontend.customercare.CustomerCareConfigHelper.isPreviousCustomerCareVersionActive;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkBrandIdMatchesCustomersVendor;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkClientIsKnown;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkClientIsKnownAsGeneralSystemError;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkContractIdNotNull;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkContractNotNull;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkContractOrIccIdNotNull;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkSalutationIsValid;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkTenantIdMatchesCustomersVendor;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.validateAccountOwner;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.validateNonGermanBankAccount;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtils.createErrorResponseForCancelPortingOrderResult;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtils.createErrorResponseForResubmitPortingDateResult;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtils.createErrorResponseFromPortingDeclarationException;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtils.getChurnVendor;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createErrorResponseAndFillCommonValuesAndContractData;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createErrorResponseForRequestWithMsisdn;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createResponse;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createResponseFromException;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createSuccessResponse;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createSuccessResponseWithContract;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.createWrongParameterErrorResponse;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.fillErrorResponseWithCommonValuesAndContractData;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.fillResponse;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.fillWithSuccessResult;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.fillWithWrongParameterError;
import static com.telefonica.prepaid.frontend.customercare.service.PrepaidITCustomerCareServicesBeanUtilsStatic.populateWithSuccessResultAndContractData;
import static com.telefonica.prepaid.frontend.customercare.validator.PrepaidITCustomerCareServicesBaseValidator.getValidator;
import static com.telefonica.prepaid.product.domain.AvailableProduct.dependsOnProduct;
import static com.telefonica.prepaid.subscription.cache.Customer.getCustomer;
import static java.util.Collections.emptyList;
import static java.util.Collections.singleton;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkCustomerActive;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.MSISDN_NOT_ACTIVE;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.NO_KITTED_PRODUCTS_FOUND;
import static com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode.ICCID_DOES_NOT_EXIST_IN_THE_SYSTEM;
import static com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants.PARAM_PRODUCTID;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkProductIdNotNull;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkIccid;
import static com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorBuildingBlocks.checkKittedProduct;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

import org.apache.log4j.Logger;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;

import de.danet.prepaid.domain.exceptions.BundleNotExistentException;
import de.danet.prepaid.domain.exceptions.MsisdnNotExistentException;
import de.danet.prepaid.domain.exceptions.PackPromotionException;
import de.danet.prepaid.domain.valueobjects.ConfigurationAgnosticVendor;
import de.danet.prepaid.domain.valueobjects.Vendor;
import de.danet.ta.prepaid.daogen.precom.dto.ContractMsisdnStatus;

import com.techmahindra.prepaid.ocs.OcsException;
import com.techmahindra.prepaid.prepaiditcustomercareservices.AbstractCrmOrderRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ActivateDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.BarUnbarAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelFailedPortingOutOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelFailedPortingOutOrderResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CancelPortingInOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeBankAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCLIPorCLIRRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerCommChannelRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeSIMRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeTariffRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeVoiceMailboxPINRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ChangeWhoCalledServiceRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreateCrmOrderRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreatePortingDeclarationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CreatePortingDeclarationResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderActionVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderChangeTariffVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderRegisterCustomerActionVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderRegisterDirectDebitVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.CrmOrderSubscribePackVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeactivateAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeactivateDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeleteBundleRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DeletePackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.DirectDebitRechargeOptionsResponseVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ExportAccountContactHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAccountBalanceRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailableBundlesRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailableBundlesResponseVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailablePacksRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetAvailableTariffRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetChurnCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentOrAvailableProductsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentPacksRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCurrentTariffRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetCustomerDataRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDSSEntryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetDirectDebitRechargeOptionsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetHandsetDelockDataRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetLastKnownQoSInformationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetLastKnownQoSInformationResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPackCounterStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPackHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPartnerBenefitPackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortInStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortingDeclarationResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPortingOutStatusRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetPreferredCommunicationChannelRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetSIMStatisticsRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.GetTariffChangeHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ImportAccountContactHistoryRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.NotifyAboutBankTransactionLegacyRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.PrepareClawbackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ProductActionResultVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.QueryCustomersRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResetAccountRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResubmitPortingDateRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResubmitPortingDateResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.ResultVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SimValidationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.StoreFailedRechargeAttemptRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SubscribeBundleRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.SubscribePackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UnsubscribePackRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdateFrontendRegistrationDateRequestVo;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingDeclarationRequestVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingDeclarationResponseVO;
import com.techmahindra.prepaid.prepaiditcustomercareservices.UpdatePortingInOrderRequestVO;

import com.telefonica.prepaid.common.AbstractBean;
import com.telefonica.prepaid.common.CustomerCareClient;
import com.telefonica.prepaid.common.ProductId;
import com.telefonica.prepaid.common.SepaMandateId;
import com.telefonica.prepaid.common.currency.MonetaryValue;
import com.telefonica.prepaid.common.db.DaoException;
import com.telefonica.prepaid.common.domain.VoId;
import com.telefonica.prepaid.common.errorhandling.Reject;
import com.telefonica.prepaid.common.errorhandling.exception.ApplicationException;
import com.telefonica.prepaid.common.errorhandling.exception.CrmOrderException;
import com.telefonica.prepaid.common.errorhandling.exception.ProductNotFoundException;
import com.telefonica.prepaid.common.errorhandling.exception.RegistrationResetException;
import com.telefonica.prepaid.common.errorhandling.exception.RegistrationResetException.RegistrationResetErrorType;
import com.telefonica.prepaid.common.errorhandling.exception.SepaMandateException;
import com.telefonica.prepaid.common.errorhandling.exception.WrongDirectDebitStateException;
import com.telefonica.prepaid.common.log.Log;
import com.telefonica.prepaid.common.service.EaiService;
import com.telefonica.prepaid.common.service.TmServiceLocal;
import com.telefonica.prepaid.common.tags.ApplicationInterface;
import com.telefonica.prepaid.common.tags.UseCase;
import com.telefonica.prepaid.common.util.ListUtils;
import com.telefonica.prepaid.common.util.OptionalUtils;
import com.telefonica.prepaid.communication.sms.SmsNotSentException;
import com.telefonica.prepaid.config.SpVendorChannelConfigParameter;
import com.telefonica.prepaid.contract.db.BasicContractUtil;
import com.telefonica.prepaid.contract.db.BasicContractUtilFactory;
import com.telefonica.prepaid.contract.domain.Contract;
import com.telefonica.prepaid.contract.domain.ContractIdMsisdnStatusVo;
import com.telefonica.prepaid.crmorder.CrmOrderLoggingUtil;
import com.telefonica.prepaid.crmorder.CrmOrderUtil;
import com.telefonica.prepaid.crmorder.domain.CrmOrder;
import com.telefonica.prepaid.crmorder.domain.CrmOrderItemInfo;
import com.telefonica.prepaid.crmorder.domain.CrmOrderShipSimVo;
import com.telefonica.prepaid.crmorder.processing.CrmOrderProcessingService;
import com.telefonica.prepaid.crmorder.service.CrmOrderServiceLocal;
import com.telefonica.prepaid.crmorder.validation.CrmOrderValidationService;
import com.telefonica.prepaid.customer.ContractNotActiveException;
import com.telefonica.prepaid.customer.identification.IdRegistrationDataVoConverter;
import com.telefonica.prepaid.customer.identity.IdentityPersonalDataService;
import com.telefonica.prepaid.customer.identity.IdvFraudManagementService;
import com.telefonica.prepaid.customer.identity.domain.NoAssociatedIdentityException;
import com.telefonica.prepaid.customer.identity.domain.PersonalDataModificationException;
import com.telefonica.prepaid.customer.identity.domain.WrongIdvFraudStatusException;
import com.telefonica.prepaid.customer.identity.domain.WrongIdvStatusException;
import com.telefonica.prepaid.customer.master.service.CustomerDataService;
import com.telefonica.prepaid.customer.master.service.CustomerService;
import com.telefonica.prepaid.customercare.CustomerCareVersion;
import com.telefonica.prepaid.customercare.PrepaidITCustomerCareServicesConstants;
import com.telefonica.prepaid.directdebit.DirectDebitRechargeOptionsService.DirectDebitRechargeOptionsVoAndGlobalSettings;
import com.telefonica.prepaid.directdebit.boundary.DirectDebitExternalSystemsException;
import com.telefonica.prepaid.directdebit.boundary.DirectDebitService;
import com.telefonica.prepaid.directdebit.boundary.OutOfSyncException;
import com.telefonica.prepaid.directdebit.domain.MonthlyLimitResetCycle;
import com.telefonica.prepaid.domain.common.Channel;
import com.telefonica.prepaid.domain.common.PortingOutDeclarationSource;
import com.telefonica.prepaid.domain.common.ProductType;
import com.telefonica.prepaid.domain.common.RoleId;
import com.telefonica.prepaid.domain.common.SubscriberSubscriptionStatus;
import com.telefonica.prepaid.domain.crm.CrmOrderActionType;
import com.telefonica.prepaid.domain.directdebit.DirectDebitBankAccountVo;
import com.telefonica.prepaid.domain.ocs.OcsResponse;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderActionResult;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderRegisterCustomerActionResult;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.CrmOrderStepResult.CrmOrderStep;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.CustomerCareNetworkErrorMapper;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.response.BundleChangeTypeVo;
import com.telefonica.prepaid.domain.prepaiditcustomercareservices.response.TenantBrandAssignmentElementVO;
import com.telefonica.prepaid.domain.valueobjects.PortingDeclarationVO;
import com.telefonica.prepaid.domain.valueobjects.PortingDeclarationVO.PortingDeclarationValidationResult;
import com.telefonica.prepaid.dto.productdynamic.ViewSubscriberSubscription;
import com.telefonica.prepaid.external.customercare.common.CustomerCareUtil;
import com.telefonica.prepaid.external.customercare.domain.ApplyCreditDebitRequestVo;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareResultCode;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesRequestVo;
import com.telefonica.prepaid.external.customercare.domain.CustomerCareServicesResponseVo;
import com.telefonica.prepaid.external.customercare.domain.IncompatiblePacksMap;
import com.telefonica.prepaid.external.customercare.domain.QoSInformationVo;
import com.telefonica.prepaid.external.lapi.domain.ExternalOrderId;
import com.telefonica.prepaid.external.ocs.domain.OcsQueryFlagsVo;
import com.telefonica.prepaid.external.ocs.domain.PackAndBalanceInfoVo;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderRequestVo;
import com.telefonica.prepaid.frontend.customercare.ValidateCrmOrderResponseVo;
import com.telefonica.prepaid.frontend.customercare.common.CustomerCareValidatorUtils;
import com.telefonica.prepaid.frontend.customercare.domain.ActivateReplacementSimRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.BrandConfigurationSimReplacementGracePeriodVo;
import com.telefonica.prepaid.frontend.customercare.domain.BrandConfigurationSimReplacementVo;
import com.telefonica.prepaid.frontend.customercare.domain.ConfirmSepaMandateRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.CrmOrderRegisterCustomerForDirectDebitActionResult;
import com.telefonica.prepaid.frontend.customercare.domain.CrmOrderShipSimActionResult;
import com.telefonica.prepaid.frontend.customercare.domain.CustomerCareServicesResponseWithAvailabilityVo;
import com.telefonica.prepaid.frontend.customercare.domain.CustomerCareUseCase;
import com.telefonica.prepaid.frontend.customercare.domain.DataCheckQuality;
import com.telefonica.prepaid.frontend.customercare.domain.DeregisterPaymentMethodRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetAvailableProductsResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCrdInformationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCrdInformationResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCurrentPacksResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCurrentProductsResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetCustomerDataForDataPortabilityRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetDynamicCustomerDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetDynamicCustomerDataResponseVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetEGNDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.HasLimitResponseTo;
import com.telefonica.prepaid.frontend.customercare.domain.ModifyRegistrationDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.NotifyAboutSuccessfulReverificationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.NotifyCustomerDirectDebitLimitExceededLegacyRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.ProductSubscriptionsListVo;
import com.telefonica.prepaid.frontend.customercare.domain.ResetRegistrationDataRequestVo;
import com.telefonica.prepaid.frontend.customercare.subscription.ActivateReplacementSimRequestProcessor;
import com.telefonica.prepaid.frontend.customercare.validator.CustomerCareAvailableUseCases;
import com.telefonica.prepaid.frontend.customercare.validator.PackBaseValidator;
import com.telefonica.prepaid.frontend.customercare.validator.PrepaidITCustomerCareServicesBaseValidator;
import com.telefonica.prepaid.frontend.payment.domain.NotifyAboutBankTransactionRequestVo;
import com.telefonica.prepaid.frontend.payment.domain.NotifyCustomerDirectDebitLimitExceededRequestVo;
import com.telefonica.prepaid.frontend.payment.domain.PrepareClawbackRequestVo;
import com.telefonica.prepaid.frontend.payment.domain.StoreFailedRechargeAttemptRequestVo;
import com.telefonica.prepaid.frontend.payment.service.PrepaidApiPaymentService;
import com.telefonica.prepaid.infrastructure.logging.LogInterceptor;
import com.telefonica.prepaid.infrastructure.workflow.lock.WorkflowLockNotAcquiredException;
import com.telefonica.prepaid.kitting.KittedDataRepository;
import com.telefonica.prepaid.kitting.domain.KittedData;
import com.telefonica.prepaid.payment.PaymentMethodVendorConfigurationService;
import com.telefonica.prepaid.porting.out.CancelFailedPortingOutOrderException;
import com.telefonica.prepaid.porting.out.ResubmitPortingDateException;
import com.telefonica.prepaid.porting.service.PortingService;
import com.telefonica.prepaid.prepaiditcustomercareservices.ActivateContractRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetBrandConfigurationRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetBrandConfigurationResponseVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetCurrentBundleRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.GetCurrentBundleResponseVo;
import com.telefonica.prepaid.prepaiditcustomercareservices.SearchTenantBrandAssignmentRequestVO;
import com.telefonica.prepaid.prepaiditcustomercareservices.SearchTenantBrandAssignmentResponseVO;
import com.telefonica.prepaid.preprovisioning.domain.ProvisioningType;
import com.telefonica.prepaid.product.crd.AvailableProductWithCrdInfo;
import com.telefonica.prepaid.product.domain.AvailableProduct;
import com.telefonica.prepaid.product.domain.EmptyProductVisitor;
import com.telefonica.prepaid.product.domain.Product;
import com.telefonica.prepaid.product.domain.ProductSubscription;
import com.telefonica.prepaid.product.pack.PackProduct;
import com.telefonica.prepaid.product.service.ProductCacheService;
import com.telefonica.prepaid.product.service.ProductServiceLocal;
import com.telefonica.prepaid.product.tariff.TariffProduct;
import com.telefonica.prepaid.registration.RegistrationResetServiceLocal;
import com.telefonica.prepaid.shipment.domain.SimShipmentStatus;
import com.telefonica.prepaid.shipment.frontend.customercare.activate.contract.ActivateContractRequestProcessor;
import com.telefonica.prepaid.shipment.service.SimShipmentHistoryService;
import com.telefonica.prepaid.shipment.workflow.WorkflowOrderEventHistoryService;
import com.telefonica.prepaid.subscription.bundle.BundleRequestService;
import com.telefonica.prepaid.subscription.cache.Customer;
import com.telefonica.prepaid.subscription.pack.PackProductSubscription;
import com.telefonica.prepaid.subscription.pack.counters.QueryCountersService;
import com.telefonica.prepaid.subscription.sim.service.ContractWithProvisioningDataService;
import com.telefonica.prepaid.subscription.sim.service.ContractWithProvisioningDataService.ContractWithProvisioningData;
import com.telefonica.prepaid.usage.GetTopUpsRequestVo;
import com.telefonica.prepaid.vendor.VendorChannelConfigService;
import com.telefonica.prepaid.vendor.config.VendorConfigService;
import com.telefonica.prepaid.frontend.customercare.domain.GetKittedProductsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetKittedProductsResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetNonEECCRelevantProductsForBrandRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetNonEECCRelevantProductsForBrandResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetPreContractualInformationRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.GetPreContractualInformationResultVo;
import com.telefonica.prepaid.frontend.customercare.domain.RequestEmailAddressPerSmsRequestVo;
import com.telefonica.prepaid.frontend.customercare.domain.RequestEmailAddressPerSmsResultVo;

@Stateless
@Interceptors( { VersionValidationInterceptor.class, LogInterceptor.class } )
@Local( value = CustomerCareServicesLocal.class )
@Remote( value = CustomerCareServicesRemote.class )
@ApplicationInterface( CustomerCare )
public class CustomerCareServicesBean extends AbstractBean implements CustomerCareServices {
    private static final String ERROR_REASON_MESSSAGE_CRM_ORDER_ACTIONS_NOT_ADMISSIBLE = "Composition of actions not supported";

    private static final Logger log = Logger.getLogger( CustomerCareServicesBean.class );

    @Inject
    private PrepaidApiPaymentService prepaidApiPaymentService;

    @Resource( type = SessionContext.class )
    protected SessionContext ctx;
    @EJB
    PortingService portingBean;
    @EJB
    protected TmServiceLocal tmService;
    @Inject
    protected CustomerService customerService;
    @EJB
    protected CustomerDataService customerDataService;
    @EJB
    protected EaiService eaiService;
    @EJB
    protected ProductServiceLocal productService;
    @EJB
    private CrmOrderProcessingService crmOrderProcessingService;
    @EJB
    private CrmOrderValidationService crmOrderValidationService;
    @EJB
    private CrmOrderServiceLocal crmOrderService;
    @EJB
    private BundleRequestService bundleRequestService;
    @EJB
    protected ProductCacheService productCache;
    @EJB
    DirectDebitService directDebitService;
    @EJB
    private WorkflowOrderEventHistoryService onlineOrderEventHistoryService;
    @EJB
    RegistrationResetServiceLocal registrationResetService;
    @Inject
    private ChangeCustomerDataRequestProcessor changeCustomerDataRequestProcessor;
    @Inject
    private ActivateContractRequestProcessor activateContractRequestProcessor;
    @Inject
    private CustomerCareAvailableUseCases customerCareAvailableUseCases;
    @Inject
    private VendorConfigService vendorConfigService;
    @Inject
    private VendorChannelConfigService vendorChannelConfigService;
    @Inject
    private KittedDataRepository kittedDataRepository;

    @Inject
    @VisibleForTesting
    PrepaidITCustomerCareServicesBeanUtilsWithTm beanUtils;
    @Inject
    private SimShipmentHistoryService simShipmentHistoryService;
    @Inject
    private ContractWithProvisioningDataService contractWithProvisioningDataService;
    @Inject
    private ActivateReplacementSimRequestProcessor activateReplacementSimRequestProcessor;
    @Inject
    private QueryCountersService queryCountersService;
    @Inject
    private IdvFraudManagementService idvFraudManagementService;
    @Inject
    private PaymentMethodVendorConfigurationService paymentMethodConfigService;
    @Inject
    private IdentityPersonalDataService identityPersonalDataService;
    @Inject
    private IdRegistrationDataVoConverter idRegistrationDataVoConverter;

    @Override
    public CustomerCareServicesResponseVo importAccountContactHistory( ImportAccountContactHistoryRequestVO requestVo ) {
        return new RequestProcessor<ImportAccountContactHistoryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.importAccountContactHistory( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo exportAccountContactHistory( ExportAccountContactHistoryRequestVO requestVo ) {
        return new RequestProcessor<ExportAccountContactHistoryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                if( requestVo.getContract().isNotProvisioned() || !requestVo.getContract().getVendor().equals( requestVo.getVendor() ) ) {
                    Contract currentContract = requestVo.getContract();
                    requestVo.setContract( BasicContractUtilFactory.getBasicContractUtil( daos ).getContractWithVendorPreference(
                        requestVo.getContract().getMsisdn(), requestVo.getVendor(), false ) );
                    if( requestVo.getContract() == null ) {
                        requestVo.setContract( currentContract );
                    }
                }
                responseVo = beanUtils.exportAccountContactHistory( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getSIMInfo( CustomerCareServicesRequestVo requestVo ) {
        return new RequestProcessor<CustomerCareServicesRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getSIMInfo( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo applyCreditDebit( ApplyCreditDebitRequestVo requestVo ) {
        return new RequestProcessor<ApplyCreditDebitRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.applyCreditDebit( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getAccountBalance( GetAccountBalanceRequestVO requestVo ) {
        return new RequestProcessor<GetAccountBalanceRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getAccountBalance( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getAvailablePacks( GetAvailablePacksRequestVO requestVo ) {
        return new RequestProcessor<GetAvailablePacksRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getAvailablePacks( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo validateSim( SimValidationRequestVO requestVo ) {
        return new RequestProcessor<SimValidationRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.validateSim( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo deletePack( DeletePackRequestVO requestVo ) {
        return new RequestProcessor<DeletePackRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.deletePack( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getPackHistory( GetPackHistoryRequestVO requestVo ) {
        return new RequestProcessor<GetPackHistoryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getPackHistory( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getPortingOutStatus( GetPortingOutStatusRequestVO requestVo ) {
        return new RequestProcessor<GetPortingOutStatusRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getPortingOutStatus( requestVo );
            }
        }.processRequest();
    }

    @Override
    @Interceptors( { TraceLogInterceptor.class } )
    public CustomerCareServicesResponseVo subscribePack( SubscribePackRequestVO requestVo ) {
        return new RequestProcessor<SubscribePackRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.subscribePack( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo unsubscribePack( UnsubscribePackRequestVO requestVo ) {
        return new RequestProcessor<UnsubscribePackRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.unsubscribePack( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo changeCLIPorCLIR( ChangeCLIPorCLIRRequestVO requestVo ) {
        return new RequestProcessor<ChangeCLIPorCLIRRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.changeCLIPorCLIR( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo changeVoiceMailboxPIN( ChangeVoiceMailboxPINRequestVO requestVo ) {
        return new RequestProcessor<ChangeVoiceMailboxPINRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.changeVoiceMailboxPIN( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getPackCounterStatus( GetPackCounterStatusRequestVO requestVo ) {
        return new RequestProcessor<GetPackCounterStatusRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getPackCounterStatus( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo changeWhoCalledService( ChangeWhoCalledServiceRequestVO requestVo ) {
        return new RequestProcessor<ChangeWhoCalledServiceRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.changeWhoCalledService( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo barUnbarAccount( BarUnbarAccountRequestVO requestVo ) {
        return new RequestProcessor<BarUnbarAccountRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.barUnbarAccount( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo createPortingDeclaration( CreatePortingDeclarationRequestVO requestVO ) {
        CreatePortingDeclarationResponseVO response;
        try {
            CustomerCareVersion version = requestVO.getVersionInfo();
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkTenantIdMatchesCustomersVendor() )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkBrandIdMatchesCustomersVendor() )
                .validate( requestVO );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVO, resultVo );
            }

            PortingDeclarationVO portingDeclarationVO = portingBean.createPortingDeclaration( requestVO.getContract(),
                requestVO.getPortingDeclarationStartDate(), requestVO.isServiceContinuityFlag(),
                requestVO.getAgent(), "",
                PortingOutDeclarationSource.CUSTOMER_CARE );

            if( PortingDeclarationValidationResult.SUCCESS == portingDeclarationVO.getValidationResult() ) {
                response = populateWithSuccessResultAndContractData( requestVO,
                    new CreatePortingDeclarationResponseVO( portingDeclarationVO ) );
            } else {
                response = createErrorResponseFromPortingDeclarationException( requestVO,
                    portingDeclarationVO.getValidationResult(), new CreatePortingDeclarationResponseVO() );
            }
        } catch( ApplicationException e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVO,
                GENERAL_SYSTEM_ERROR, new CreatePortingDeclarationResponseVO() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo updatePortingDeclaration( UpdatePortingDeclarationRequestVO requestVO ) {
        CustomerCareServicesResponseVo response;
        try {
            CustomerCareVersion version = requestVO.getVersionInfo();
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkTenantIdMatchesCustomersVendor() )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkBrandIdMatchesCustomersVendor() )
                .validate( requestVO );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVO, resultVo );
            }

            PortingDeclarationVO portingDeclarationVO = portingBean.updatePortingDeclaration( requestVO.getContract(),
                requestVO.getPortingDeclarationStartDate(), requestVO.isServiceContinuityFlag(),
                requestVO.getAgent(), "",
                PortingOutDeclarationSource.CUSTOMER_CARE );

            if( PortingDeclarationValidationResult.SUCCESS == portingDeclarationVO.getValidationResult() ) {
                response = populateWithSuccessResultAndContractData( requestVO, new UpdatePortingDeclarationResponseVO(
                    portingDeclarationVO ) );
            } else {
                response = createErrorResponseFromPortingDeclarationException( requestVO,
                    portingDeclarationVO.getValidationResult(), new UpdatePortingDeclarationResponseVO() );
            }
        } catch( ApplicationException e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVO,
                GENERAL_SYSTEM_ERROR, new UpdatePortingDeclarationResponseVO() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo getPortingDeclaration( CustomerCareServicesRequestVo requestVO ) {
        CustomerCareServicesResponseVo response;
        try {
            CustomerCareVersion version = requestVO.getVersionInfo();
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkTenantIdMatchesCustomersVendor() )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkBrandIdMatchesCustomersVendor() )
                .validate( requestVO );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVO, resultVo );
            }

            PortingDeclarationVO portingDeclarationVO = portingBean.getPortingDeclaration( requestVO.getContract(),
                true );

            if( PortingDeclarationValidationResult.SUCCESS == portingDeclarationVO.getValidationResult() ) {
                response = populateWithSuccessResultAndContractData( requestVO,
                    new GetPortingDeclarationResponseVO( portingDeclarationVO ) );
            } else {
                response = createErrorResponseFromPortingDeclarationException( requestVO,
                    portingDeclarationVO.getValidationResult(), new GetPortingDeclarationResponseVO() );
            }
        } catch( ApplicationException e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVO, GENERAL_SYSTEM_ERROR,
                new GetPortingDeclarationResponseVO() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo removePortingDeclaration( CustomerCareServicesRequestVo requestVO ) {
        CustomerCareServicesResponseVo response;
        try {
            CustomerCareVersion version = requestVO.getVersionInfo();
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkTenantIdMatchesCustomersVendor() )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkBrandIdMatchesCustomersVendor() )
                .validate( requestVO );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVO, resultVo );
            }

            PortingDeclarationValidationResult result = portingBean.removePortingDeclaration( requestVO.getContract(),
                requestVO.getAgent(), "", PortingOutDeclarationSource.CUSTOMER_CARE );
            if( PortingDeclarationValidationResult.SUCCESS == result ) {
                response = createSuccessResponseWithContract( requestVO );
            } else {
                response = createErrorResponseFromPortingDeclarationException( requestVO, result );
            }
        } catch( ApplicationException e ) { // NOSONAR
            response = createErrorResponseAndFillCommonValuesAndContractData( requestVO, GENERAL_SYSTEM_ERROR );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo resubmitPortingDate( ResubmitPortingDateRequestVO requestVO ) {
        ResubmitPortingDateResponseVO response;
        try {
            CustomerCareVersion version = requestVO.getVersionInfo();
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkTenantIdMatchesCustomersVendor() )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkBrandIdMatchesCustomersVendor() )
                .validate( requestVO );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVO, resultVo );
            }

            portingBean.resubmitPortingOutDate( requestVO.getContract(), requestVO.getRequestedPortingDate() );
            response = populateWithSuccessResultAndContractData( requestVO, new ResubmitPortingDateResponseVO() );
            response.setAdjustedPortingDate( requestVO.getRequestedPortingDate() );
        } catch( ResubmitPortingDateException e ) {
            response = createErrorResponseForResubmitPortingDateResult( requestVO, e );
        } catch( ApplicationException e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVO, GENERAL_SYSTEM_ERROR,
                new ResubmitPortingDateResponseVO() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo cancelFailedPortingOutOrder( CancelFailedPortingOutOrderRequestVO requestVO ) {
        CancelFailedPortingOutOrderResponseVO response;
        try {
            CustomerCareVersion version = requestVO.getVersionInfo();
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkTenantIdMatchesCustomersVendor() )
                .nextIf( version.isGreaterThanVersion( VERSION_8 ),
                    checkBrandIdMatchesCustomersVendor() )
                .validate( requestVO );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVO, resultVo );
            }

            portingBean.cancelFailedPortingOutOrder( requestVO.getContract(), requestVO.getPortingOrderId() );
            response = populateWithSuccessResultAndContractData( requestVO, new CancelFailedPortingOutOrderResponseVO() );
        } catch( CancelFailedPortingOutOrderException e ) {
            response = createErrorResponseForCancelPortingOrderResult( requestVO, e );
        } catch( ApplicationException | DaoException e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVO, GENERAL_SYSTEM_ERROR,
                new CancelFailedPortingOutOrderResponseVO() );
        }

        return response;
    }

    @Override
    public CustomerCareServicesResponseVo getPortingInStatus( GetPortInStatusRequestVO requestVo ) {
        return new RequestProcessor<GetPortInStatusRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getPortingInStatus( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo updatePortInRequest( UpdatePortingInOrderRequestVO requestVo ) {
        return new RequestProcessor<UpdatePortingInOrderRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.updatePortInRequest( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo cancelPortInRequest(
            CancelPortingInOrderRequestVO requestVo, final boolean performAdditionalValidation ) {
        return new RequestProcessor<CancelPortingInOrderRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.cancelPortInRequest( requestVo, performAdditionalValidation );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo resetAccount( ResetAccountRequestVO requestVo ) {
        return new RequestProcessor<ResetAccountRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.resetAccount( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo deactivateAccount( DeactivateAccountRequestVO requestVo ) {
        return new RequestProcessor<DeactivateAccountRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.deactivateAccount( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getEGNData( GetEGNDataRequestVo requestVo ) {
        return new RequestProcessor<GetEGNDataRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getEGNData( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getTopUps( GetTopUpsRequestVo requestVo ) {
        return new RequestProcessor<GetTopUpsRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getTopUps( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo changeCustomerData( ChangeCustomerDataRequestVO requestVo ) {
        return changeCustomerDataRequestProcessor.process( requestVo );
    }

    @Override
    public CustomerCareServicesResponseVo showVoicemailboxPINStatus( CustomerCareServicesRequestVo requestVo ) {
        return new RequestProcessor<CustomerCareServicesRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.showVoicemailboxPINStatus( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getCustomerData( GetCustomerDataRequestVO requestVo ) {
        return new RequestProcessor<GetCustomerDataRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {

                Contract contract = fillInProperContractIdMsisdnVoEcrmSafe( requestVo );
                if( contract != null && !Objects.equals( contract.getMsisdn(), requestVo.getContract().getMsisdn() ) ) {
                    responseVo = createWrongParameterErrorResponse( requestVo,
                        PrepaidITCustomerCareServicesConstants.INACTIVE_MSISDN_AFTER_PORTING_IN );
                    return;
                }
                addContractToRequest( requestVo, contract );
                responseVo = beanUtils.getCustomerData( requestVo );
                updateChannelIfAvailable( responseVo, requestVo );
            }
        }.processRequest();
    }

    private void updateChannelIfAvailable( CustomerCareServicesResponseVo response,
            CustomerCareServicesRequestVo request ) {
        if( request.getChannel() != null ) {
            response.setChannel( request.getChannel() );
        }
    }

    @Override
    public CustomerCareServicesResponseVo getNetworkServiceStatus( CustomerCareServicesRequestVo requestVo ) {
        return new RequestProcessor<CustomerCareServicesRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getNetworkServiceStatus( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getDSSEntry( GetDSSEntryRequestVO requestVo ) {
        return new RequestProcessor<CustomerCareServicesRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getDSSEntry( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getChurnCustomerData( GetChurnCustomerDataRequestVO requestVo ) {
        return new RequestProcessor<GetChurnCustomerDataRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getChurnCustomerData( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo searchCustomers( QueryCustomersRequestVO requestVo ) {
        return new RequestProcessor<QueryCustomersRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                Vendor vendor = requestVo.getVendor();
                responseVo = beanUtils.queryCustomers( vendor != null ? vendor : getChurnVendor( requestVo ), requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo changeSIM( ChangeSIMRequestVO requestVo ) {
        return new RequestProcessor<ChangeSIMRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.changeSIM( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getAvailablePacks1( GetAvailablePacksRequestVO requestVo ) {
        return new RequestProcessor<GetAvailablePacksRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getAvailablePacks( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getCurrentPacks( GetCurrentPacksRequestVO requestVo ) {
        log.debug( "Entering PrepaidITCustomerCareServicesBean.getCurrentPacks" );
        try {
            ResultVO resultVo = CustomerCareValidatorUtils
                .checkMsisdnAndVendor( requestVo.getVersionInfo() )
                .next( checkClientIsKnown() )
                .validate( requestVo );

            if( resultVo.isFailure() ) {
                return createResponse( resultVo, requestVo );
            }
            CustomerCareServicesResponseVo prepaidServicesResponseVO = PackBaseValidator.validateGetCurrentPackRequest( requestVo );
            if( !prepaidServicesResponseVO.isSuccess() ) {
                return prepaidServicesResponseVO;
            }

            Customer customer = getCustomer( daos, requestVo.getContract(), productCache );
            List<PackProductSubscription> currentPacks = tmService.getCurrentPacks( customer, requestVo.getChannel() );
            return constructGetCurrentPacksResponse( customer, requestVo, currentPacks );
        } catch( Exception e ) {
            return createResponseFromException( e, requestVo );
        }
    }

    private CustomerCareServicesResponseVo constructGetCurrentPacksResponse( Customer customer,
            GetCurrentPacksRequestVO requestVo, List<PackProductSubscription> currentPacks ) throws ApplicationException {
        if( currentPacks.isEmpty() ) {
            return createResponse( CUSTOMER_HAS_NO_PACK_SUBSCRIPTIONS, requestVo );
        }
        GetCurrentPacksResponseVo currentPacksResponseVO = fillWithSuccessResult( new GetCurrentPacksResponseVo(), requestVo );
        currentPacksResponseVO.setPackSubscriptions( currentPacks );
        addIncompatiblePacks( customer, requestVo, currentPacksResponseVO.getIncompatiblePacksMap(), currentPacks );

        return currentPacksResponseVO;
    }

    @Override
    public CustomerCareServicesResponseVo activateDSSEntry( ActivateDSSEntryRequestVO requestVo ) {
        return new RequestProcessor<ActivateDSSEntryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.activateDSSEntry( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getSIMHistory( GetSIMHistoryRequestVO requestVo ) {
        return new RequestProcessor<GetSIMHistoryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getSIMHistory( requestVo );
            }
        }.processRequest();
    }

    private Vendor getVendorFromGetSIMStatisticsRequestVO( GetSIMStatisticsRequestVO requestVo ) {
        Vendor vendor;
        if( requestVo.getVersionInfo().isAtMostVersion( VERSION_8 ) ) {
            vendor = requestVo.getClientId() != CustomerCareClient.TCHIBO ? ConfigurationAgnosticVendor.PEPS
                    : ConfigurationAgnosticVendor.TCHIBO;
        } else {
            vendor = requestVo.getVendor();
        }
        return vendor;
    }

    @Override
    public CustomerCareServicesResponseVo getSIMStatistics( GetSIMStatisticsRequestVO requestVo ) {
        return new RequestProcessor<GetSIMStatisticsRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                Vendor vendor = getVendorFromGetSIMStatisticsRequestVO( requestVo );
                responseVo = beanUtils.getSIMStatistics( requestVo, vendor );
            }

        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo deactivateDSSEntry( DeactivateDSSEntryRequestVO requestVo ) {
        return new RequestProcessor<DeactivateDSSEntryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                fillInProperContractIdMsisdnVo( requestVo );
                responseVo = beanUtils.deactivateDSSEntry( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getPreferredCommunicationChannel( GetPreferredCommunicationChannelRequestVO requestVo ) {
        return new RequestProcessor<GetPreferredCommunicationChannelRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                fillInProperContractIdMsisdnVo( requestVo );
                responseVo = beanUtils.getPreferredCommunicationChannel( requestVo );
            }
        }.processRequest();
    }

    /**
     * This method calls getPartnerBenefitPack of PrepaidITCustomerCareServicesBeanUtils.
     * It is invoked by getPartnerBenefitPack operation of the webservice, and returns the partner benefit pack
     * subscription id
     * for a given combination of amount, service type and campaign id.
     */
    @Override
    public CustomerCareServicesResponseVo getPartnerBenefitPack( GetPartnerBenefitPackRequestVO requestVo ) {
        return new RequestProcessor<GetPartnerBenefitPackRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getPartnerBenefitPack( requestVo );
            }
        }.processRequest();
    }

    /**
     * This method is used to activate or deactivate SMS or EMAIL communication channels of Customer
     */
    @Override
    public CustomerCareServicesResponseVo changeCustomerCommChannel( ChangeCustomerCommChannelRequestVO requestVo ) {
        return new RequestProcessor<ChangeCustomerCommChannelRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = CustomerCareServicesResponseVo.createGeneralSystemError();
                fillInProperContractIdMsisdnVoNullSafe( requestVo );
                responseVo = beanUtils.changeCustomerCommChannel( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo changeTariff( ChangeTariffRequestVO requestVo ) {
        return new RequestProcessor<ChangeTariffRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                ResultVO resultVO = CustomerCareValidatorUtils
                    .checkMsisdnAndVendor( requestVo.getVersionInfo() )
                    .next( checkClientIsKnownAsGeneralSystemError() )
                    .validate( requestVo );

                if( resultVO.isFailure() ) {
                    responseVo = createResponse( resultVO, requestVo );
                } else {
                    responseVo = beanUtils.changeTariff( requestVo );
                }
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getAvailableTariff( GetAvailableTariffRequestVO requestVo ) {
        return new RequestProcessor<GetAvailableTariffRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = CustomerCareServicesResponseVo.createGeneralSystemError();
                fillInProperContractIdMsisdnVoNullSafe( requestVo );
                responseVo = beanUtils.getAvailableTariff( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getRechargeOptions( GetDirectDebitRechargeOptionsRequestVO requestVo ) {
        return new RequestProcessor<GetDirectDebitRechargeOptionsRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                ResultVO validationResult = checkContractIdNotNull( CustomerCareResultCode.MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM )
                    .next( checkBrandIdMatchesCustomersVendor() )
                    .validate( requestVo );

                if( validationResult.isFailure() ) {
                    responseVo = createErrorResponseAndFillCommonValuesAndContractData( requestVo, validationResult );
                } else {
                    fillInProperContractIdMsisdnVoNullSafe( requestVo );
                    DirectDebitRechargeOptionsVoAndGlobalSettings directDebitRechargeOptions = directDebitService
                        .getDirectDebitRechargeOptions( requestVo.getContract(), requestVo.getChannel() );
                    responseVo = new DirectDebitRechargeOptionsResponseVo();
                    responseVo.setContract( requestVo.getContract() );
                    DirectDebitRechargeOptionsResponseVo rechargeOptionsResponseVo = (DirectDebitRechargeOptionsResponseVo) this.responseVo;
                    rechargeOptionsResponseVo.setSelectedRechargeOptions( directDebitRechargeOptions.getDirectDebitRechargeOptions() );
                    rechargeOptionsResponseVo.setAvailableRechargeOptions( directDebitRechargeOptions.getAvailableRechargeOptions() );
                    rechargeOptionsResponseVo.setAllowedOnDemandRechargeValues( directDebitRechargeOptions.getDirectDebitRechargeValues() );

                    CustomerCareResultCode requestSuccessful = CustomerCareResultCode.REQUEST_SUCCESSFUL;
                    responseVo.setResultCode( requestSuccessful );
                    responseVo.setReasonMsg( requestSuccessful.getDocumentation() );
                }
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getTariffChangeHistory( GetTariffChangeHistoryRequestVO requestVo ) {
        return new RequestProcessor<GetTariffChangeHistoryRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = CustomerCareServicesResponseVo.createGeneralSystemError();
                fillInProperContractIdMsisdnVoNullSafe( requestVo );
                responseVo = beanUtils.getTariffChangeHistory( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getLastKnownQoSInformation( GetLastKnownQoSInformationRequestVO requestVo ) {
        return new RequestProcessor<GetLastKnownQoSInformationRequestVO, GetLastKnownQoSInformationResponseVO>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getLastKnownQoSInformation( requestVo );
            }

            @Override
            public void handleError() {
                responseVo = fillErrorResponseWithCommonValuesAndContractData( requestVo,
                    GENERAL_SYSTEM_ERROR,
                    new GetLastKnownQoSInformationResponseVO() );
            }
        }.processRequest();
    }

    private void fillInProperContractIdMsisdnVo( CustomerCareServicesRequestVo requestVo ) {
        Contract possiblyIncompleteContractIdMsisdnVo = requestVo.getContract();
        Contract contractIdMsisdnVo = BasicContractUtilFactory.getBasicContractUtil( daos )
            .getContractDetailsFromActiveMsisdn( possiblyIncompleteContractIdMsisdnVo.getMsisdn() );
        if( contractIdMsisdnVo != null ) {
            requestVo.setContract( contractIdMsisdnVo );
        }
    }

    private Contract fillInProperContractIdMsisdnVoEcrmSafe( CustomerCareServicesRequestVo requestVo ) {
        Contract possiblyIncompleteMsisdnVo = requestVo.getContract();

        BasicContractUtil basicContractUtil = BasicContractUtilFactory.getBasicContractUtil( daos );
        if( !possiblyIncompleteMsisdnVo.isNotProvisioned() ) {
            if( !requestVo.getVendor().equals( requestVo.getContract().getVendor() ) ) {
                return basicContractUtil
                    .getContractWithVendorPreference( requestVo.getContract().getMsisdn(), requestVo.getVendor(), false );
            }
            return possiblyIncompleteMsisdnVo;
        }
        boolean allowUnassigned = CustomerCareUtil.isECrm( requestVo ) || requestVo.getChannel() == Channel.CS;
        Contract contract = basicContractUtil
            .getContractDetailsFromMsisdnMnpSafe( possiblyIncompleteMsisdnVo.getMsisdn(), !allowUnassigned, requestVo.getVendor() );
        if( contract != null || allowUnassigned ) {
            return contract;
        }
        return possiblyIncompleteMsisdnVo;
    }

    private void addContractToRequest( CustomerCareServicesRequestVo requestVo, Contract contract ) {
        if( contract != null ) {
            requestVo.setContract( contract );
        }
    }

    @VisibleForTesting
    void fillInProperContractIdMsisdnVoNullSafe( CustomerCareServicesRequestVo requestVo ) {
        if( requestVo.getContract() != null ) {
            requestVo.setContract( BasicContractUtilFactory.getBasicContractUtil( daos ).getContractDetailsFromActiveMsisdn( requestVo
                .getContract().getMsisdn() ) );
        }
    }

    @Override
    public CustomerCareServicesResponseVo getCurrentTariff( GetCurrentTariffRequestVO requestVo ) {
        return new RequestProcessor<GetCurrentTariffRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getCurrentTariff( requestVo );
            }
        }.processRequest();
    }

    @Override
    @UseCase( SubscribeBundle )
    public CustomerCareServicesResponseVo subscribeBundle( SubscribeBundleRequestVo requestVO ) {
        Contract contract = requestVO.getContract();
        try {
            CustomerCareServicesResponseVo validationError = beanUtils.validateBundleRequest( requestVO );
            if( validationError != null ) {
                return validationError;
            }

            PrepaidITCustomerCareServicesBaseValidator validator = getValidator();
            if( !validator.isMsisdnValidForClient( requestVO, true ) ) {
                return createResponse( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM, requestVO );
            }

            CustomerCareClient clientId = requestVO.getClientId();
            int bundleId = beanUtils.extractBundleSubscriptionId( requestVO );
            bundleRequestService.subscribeBundleCustomerCareAndSebula( requestVO.getChannel(), contract, bundleId,
                clientId.getValue(), requestVO.getTransactionId(), requestVO.getVersionInfo(), requestVO.getTransactionId(),
                requestVO.getClientRequestReference() );

            BundleChangeTypeVo bundleInfo = eaiService.getActiveBundleInformation( contract );
            bundleInfo.setClientRequestReference( requestVO.getClientRequestReference() );
            beanUtils.sendBundleStateChangeResponse( bundleInfo, requestVO, bundleInfo.getPackPromotionList() );

            return createSuccessResponse( requestVO );
        } catch( BundleNotExistentException e ) {
            log.error( e, e );
            return createResponse( BUNDLE_PROMOTION_NOT_OFFERED, requestVO );
        } catch( MsisdnNotExistentException e ) {
            log.error( e, e );
            return createResponse( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM, requestVO );
        } catch( PackPromotionException e ) {
            log.error( e, e );
            return createResponse( ELIGIBILITY_ERROR, requestVO );
        } catch( Exception e ) {
            log.error( e, e );
            return createResponse( GENERAL_SYSTEM_ERROR, requestVO );
        }
    }

    @Override
    @UseCase( DeleteBundle )
    public CustomerCareServicesResponseVo deleteBundle( DeleteBundleRequestVo requestVO ) {
        Contract contract = requestVO.getContract();
        try {
            CustomerCareServicesResponseVo validationError = beanUtils.validateBundleRequest( requestVO );
            if( validationError != null ) {
                return validationError;
            }

            int bundleId = beanUtils.extractBundleSubscriptionId( requestVO );
            Channel channel = requestVO.getChannel();
            int deletedBundles = bundleRequestService.deleteBundle( channel, contract, bundleId, requestVO.getVersionInfo(),
                requestVO.getTransactionId(), requestVO.getClientRequestReference() );
            if( deletedBundles == 0 ) {
                return createResponse( CUSTOMER_DOES_NOT_HAVE_ANY_BUNDLE_SUBSCRIPTIONS, requestVO );
            }

            beanUtils.sendBundleStateChangeResponseWithEmptyPackPromotionList(
                eaiService.getBundleBusinessBuildingBlock( contract, bundleId ),
                requestVO );

            return createSuccessResponse( requestVO );
        } catch( MsisdnNotExistentException e ) {
            log.error( e, e );
            return createResponse( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM, requestVO );
        } catch( Exception e ) {
            log.error( e, e );
            return createResponse( GENERAL_SYSTEM_ERROR, requestVO );
        }
    }

    @Override
    public CustomerCareServicesResponseVo getAvailableBundles( GetAvailableBundlesRequestVo requestVo ) {
        return new RequestProcessor<GetAvailableBundlesRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getAvailableBundles( requestVo );
            }

            @Override
            public void handleError() {
                responseVo = fillErrorResponseWithCommonValuesAndContractData( requestVo,
                    GENERAL_SYSTEM_ERROR, new GetAvailableBundlesResponseVo() );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getCurrentBundle( GetCurrentBundleRequestVO requestVo ) {
        return new RequestProcessor<GetCurrentBundleRequestVO, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getCurrentBundle( requestVo );
            }

            @Override
            public void handleError() {
                responseVo = fillErrorResponseWithCommonValuesAndContractData(
                    requestVo, GENERAL_SYSTEM_ERROR, new GetCurrentBundleResponseVo() );
            }
        }.processRequest();
    }

    @Override
    @UseCase( TopUp )
    public CustomerCareServicesResponseVo storeFailedRechargeAttempt( StoreFailedRechargeAttemptRequestVO requestVO ) {
        StoreFailedRechargeAttemptRequestVo request = StoreFailedRechargeAttemptRequestVo.from( requestVO );
        return prepaidApiPaymentService.storeFailedRechargeAttempt( request ).toLegacy();
    }

    @Override
    public CustomerCareServicesResponseVo getDynamicCustomerData( GetDynamicCustomerDataRequestVo requestVo ) {
        ResultVO resultVO = CustomerCareValidatorUtils
            .checkMsisdnAndVendor( requestVo.getVersionInfo() )
            .validate( requestVo );

        if( resultVO.isFailure() ) {
            GetDynamicCustomerDataResponseVo responseVo = new GetDynamicCustomerDataResponseVo();
            responseVo.setProductSubscriptionsList( new ProductSubscriptionsListVo( Collections.<ProductSubscription>emptyList(),
                Collections.<CrmOrderItemInfo>emptyList() ) );
            return fillResponse( responseVo, resultVO, requestVo );
        }

        Set<ProductType> productTypes = determineProductTypesWhereEmptyMeansAll( requestVo );
        OcsQueryFlagsVo ocsQueryFlagsVo = new OcsQueryFlagsVo()
            .withPackCounterFlag( requestVo.isPackCounters() )
            .withBalanceFlag( requestVo.isBalance() )
            .withUsageControlCounterFlag( requestVo.isUsageControlCounters() );
        return retrieveCountersAndBalances( requestVo, ocsQueryFlagsVo, productTypes, requestVo.isQualityOfService(),
            requestVo.isTariffInfo() );
    }

    @Override
    @UseCase( GetCurrentProducts )
    public CustomerCareServicesResponseVo getCurrentProducts( GetCurrentOrAvailableProductsRequestVO requestVo ) {
        ResultVO resultVo = CustomerCareValidatorUtils
            .checkMsisdnAndVendor( requestVo.getVersionInfo() )
            .validate( requestVo );

        if( resultVo.isFailure() ) {
            GetCurrentProductsResponseVo responseVo = new GetCurrentProductsResponseVo();
            responseVo.setProductSubscriptionsList( new ProductSubscriptionsListVo(
                Collections.<ProductSubscription>emptyList(), Collections.<CrmOrderItemInfo>emptyList() ) );
            return fillResponse( responseVo, resultVo, requestVo );
        }

        Set<ProductType> productTypes = determineProductTypesWhereEmptyMeansAll( requestVo );
        OcsQueryFlagsVo ocsQueryFlagsVo = new OcsQueryFlagsVo()
            .withPackCounterFlag( requestVo.isGetCurrentCounterValues() )
            .withUsageControlCounterFlag( requestVo.isGetCurrentCounterValues() );
        return retrieveCountersAndBalances( requestVo, ocsQueryFlagsVo, productTypes, false, false );
    }

    private CustomerCareServicesResponseVo retrieveCountersAndBalances( CustomerCareServicesRequestVo requestVo,
            OcsQueryFlagsVo ocsQueryFlagsVo, Set<ProductType> productTypes, boolean withQualityOfService, boolean withTariffInfo ) {
        try {
            GetDynamicCustomerDataResponseVo responseVo = new GetDynamicCustomerDataResponseVo();

            List<CrmOrderItemInfo> ongoingCrmOrderItems = crmOrderService.getRunningCrmOrderItemsWithTypes( productTypes,
                requestVo.getContract() );

            Customer customer = getCustomer( daos, requestVo.getContract(), productCache );
            List<ProductSubscription> currentProductSubscriptions = productService.getCurrentProductsOfTypes( productTypes,
                customer, requestVo.getChannel(), withTariffInfo );

            List<PackProductSubscription> packProductSubscriptions = FluentIterable.from( currentProductSubscriptions )
                .filter( PackProductSubscription.class ).toList();
            PackAndBalanceInfoVo packAndBalanceInfoVo = queryCountersService.retrieveCountersAndBalances( customer, requestVo.getChannel(),
                requestVo.getClientRequestReference(), packProductSubscriptions, ocsQueryFlagsVo );

            if( ocsQueryFlagsVo.isBalanceFlag() ) {
                responseVo.setBalanceInfo( packAndBalanceInfoVo.getBalanceInfoVo() );
            }
            if( withQualityOfService ) {
                QoSInformationVo qosInformation = beanUtils.getQosInformation( requestVo.getContract() );
                responseVo.setQosInformation( qosInformation );
            }

            ProductSubscriptionsListVo subscriptionsList = new ProductSubscriptionsListVo( currentProductSubscriptions,
                ongoingCrmOrderItems );
            addIncompatiblePacks( customer, requestVo, subscriptionsList.getIncompatiblePacksMap(), currentProductSubscriptions );
            responseVo.setProductSubscriptionsList( subscriptionsList );
            populateWithSuccessResultAndContractData( requestVo, responseVo );
            return responseVo;
        } catch( MsisdnNotExistentException e ) { // NOSONAR
            return fillErrorResponseWithCommonValuesAndContractData(
                requestVo, MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM, emptyGetCurrentProductsResponse() );
        } catch( ApplicationException e ) { // NOSONAR
            return fillErrorResponseWithCommonValuesAndContractData( requestVo, GENERAL_SYSTEM_ERROR, emptyGetCurrentProductsResponse() );
        } catch( OcsException e ) { // NOSONAR
            OcsResponse responseCode = e.getOcsResponse().getResponseCode();
            CustomerCareResultCode resultCode = CustomerCareNetworkErrorMapper.fromOcsResponseOrNetworkError( responseCode );
            return fillErrorResponseWithCommonValuesAndContractData( requestVo, resultCode, emptyGetCurrentProductsResponse() );
        }
    }

    private GetCurrentProductsResponseVo emptyGetCurrentProductsResponse() {
        GetCurrentProductsResponseVo responseVo = new GetCurrentProductsResponseVo();
        responseVo.setProductSubscriptionsList( new ProductSubscriptionsListVo() );
        return responseVo;
    }

    private void addIncompatiblePacks( final Customer customer, final CustomerCareServicesRequestVo requestVo,
            final IncompatiblePacksMap incompatiblePacksMap, List<? extends ProductSubscription> subscriptions )
            throws ApplicationException {
        if( subscriptions.isEmpty() ) {
            return;
        }

        for( ProductSubscription subscription : subscriptions ) {
            subscription.getProduct().accept( getEmptyProductVisitor( customer, requestVo, incompatiblePacksMap ) );
        }
    }

    private EmptyProductVisitor getEmptyProductVisitor( final Customer customer, final CustomerCareServicesRequestVo requestVo,
            final IncompatiblePacksMap incompatiblePacksMap ) {

        return new EmptyProductVisitor() {

            @Override
            public void visitPackProduct( PackProduct product ) throws ApplicationException {
                List<PackProduct> incompatiblePacks = productService.getIncompatiblePacks( customer, product.getBusinessBuildingBlock()
                    .getPackId(), requestVo.getChannel() );
                incompatiblePacksMap.putIncompatiblePacks( product, incompatiblePacks );
            }
        };
    }

    private CrmOrderStepResult performFullValidation( AbstractCrmOrderRequestVo requestVo, boolean inhibitExternalCallChecks )
            throws ApplicationException {
        List<CrmOrderActionVO> orderActionList = requestVo.getProductActions().getCrmOrderActionList();

        if( !crmOrderValidationService.areCrmOrderActionsAdmissible( requestVo.getVersionInfo(), orderActionList,
            requestVo.getRequestType() ) ) {
            return new CrmOrderStepResult( ITEM_COMPOSITION,
                versionSpecificInvalidCombinationOfProductActions( requestVo.getVersionInfo() ),
                Collections.<CrmOrderActionResult>emptyList() );
        }

        List<CrmOrderActionResult> actionVoResponses = crmOrderValidationService.validateAndUpdateActions( requestVo,
            requestVo.isAdditionalBalanceCheck(), inhibitExternalCallChecks );

        if( atLeastOneFailingItemExists( requestVo, actionVoResponses ) ) {
            return new CrmOrderStepResult( ITEM_VALIDATION, null, actionVoResponses );
        }

        if( !inhibitExternalCallChecks && isBalanceCheckRequired( requestVo ) && !crmOrderValidationService.isBalanceSufficient(
            requestVo ) ) {
            return new CrmOrderStepResult( BALANCE_VALIDATION, INSUFFICIENT_BALANCE, actionVoResponses );
        }

        return new CrmOrderStepResult( VALIDATION_COMPLETE, null, actionVoResponses );
    }

    private boolean isBalanceCheckRequired( AbstractCrmOrderRequestVo requestVo ) {
        return requestVo.isAdditionalBalanceCheck()
                && !CrmOrderUtil.getFirstActionThatDisallowsMsisdn( requestVo ).isPresent();
    }

    private boolean atLeastOneFailingItemExists( AbstractCrmOrderRequestVo requestVo, List<CrmOrderActionResult> actionVoResponses ) {
        for( CrmOrderActionResult actionResult : actionVoResponses ) {

            if( actionResultMayBeSkippedDuringValidation( requestVo, actionResult ) ) {
                continue;
            }

            if( !actionResult.valid() ) {
                return true;
            }
        }
        return false;
    }

    private boolean actionResultMayBeSkippedDuringValidation( AbstractCrmOrderRequestVo requestVo, CrmOrderActionResult actionResult ) {
        if( !requestVo.getAllowSyncCustomerDataValidationResponse().or( true ) ) {
            CustomerCareResultCode customerCareResultCode = actionResult.getCustomerCareResultCode();
            if( CustomerCareResultCode.MAXIMUM_SIM_REGISTRATION_IS_EXCEEDED.equals( customerCareResultCode ) ) {
                return true;
            }

            if( CustomerCareResultCode.ADDRESS_IS_NOT_VALID.equals( customerCareResultCode ) ) {
                return true;
            }

            if( CustomerCareResultCode.INVALID_BANK_DATA.equals( customerCareResultCode ) ) {
                return true;
            }

            if( CustomerCareResultCode.INVALID_SHIPPING_ADDRESS.equals( customerCareResultCode ) ) {
                return true;
            }
        }
        return false;
    }

    @VisibleForTesting
    CustomerCareResultCode versionSpecificInvalidCombinationOfProductActions( CustomerCareVersion version ) {
        return version.isGreaterThanVersion( VERSION_8 ) ? INVALID_COMBINATION_OF_PRODUCT_ACTIONS
                : WRONG_OR_MISSING_MANDATORY_PARAMETERS;
    }

    private CrmOrderResponseVO mapValidationResultToResponseVO( AbstractCrmOrderRequestVo requestVo, CrmOrderResponseVO initialResponseVO,
            CrmOrderStepResult validationResult, boolean fromValidateCrmOrder ) {
        CrmOrderStep crmOrderStep = validationResult.getCrmOrderStep();
        switch( crmOrderStep ) {
            case ITEM_COMPOSITION:
                return fillResponse( initialResponseVO, new ResultVO( validationResult.getGlobalResultCode(),
                    ERROR_REASON_MESSSAGE_CRM_ORDER_ACTIONS_NOT_ADMISSIBLE ), requestVo );
            case ITEM_VALIDATION:
                return createCrmOrderResponseFromActionResults( requestVo, initialResponseVO, validationResult.getActionResults(),
                    fromValidateCrmOrder );
            case BALANCE_VALIDATION:
                return fillResponse( initialResponseVO, INSUFFICIENT_BALANCE, requestVo );
            default:
                throw Reject.always( "Cannot map " + crmOrderStep + " to a response." );
        }
    }

    @Override
    public ValidateCrmOrderResponseVo validateCrmOrder( ValidateCrmOrderRequestVo requestVo ) {
        ValidateCrmOrderResponseVo responseVO = populateWithSuccessResultAndContractData( requestVo, new ValidateCrmOrderResponseVo() );

        ResultVO resultVo = crmOrderValidationService.performBasicValidation( requestVo );

        if( resultVo.isFailure() ) {
            return fillResponse( responseVO, resultVo, requestVo );
        }

        CrmOrderStepResult validationResult;
        try {
            crmOrderService.fillMissingInformationForEachAction( requestVo );

            validationResult = performFullValidation( requestVo, true );
            overrideFailedValidationsIfSyncValidationIsNotAllowed( requestVo, validationResult );

            if( validationResult.getCrmOrderStep() != VALIDATION_COMPLETE ) {
                CrmOrderResponseVO orderResponseVO = mapValidationResultToResponseVO( requestVo, new CrmOrderResponseVO(),
                    validationResult, true );
                responseVO = fillResponse( responseVO, new ResultVO( orderResponseVO.getResultCodeEnum(), orderResponseVO.getReasonMsg() ),
                    requestVo );
                responseVO.setProductActionResults( orderResponseVO.getProductActionResult() );
                return responseVO;
            }

            if( requestVo.isSuggestFurtherProducts() ) {
                ImmutableSet<ProductType> limitResponseTo = requestVo.getLimitResponseTo();
                if( !ImmutableSet.of( ProductType.PACK ).equals( limitResponseTo ) ) {
                    return fillWithWrongParameterError( responseVO, "limitResponseTo", requestVo );
                }

                Optional<AvailableProduct> targetTariffProduct = getChangeTariffActionAsAvailableProductIfPresent( requestVo );
                List<ViewSubscriberSubscription> packsToBeSubscribed = getPacksToBeSubscribed( requestVo );
                List<AvailableProduct> products = getAvailableProductsHelper( requestVo, targetTariffProduct.orNull(), packsToBeSubscribed,
                    false );
                if( targetTariffProduct.isPresent() ) {
                    Product tariffProduct = targetTariffProduct.get().getProduct();
                    products = keepOnlyProductsAvailableInNewTariff( products, tariffProduct.getProductId() );
                }
                responseVO.setSuggestedProducts( products );
            }

            return responseVO;
        } catch( MsisdnNotExistentException e ) {
            responseVO.setProductActionResults( Collections.<ProductActionResultVO>emptyList() );

            log.error( "Msisdn " + requestVo.getMsisdn() + " not found in the system.", e );
            return fillResponse( responseVO, MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM, requestVo );
        } catch( CrmOrderException e ) { // NOSONAR
            responseVO.setProductActionResults( Collections.<ProductActionResultVO>emptyList() );

            CustomerCareResultCode errorCode = e.getCustomerCareResultCode();
            if( errorCode == null ) {
                log.error( "Unknown error in validateCrmOrder", e );
                return createErrorResponseForRequestWithMsisdn( GENERAL_SYSTEM_ERROR, responseVO, requestVo );
            }
            log.error( "Error in validateCrmOrder for request " + requestVo.getClientRequestReference() + ": "
                    + e.getErrorTextForResultCode() + " for " + e.getOriginatingType() + " action." );
            return createErrorResponseForRequestWithMsisdn( errorCode, responseVO, requestVo );
        } catch( Exception e ) {
            responseVO.setProductActionResults( Collections.<ProductActionResultVO>emptyList() );

            log.error( "Error in validateCrmOrder", e );
            return createErrorResponseForRequestWithMsisdn( GENERAL_SYSTEM_ERROR, responseVO, requestVo );
        }
    }

    private List<ViewSubscriberSubscription> getPacksToBeSubscribed( AbstractCrmOrderRequestVo crmOrderRequestVo )
            throws ProductNotFoundException {
        if( crmOrderRequestVo.getProductActions() == null ) {
            return emptyList();
        }

        List<CrmOrderActionVO> productActions = crmOrderRequestVo.getProductActions().getCrmOrderActionList();
        if( ListUtils.isNullOrEmpty( productActions ) ) {
            return emptyList();
        }

        List<ViewSubscriberSubscription> result = newArrayList();
        for( CrmOrderActionVO actionVO : productActions ) {
            if( CrmOrderActionType.SUBSCRIBE_PACK.equals( actionVO.getActionType() ) ) {
                ViewSubscriberSubscription presumedSubscription = getViewSubscriberSubscription(
                    ( (CrmOrderSubscribePackVO) actionVO ).getProductId(),
                    crmOrderRequestVo.getContract() );
                result.add( presumedSubscription );
            }
        }

        return result;
    }

    private ViewSubscriberSubscription getViewSubscriberSubscription( ProductId productId, Contract contract )
            throws ProductNotFoundException {
        ViewSubscriberSubscription presumedSubscription = new ViewSubscriberSubscription();
        presumedSubscription.setSubscriptionId( productCache.getPackProduct( productId )
            .getBusinessBuildingBlock().getSubscriptionId() );
        presumedSubscription.setStatus( SubscriberSubscriptionStatus.ACTIVE );
        presumedSubscription.setContractId( contract.getContractId() );
        presumedSubscription.setCustomerPackSubscrId( 0L );
        return presumedSubscription;
    }

    private List<AvailableProduct> keepOnlyProductsAvailableInNewTariff( List<AvailableProduct> products, ProductId productId ) {
        return newArrayList( Iterables.filter( products, dependsOnProduct( productId ) ) );
    }

    private Optional<AvailableProduct> getChangeTariffActionAsAvailableProductIfPresent( AbstractCrmOrderRequestVo crmOrderRequestVo )
            throws ProductNotFoundException {
        CrmOrderChangeTariffVO crmOrderChangeTariffActionVO = crmOrderRequestVo.getProductActions().getActionForType(
            CrmOrderChangeTariffVO.class );
        if( crmOrderChangeTariffActionVO != null ) {
            Integer newTariffId = crmOrderChangeTariffActionVO.getNewTariffId();
            TariffProduct tariffProduct = productCache.getTariffProductByTariffId( newTariffId );
            if( crmOrderRequestVo.getChannel() == Channel.POS ) {
                tariffProduct = productService.getTariffProductWithPosDisplayFee( tariffProduct );
            }
            return Optional.of( new AvailableProduct( tariffProduct ) );
        }

        return Optional.absent();
    }

    @Override
    @Interceptors( { TraceLogInterceptor.class } )
    public CustomerCareServicesResponseVo createCrmOrder( CreateCrmOrderRequestVO requestVo ) {
        debug( log, "processing CRM order = ", requestVo );

        CrmOrderLoggingUtil.log( "[PrepaidITCustomerCareServicesBean] Creating CRM order ", requestVo );

        ResultVO resultVo = crmOrderValidationService.performBasicValidation( requestVo );
        if( resultVo.isFailure() ) {
            return createResponse( resultVo, requestVo );
        }

        CrmOrderResponseVO responseVo = new CrmOrderResponseVO();
        CrmOrder crmOrder;
        try {
            crmOrderService.fillMissingInformationForEachAction( requestVo );
            crmOrder = crmOrderService.storeCrmOrder( requestVo );
            storeShipSimTemporaryHistoryEntryIfNecessary( requestVo, crmOrder );
        } catch( CrmOrderException e ) { // NOSONAR
            CustomerCareResultCode errorCode = e.getCustomerCareResultCode();
            if( errorCode == null ) {
                log.error( "Unknown error in createCrmOrder", e );
                return createErrorResponseForRequestWithMsisdn( GENERAL_SYSTEM_ERROR, responseVo, requestVo );
            }
            log.error( "Error in createCrmOrder for request " + requestVo.getClientRequestReference() + ": "
                    + e.getErrorTextForResultCode() + " for " + e.getOriginatingType() + " action." );
            return createResponseForCrmRequestWithErrorForOneItem( requestVo, responseVo, e );
        } catch( Exception e ) {
            log.error( "Error in createCrmOrder", e );
            return createErrorResponseForRequestWithMsisdn( GENERAL_SYSTEM_ERROR, responseVo, requestVo );
        }

        try {
            CrmOrderStepResult validationResult = performFullValidation( requestVo, false );

            Set<CustomerCareResultCode> simShipmentValidationFailures = overrideFailedValidationsIfSyncValidationIsNotAllowed( requestVo,
                validationResult );

            if( validationResult.getCrmOrderStep() != VALIDATION_COMPLETE ) {
                crmOrderService.updateCrmOrder( crmOrder, validationResult );
                return mapValidationResultToResponseVO( requestVo, responseVo, validationResult, false );
            }

            updateCrmRegisterCustomerActionAddress( validationResult );
            updateCrmRegDirectDebitActionTpbaoAddressAndBankData( validationResult );

            updateCrmSimShipAddressFromCustomerChecking( validationResult );

            List<CrmOrderActionResult> processingResultActions = newArrayList();
            if( !simShipmentValidationFailures.isEmpty() ) {
                crmOrderService.markOrderAsDefective( crmOrder );
                onlineOrderEventHistoryService.createCustomerDataValidationHistoryEntry( crmOrder, requestVo,
                    ImmutableList.copyOf( simShipmentValidationFailures ) );

                simShipmentHistoryService.addSimShipmentHistoryEntry( crmOrder.getCrmOrderId(), Optional.<ExternalOrderId>absent(),
                    SimShipmentStatus.OPEN );
                simShipmentHistoryService.addEntryForValidationFailures( crmOrder.getCrmOrderId(), simShipmentValidationFailures );

            } else {
                CrmOrderStepResult processingResult = triggerExecutionOfFirstCrmOrderItem( crmOrder, requestVo );
                processingResultActions = processingResult.getActionResults();
                crmOrderService.updateCrmOrderFromAllItems( crmOrder );
            }

            responseVo = createCrmOrderResponseFromActionResults( requestVo, responseVo,
                ListUtils.concat( validationResult.getActionResults(), processingResultActions ), false );

            if( responseVo.isSuccess() ) {
                responseVo.setOrderId( requestVo.getCrmOrderId() );
            }
            return responseVo;
        } catch( Exception e ) {
            log.error( "Error in createCrmOrder: " + requestVo, e );
            crmOrderService.updateCrmOrderPermanentErrorInIndependentTransaction( crmOrder );
            return createErrorResponseForRequestWithMsisdn( GENERAL_SYSTEM_ERROR, responseVo, requestVo );
        }
    }

    private void storeShipSimTemporaryHistoryEntryIfNecessary( CreateCrmOrderRequestVO requestVo, CrmOrder crmOrder ) {
        if( !crmOrder.getCrmOrderItemsByType( CrmOrderActionType.SHIP_SIM ).isEmpty() ) {
            onlineOrderEventHistoryService.createCrmOrderCreationTemporaryHistoryEntry( crmOrder.getCrmOrderId(), requestVo );
        }
    }

    private Set<CustomerCareResultCode> overrideFailedValidationsIfSyncValidationIsNotAllowed( AbstractCrmOrderRequestVo requestVo,
            CrmOrderStepResult validationResult ) {
        Set<CustomerCareResultCode> validationFailures = Sets.newHashSet();

        Optional<CrmOrderShipSimVo> shipSimAction = requestVo.getShipSim();
        if( !shipSimAction.isPresent() ) {
            return validationFailures;
        }

        Optional<CrmOrderRegisterCustomerActionVO> addressData = requestVo.getRegisterCustomerAction();
        Optional<CrmOrderRegisterDirectDebitVO> directDebitData = requestVo.getRegisterForDirectDebitAction();

        boolean isDefectiveOrderDueToAddressCheckQualityFlag = addressData.isPresent() && addressData.get()
            .getAddressCheckQuality() == DataCheckQuality.CHECKED_UNKNOWN;
        if( isDefectiveOrderDueToAddressCheckQualityFlag ) {
            validationFailures.add( CustomerCareResultCode.ADDRESS_IS_NOT_VALID );
        }

        boolean isDefectiveOrderDueToAddressShippingCheckQualityFlag = shipSimAction.get().getShippingAddress().isPresent()
                && DataCheckQuality.CHECKED_UNKNOWN.equals( shipSimAction.get().getShippingAddress().get().getAddressQuality() );
        if( isDefectiveOrderDueToAddressShippingCheckQualityFlag ) {
            validationFailures.add( CustomerCareResultCode.INVALID_SHIPPING_ADDRESS );
        }

        boolean isDefectiveOrderDueToBankDataCheckQualityFlag = directDebitData.isPresent()
                && directDebitData.get().getBankAccount().getDataCheckQuality() == DataCheckQuality.CHECKED_UNKNOWN;
        if( isDefectiveOrderDueToBankDataCheckQualityFlag ) {
            validationFailures.add( CustomerCareResultCode.INVALID_BANK_DATA );
        }

        for( CrmOrderActionResult actionResult : validationResult.getActionResults() ) {
            if( actionResultMayBeSkippedDuringValidation( requestVo, actionResult ) ) {
                validationFailures.add( actionResult.getCustomerCareResultCode() );
                actionResult.setCustomerCareResultCode( CustomerCareResultCode.REQUEST_SUCCESSFUL );
                actionResult.setReasonMessage( CustomerCareResultCode.REQUEST_SUCCESSFUL.getDocumentation() );
            }
        }

        return validationFailures;
    }

    private void updateCrmRegisterCustomerActionAddress( CrmOrderStepResult validationResult ) {
        Optional<CrmOrderRegisterCustomerActionResult> result = getCrmOrderRegisterCustomerResultWithNormalizedAddress( validationResult );
        if( result.isPresent() && result.get().getNormalizedAddress().isPresent() ) {
            crmOrderService.updateTabCrmRegCustomerAction( result.get().getCrmOrderActionVO().getCrmOrderItemIdWrapped(),
                result.get().getNormalizedAddress().get() );
        }
    }

    private void updateCrmRegDirectDebitActionTpbaoAddressAndBankData( CrmOrderStepResult validationResult ) {
        Optional<CrmOrderRegisterCustomerForDirectDebitActionResult> crmOrderRegisterForDirectDebitActionResult = getCrmOrderRegisterCustomerForDirectDebitActionResultSuccessful(
            validationResult );
        if( !crmOrderRegisterForDirectDebitActionResult.isPresent() ) {
            return;
        }
        crmOrderService.updateTabCrmRegDdActionTpbaoAddress( crmOrderRegisterForDirectDebitActionResult.get().getCrmOrderActionVO()
            .getCrmOrderItemIdWrapped(), crmOrderRegisterForDirectDebitActionResult.get().getNormalizedThirdPartyAddress(),
            crmOrderRegisterForDirectDebitActionResult.get().valid() );

        if( crmOrderRegisterForDirectDebitActionResult.get().isBankDataUpdated() ) {
            CrmOrderRegisterDirectDebitVO orderActionVo = (CrmOrderRegisterDirectDebitVO) crmOrderRegisterForDirectDebitActionResult.get()
                .getCrmOrderActionVO();
            crmOrderService.updateTabCrmRegDirectDebitAction( crmOrderRegisterForDirectDebitActionResult.get().getCrmOrderActionVO()
                .getCrmOrderItemIdWrapped(), orderActionVo.getBankAccount() );
        }
    }

    private void updateCrmSimShipAddressFromCustomerChecking( CrmOrderStepResult validationResult ) {
        Optional<CrmOrderShipSimActionResult> crmOrderShipSimActionResult = getCrmOrderShipSimActionResultSuccessful( validationResult );
        if( crmOrderShipSimActionResult.isPresent() && crmOrderShipSimActionResult.get().getNormalizedAddress().isPresent() ) {
            crmOrderService.updateTabCrmSimShipAddress( crmOrderShipSimActionResult.get().getCrmOrderActionVO()
                .getCrmOrderItemIdWrapped(), crmOrderShipSimActionResult.get().getNormalizedAddress().get(), true );
        }
    }

    private Optional<CrmOrderRegisterCustomerForDirectDebitActionResult> getCrmOrderRegisterCustomerForDirectDebitActionResultSuccessful(
            CrmOrderStepResult validationResult ) {
        return getCrmOrderResultSuccessfulOfType( validationResult, CrmOrderActionType.REGISTER_FOR_DIRECT_DEBIT ).transform(
            new Function<CrmOrderActionResult, CrmOrderRegisterCustomerForDirectDebitActionResult>() {
                @Override
                public CrmOrderRegisterCustomerForDirectDebitActionResult apply( CrmOrderActionResult input ) {
                    return (CrmOrderRegisterCustomerForDirectDebitActionResult) input;
                }
            } );
    }

    private Optional<CrmOrderShipSimActionResult> getCrmOrderShipSimActionResultSuccessful( CrmOrderStepResult validationResult ) {
        return getCrmOrderResultSuccessfulOfType( validationResult, CrmOrderActionType.SHIP_SIM ).transform(
            new Function<CrmOrderActionResult, CrmOrderShipSimActionResult>() {
                @Override
                public CrmOrderShipSimActionResult apply( CrmOrderActionResult input ) {
                    return (CrmOrderShipSimActionResult) input;
                }
            } );
    }

    private Optional<CrmOrderActionResult> getCrmOrderResultSuccessfulOfType(
            CrmOrderStepResult validationResult, CrmOrderActionType crmOrderActionType ) {
        for( CrmOrderActionResult crmOrderActionResult : validationResult.getActionResults() ) {
            if( crmOrderActionType.equals( crmOrderActionResult.getCrmOrderActionVO().getActionType() )
                    && crmOrderActionResult.getCustomerCareResultCode() == REQUEST_SUCCESSFUL ) {
                return Optional.of( crmOrderActionResult );
            }
        }
        return Optional.absent();
    }

    private Optional<CrmOrderRegisterCustomerActionResult> getCrmOrderRegisterCustomerResultWithNormalizedAddress(
            CrmOrderStepResult validationResult ) {
        CrmOrderActionType crmOrderActionType = CrmOrderActionType.REGISTER_CUSTOMER;
        for( CrmOrderActionResult crmOrderActionResult : validationResult.getActionResults() ) {
            if( crmOrderActionType.equals( crmOrderActionResult.getCrmOrderActionVO().getActionType() )
                    && crmOrderActionResult.getCustomerCareResultCode() == REQUEST_SUCCESSFUL
                    && crmOrderActionResult instanceof CrmOrderRegisterCustomerActionResult
                    && ( (CrmOrderRegisterCustomerActionResult) crmOrderActionResult ).getNormalizedAddress().isPresent() ) {
                return Optional.of( (CrmOrderRegisterCustomerActionResult) crmOrderActionResult );
            }
        }
        return Optional.absent();
    }

    private CrmOrderStepResult triggerExecutionOfFirstCrmOrderItem( CrmOrder crmOrder, CreateCrmOrderRequestVO requestVo )
            throws MsisdnNotExistentException, CrmOrderException, ProductNotFoundException, ApplicationException {
        CrmOrderActionType startActionType = crmOrderService.getNextActionType( crmOrder );
        Reject.ifNull( startActionType, "Missing next CrmOrderActionType, should have been detected by validation." );
        List<CrmOrderActionResult> crmOrderActionVoResponses = crmOrderProcessingService
            .processActionsAndUpdateActionsForType( crmOrder, requestVo, startActionType );
        return new CrmOrderStepResult( TRIGGERING, null, crmOrderActionVoResponses );
    }

    @Override
    public CustomerCareServicesResponseVo getAvailableProducts( GetCurrentOrAvailableProductsRequestVO request ) {
        try {
            ResultVO validationResult = checkContractOrIccIdNotNull().validate( request );
            if( validationResult.isFailure() ) {
                return createResponse( validationResult, request );
            }

            ContractWithProvisioningData contractData = getContractAndProvisioningData( request );
            request.setContract( contractData.getContract() );
            Optional<KittedData> kittedData = request.getIccId().isPresent() ? kittedDataRepository.findLastKittedDataForIccIdWithPacks(
                request.getIccId().get() ) : Optional.<KittedData>absent();

            validationResult = checkIfVendorIsAllowed( request, contractData, kittedData );
            if( validationResult.isFailure() ) {
                return createResponse( validationResult, request );
            }

            Set<ProductType> productTypes = determineProductTypesWhereEmptyMeansAll( request );

            ProvisioningType provisioningType = contractData.getProvisioningData() != null
                    ? contractData.getProvisioningData().getProvisioningType()
                    : null;
            List<AvailableProduct> products = productService.getAvailableProducts( contractData.getVendor(), contractData.getContract(),
                provisioningType, productTypes, kittedData, request.getVoIdWrapped(), request.getChannel(), request.getRoleId() );

            CustomerCareServicesResponseVo responseVo = new GetAvailableProductsResponseVo( products );
            populateWithSuccessResultAndContractData( request, responseVo );
            return responseVo;
        } catch( MsisdnNotExistentException e ) { // NOSONAR
            return fillErrorResponseWithCommonValuesAndContractData( request, MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM,
                new GetAvailableProductsResponseVo( Collections.<AvailableProduct>emptyList() ) );
        } catch( ApplicationException e ) { // NOSONAR
            return fillErrorResponseWithCommonValuesAndContractData( request, GENERAL_SYSTEM_ERROR,
                new GetAvailableProductsResponseVo( Collections.<AvailableProduct>emptyList() ) );
        }
    }

    private ResultVO checkIfVendorIsAllowed( GetCurrentOrAvailableProductsRequestVO request, ContractWithProvisioningData contractData,
            Optional<KittedData> kittedData ) {
        CustomerCareVersion version = request.getVersionInfo();
        if( contractData.getContract() != null ) {
            if( version.isGreaterThanVersion( VERSION_8 ) ) {
                return checkTenantIdMatchesCustomersVendor()
                    .next( checkBrandIdMatchesCustomersVendor() )
                    .validate( request );
            } else {
                PrepaidITCustomerCareServicesBaseValidator validator = getValidator();
                if( !validator.isMsisdnValidForClient( request, true ) ) {
                    return new ResultVO( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM );
                }
            }
        } else {
            if( kittedData.isPresent() && !kittedData.get().getVendor().equals( request.getVendor() ) ) {
                return new ResultVO( MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM );
            }
        }

        return new ResultVO( REQUEST_SUCCESSFUL );
    }

    @VisibleForTesting
    public ContractWithProvisioningData getContractAndProvisioningData( GetCurrentOrAvailableProductsRequestVO requestVo ) {
        return contractWithProvisioningDataService.getContractWithProvisioningData( requestVo.getContract(),
            requestVo.getVendorOfContractOrRequest(), requestVo.getIccId() );
    }

    @Override
    public CustomerCareServicesResponseVo getProductList( GetCurrentOrAvailableProductsRequestVO requestVo ) {
        try {
            Set<ProductType> productTypes = determineProductTypesWhereEmptyMeansAll( requestVo );

            List<AvailableProduct> products = productService.getProductListOfTypes( productTypes, requestVo.getChannel(),
                requestVo.getVendor(), requestVo.getVoIdWrapped() );

            CustomerCareServicesResponseVo responseVo = new GetAvailableProductsResponseVo( products );
            populateWithSuccessResultAndContractData( requestVo, responseVo );
            return responseVo;
        } catch( ApplicationException e ) {
            log.error( "Error in getProductList: " + requestVo, e );
            return fillErrorResponseWithCommonValuesAndContractData( requestVo,
                GENERAL_SYSTEM_ERROR,
                new GetAvailableProductsResponseVo( Collections.<AvailableProduct>emptyList() ) );
        }
    }

    private <T extends CustomerCareServicesRequestVo & HasLimitResponseTo> List<AvailableProduct> getAvailableProductsHelper(
            T requestVo, @Nullable AvailableProduct targetTariffProduct,
            List<ViewSubscriberSubscription> packsToBeSubscribed, boolean removeSatisfiedDependencies )
            throws ApplicationException, MsisdnNotExistentException {
        Set<ProductType> productTypes = determineProductTypesWhereEmptyMeansAll( requestVo );

        Contract contract = requestVo.getContract();
        Channel channel = requestVo.getChannel();
        RoleId roleId = requestVo.getRoleId();
        Vendor vendor = requestVo.getVendor();
        Optional<VoId> voId = requestVo.getVoIdWrapped();

        List<AvailableProduct> products;

        if( contract == null ) {
            products = productService.getProductListOfTypes( productTypes, channel, vendor, voId );
        } else {
            Customer customer = getCustomer( daos, contract, productCache );
            products = productService.getAvailableProductsWithTypes( productTypes, customer, channel, roleId, voId, targetTariffProduct,
                packsToBeSubscribed, removeSatisfiedDependencies, true );
        }
        return products;
    }

    @VisibleForTesting
    <T extends CustomerCareServicesRequestVo & HasLimitResponseTo> Set<ProductType> determineProductTypesWhereEmptyMeansAll(
            T requestVo ) {
        Set<ProductType> set = requestVo.getLimitResponseTo();
        if( set != null && !set.isEmpty() ) {
            return set;
        }
        if( requestVo.getVersionInfo().isAtMostVersion( VERSION_8 ) ) {
            return Sets.difference( ProductType.ALL_BUT_BUNDLE, singleton( ProductType.TARIFF ) );
        }
        return ProductType.ALL_BUT_BUNDLE;
    }

    @Override
    public CustomerCareServicesResponseVo getCrdInformation( GetCrdInformationRequestVo requestVo ) {
        try {
            List<AvailableProductWithCrdInfo> products = productService.getProductsWithCrdInfo( requestVo.getProductIds(),
                requestVo.getChannel(), requestVo.getVendor(), requestVo.getVoIdWrapped() );

            GetCrdInformationResponseVo responseVo = new GetCrdInformationResponseVo( products );

            return fillWithSuccessResult( responseVo, requestVo );
        } catch( ApplicationException e ) {
            log.error( "Error in getCrdInformation: " + requestVo, e );
            return fillErrorResponseWithCommonValuesAndContractData( requestVo,
                GENERAL_SYSTEM_ERROR, new GetCrdInformationResponseVo( Collections.<AvailableProductWithCrdInfo>emptyList() ) );
        } catch( ProductNotFoundException e ) { // NOSONAR
            return fillErrorResponseWithCommonValuesAndContractData( requestVo,
                PRODUCT_DOES_NOT_EXIST, new GetCrdInformationResponseVo( Collections.<AvailableProductWithCrdInfo>emptyList() ) );
        }
    }

    @Override
    public CustomerCareServicesResponseVo updateFrontendRegistrationDate( UpdateFrontendRegistrationDateRequestVo requestVo ) {
        try {
            ResultVO result = CustomerCareValidatorUtils.validateUpdateFrontendRegistrationRequest( requestVo.getVersionInfo() )
                .validate( requestVo );
            if( result.isFailure() ) {
                return createResponse( result, requestVo );
            }
            customerService.updateFrontendRegistrationDate( requestVo.getContract(), requestVo.getFrontendRegistrationDate() );
            return createSuccessResponse( requestVo );
        } catch( ApplicationException e ) {
            log.error( e, e );
            return createResponse( GENERAL_SYSTEM_ERROR, requestVo );
        }
    }

    @Override
    public CustomerCareServicesResponseVo getHandsetDelockData( GetHandsetDelockDataRequestVo requestVo ) {
        try {
            ResultVO resultVo = checkClientIsKnown()
                .validate( requestVo );

            if( resultVo.isFailure() ) {
                return createResponse( resultVo, requestVo );
            }

            return customerDataService.getHandsetDelockData( requestVo, requestVo.getVendor() );
        } catch( ApplicationException e ) {
            log.error( "Caught an exception during getHandsetDelockData for imei " + requestVo.getImei(), e );
            return createResponse( GENERAL_SYSTEM_ERROR, requestVo );
        }
    }

    @Override
    public CustomerCareServicesResponseVo notifyCustomerDirectDebitLimitExceeded(
            NotifyCustomerDirectDebitLimitExceededLegacyRequestVo requestVo ) {
        NotifyCustomerDirectDebitLimitExceededRequestVo request = NotifyCustomerDirectDebitLimitExceededRequestVo.from( requestVo );
        return prepaidApiPaymentService.notifyCustomerDirectDebitLimitExceeded( request ).toLegacy();
    }

    @Override
    public CustomerCareServicesResponseVo notifyAboutBankTransaction( NotifyAboutBankTransactionLegacyRequestVo requestVo ) {
        NotifyAboutBankTransactionRequestVo request = NotifyAboutBankTransactionRequestVo.from( requestVo );
        return prepaidApiPaymentService.notifyAboutBankTransaction( request ).toLegacy();
    }

    @Override
    public CustomerCareServicesResponseVo prepareClawback( PrepareClawbackRequestVO requestVo ) {
        PrepareClawbackRequestVo request = PrepareClawbackRequestVo.from( requestVo );
        return prepaidApiPaymentService.prepareClawback( request ).toLegacy();
    }

    @Override
    public CustomerCareServicesResponseVo changeBankAccount( ChangeBankAccountRequestVO requestVo ) {
        Contract contract = requestVo.getContract();
        DirectDebitBankAccountVo directDebitBankAccountVo = requestVo.getDirectDebitBankAccountVO();

        ResultVO resultVo = CustomerCareValidatorUtils.checkMsisdnAndVendor( requestVo.getVersionInfo() )
            .next( validateAccountOwner() )
            .next( validateNonGermanBankAccount() )
            .next( customerCareAvailableUseCases.validateCustomerCareUseCase( CustomerCareUseCase.CHANGE_BANK_ACCOUNT ) )
            .validate( requestVo );

        if( resultVo.isFailure() ) {
            return createResponse( resultVo, requestVo );
        }

        try {
            directDebitService.changeBankAccountData( contract, directDebitBankAccountVo, false, requestVo.getChannel(),
                requestVo.getAgent(), Optional.fromNullable( requestVo.getVoId() ) );
        } catch( SmsNotSentException e ) {
            log.error( "Error occurred while sending SMS for changed bank account data for contract " + contract, e );
        } catch( WrongDirectDebitStateException e ) {
            log.error( "Operation not possible because of invalid Direct Debit State for " + contract, e );
            return createResponse( INVALID_PAYMENT_METHOD_STATE, requestVo );
        } catch( DirectDebitExternalSystemsException e ) {
            if( e.isPermanent() ) {
                log.warn( getErrorMessage( contract, false ), e );
                return createResponse( PERMANENT_BACKEND_SYSTEM_ERROR, requestVo );
            }
            log.info( getErrorMessage( contract, true ) + e );
        } catch( OutOfSyncException e ) {
            if( e.isPermanent() ) {
                log.warn( getErrorMessage( contract, false ), e );
                return createResponse( PERMANENT_BACKEND_SYSTEM_ERROR, requestVo );
            }
            log.info( getErrorMessage( contract, true ) + e );
        } catch( Exception e ) {
            log.error( "Caught an exception during changeBankAccount for " + contract, e );
            return createResponse( GENERAL_SYSTEM_ERROR, requestVo );
        }

        return createResponse( resultVo, requestVo );
    }

    @Override
    public CustomerCareServicesResponseVo getBrandConfiguration( GetBrandConfigurationRequestVO requestVo ) {
        GetBrandConfigurationResponseVO responseVo = new GetBrandConfigurationResponseVO();
        Vendor vendor = requestVo.getVendor();

        try {
            responseVo.setDirectDebitRegistration( directDebitService.isDirectDebitRegistrationAvailableForVendor( vendor ) );
            responseVo.setThirdPartyBankAccountOwnerAllowed( directDebitService.isThirdPartyBankAccountAvailableForVendor( vendor ) );
            Optional<Boolean> vendorUseEmailValidation = vendorConfigService.getVendorConfigValueAsBooleanOrDefault( vendor,
                USE_EMAIL_VALIDATION );
            responseVo.setUseEmailValidation( vendorUseEmailValidation.or( false ) );
            boolean onDemandPuk2Enabled = vendorChannelConfigService
                .getValueWithChannelFallbackAndDefaultValueAsBoolean( vendor, requestVo.getChannel(),
                    ON_DEMAND_PUK2_REQUIRED, true );
            responseVo.setOnDemandPuk2Required( onDemandPuk2Enabled );
            Long custAgreementReminderInt = vendorConfigService.getVendorConfigValueAsLongValueOrDefault( vendor,
                CUSTOMER_AGREEMENT_REMINDER_INTERVAL );
            responseVo.setCustomerAgreementReminderIntervalInDays( custAgreementReminderInt );
            responseVo.setMonthlyLimitType( MonthlyLimitResetCycle.fromValue( vendorConfigService
                .getVendorConfigValueAsBooleanOrDefaultOrException( vendor, MONTHLY_LIMIT_PERIOD ) ) );
            responseVo.setSimReplacementVo( getSimReplacementVo( requestVo ) );
            responseVo.setCreditCardRegistrationEnabled( paymentMethodConfigService.isCreditCardRegistrationEnabled( vendor ) );
            responseVo.setThirdPartyBarringEnabled(
                vendorConfigService.getVendorConfigValueAsBooleanOrDefaultOrException( vendor, THIRD_PARTY_BARRINGS_ENABLED ) );
            fillWithSuccessResult( responseVo, requestVo );
        } catch( Exception e ) {
            log.error( "An error occurs getting brand configuration for Vendor " + vendor, e );
            return fillResponse( responseVo, GENERAL_SYSTEM_ERROR, requestVo );
        }

        return responseVo;
    }

    private Optional<BrandConfigurationSimReplacementVo> getSimReplacementVo( GetBrandConfigurationRequestVO requestVo ) {
        Vendor vendor = requestVo.getVendor();
        Channel channel = requestVo.getChannel();

        Optional<MonetaryValue> feeNone = vendorChannelConfigService.getValueAsEuroCentMonetaryValue( vendor, channel,
            SpVendorChannelConfigParameter.SIM_SWAP_FEE_NONE );
        Optional<MonetaryValue> feeTheft = vendorChannelConfigService.getValueAsEuroCentMonetaryValue( vendor, channel,
            SpVendorChannelConfigParameter.SIM_SWAP_FEE_THEFT );
        Optional<MonetaryValue> feeLoss = vendorChannelConfigService.getValueAsEuroCentMonetaryValue( vendor, channel,
            SpVendorChannelConfigParameter.SIM_SWAP_FEE_LOSS );
        Optional<MonetaryValue> feeFormFactor = vendorChannelConfigService.getValueAsEuroCentMonetaryValue( vendor,
            channel, SpVendorChannelConfigParameter.SIM_SWAP_FEE_FORMFACTOR );
        Optional<MonetaryValue> feeDefectFirstPeriod = vendorChannelConfigService.getValueAsEuroCentMonetaryValue(
            vendor, channel, SpVendorChannelConfigParameter.SIM_SWAP_FEE_DEFECT_FIRST_PERIOD );
        Optional<MonetaryValue> feeDefectSecondPeriod = vendorChannelConfigService.getValueAsEuroCentMonetaryValue(
            vendor, channel, SpVendorChannelConfigParameter.SIM_SWAP_FEE_DEFECT_SECOND_PERIOD );
        Optional<Integer> firstPeriodLengthInMonths = vendorChannelConfigService.getValueAsInteger( vendor, channel,
            SpVendorChannelConfigParameter.SIM_SWAP_FEE_DEFECT_FIRST_PERIOD_LENGTH );
        Optional<Integer> showLastSimOrderedWithinXDays = vendorConfigService.getVendorConfigValueAsIntegerOrDefault( vendor,
            SIM_SWAP_WARNING_SHOW_LAST_SIM_ORDERED_WITHIN_X_DAYS );

        Optional<?>[] optionalFields = { feeNone, feeTheft, feeLoss, feeFormFactor, feeDefectSecondPeriod };

        if( !OptionalUtils.anyPresent( optionalFields ) ) {
            return Optional.absent();
        }
        BrandConfigurationSimReplacementVo simReplacement = new BrandConfigurationSimReplacementVo();
        simReplacement.setFeeNone( feeNone );
        simReplacement.setFeeTheft( feeTheft );
        simReplacement.setFeeLoss( feeLoss );
        simReplacement.setFeeFormFactor( feeFormFactor );
        simReplacement.setFeeDefectSecondPeriod( feeDefectSecondPeriod );

        if( feeDefectFirstPeriod.isPresent() && firstPeriodLengthInMonths.isPresent() && firstPeriodLengthInMonths.get() > 0 ) {
            BrandConfigurationSimReplacementGracePeriodVo gracePeriod = new BrandConfigurationSimReplacementGracePeriodVo();
            gracePeriod.setFeeDefectFirstPeriod( feeDefectFirstPeriod.get() );
            gracePeriod.setFirstPeriodLengthInMonths( firstPeriodLengthInMonths.get() );
            simReplacement.setGracePeriod( Optional.of( gracePeriod ) );
        }

        simReplacement.setShowLastSimOrderedWithinXDays( showLastSimOrderedWithinXDays );

        return Optional.of( simReplacement );
    }

    private String getErrorMessage( Contract contract, boolean isTransient ) {
        if( isTransient ) {
            return "Customer " + contract + " is transiently out-of-sync. Treating request as successful as retry handling will happen " +
                    "asynchronously: ";
        } else {
            return "Processing failed as customer is permanently out-of-sync for " + contract + "; Accepting changes but returning error.";
        }
    }

    @Override
    public CustomerCareServicesResponseVo searchTenantBrandAssignment( SearchTenantBrandAssignmentRequestVO requestVo ) {
        SearchTenantBrandAssignmentResponseVO responseVo = new SearchTenantBrandAssignmentResponseVO();
        try {
            List<TenantBrandAssignmentElementVO> tenantBrandListVo = searchTenantBrandAssignment( requestVo.getMsisdn(),
                requestVo.getTenantIdList() );
            responseVo.setTenantBrandAssignmentElement( tenantBrandListVo );
            fillWithSuccessResult( responseVo, requestVo );
            return responseVo;
        } catch( MsisdnNotExistentException e ) {
            responseVo.setTenantBrandAssignmentElement( Collections.<TenantBrandAssignmentElementVO>emptyList() );
            log.error( "Msisdn " + requestVo.getMsisdn() + " not found in the system.", e );
            return fillResponse( responseVo, MSISDN_DOES_NOT_EXIST_IN_THE_SYSTEM, requestVo );
        } catch( Exception e ) {
            responseVo.setTenantBrandAssignmentElement( Collections.<TenantBrandAssignmentElementVO>emptyList() );
            log.error( "An error occurs searching for MSISDN " + requestVo.getMsisdn(), e );
            return fillResponse( responseVo, GENERAL_SYSTEM_ERROR, requestVo );
        }
    }

    @Override
    public CustomerCareServicesResponseVo activateContract( ActivateContractRequestVO requestVO ) {
        return activateContractRequestProcessor.process( requestVO );
    }

    @Override
    public CustomerCareServicesResponseVo activateReplacementSim( ActivateReplacementSimRequestVo requestVo ) {
        return activateReplacementSimRequestProcessor.process( requestVo );
    }

    private List<TenantBrandAssignmentElementVO> searchTenantBrandAssignment( String msisdn, List<Integer> tenantIdList )
            throws MsisdnNotExistentException, ApplicationException {

        if( ListUtils.isNullOrEmpty( tenantIdList ) ) {
            throw new MsisdnNotExistentException( "Tenant list is null or empty." );
        }

        ImmutableList<ContractIdMsisdnStatusVo> contracts = BasicContractUtilFactory.getBasicContractUtil( daos )
            .getContractMsisdnStatusFromMsisdn( msisdn );
        if( ListUtils.isNullOrEmpty( contracts ) ) {
            throw new MsisdnNotExistentException( "Msisdn " + msisdn + " not found in the system" );
        }

        List<TenantBrandAssignmentElementVO> tenantBrandAssignmentList = newArrayList();
        for( ContractIdMsisdnStatusVo contract : contracts ) {
            Vendor vendor = contract.getContract().getVendor();
            if( tenantIdList.contains( vendor.getTenantId() ) ) {
                addTenantBrandAssignmentToList( tenantBrandAssignmentList, vendor, contract.getContractMsisdnStatus() );
            }
        }
        if( ListUtils.isNullOrEmpty( tenantBrandAssignmentList ) ) {
            throw new MsisdnNotExistentException( "Msisdn " + msisdn + " not found in the system for tenants " + tenantIdList );
        }
        return tenantBrandAssignmentList;
    }

    private void addTenantBrandAssignmentToList( List<TenantBrandAssignmentElementVO> tenantBrandAssignmentList, Vendor vendor,
            ContractMsisdnStatus status ) {
        TenantBrandAssignmentElementVO tenantBrandAssignmentVO = new TenantBrandAssignmentElementVO();
        tenantBrandAssignmentVO.setBrandID( vendor.getBrandId() );
        tenantBrandAssignmentVO.setTenantID( vendor.getTenantId() );
        tenantBrandAssignmentVO.setContractMsisdnStatus( status );
        tenantBrandAssignmentList.add( tenantBrandAssignmentVO );
    }

    @Override
    public CustomerCareServicesResponseVo confirmSepaMandate( ConfirmSepaMandateRequestVo requestVo ) {
        try {
            ResultVO resultVo = CustomerCareValidatorUtils
                .checkMsisdnAndVendor( requestVo.getVersionInfo() )
                .next( checkClientIsKnownAsGeneralSystemError() )
                .validate( requestVo );
            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVo, resultVo );
            }
            directDebitService.confirmSepaMandateInActivationPortal( requestVo.getContract(),
                SepaMandateId.from( requestVo.getSepaMandateId() ) );
            return new CustomerCareServicesResponseVo( requestVo, CustomerCareResultCode.REQUEST_SUCCESSFUL );
        } catch( WrongDirectDebitStateException e ) {
            log.error( "Operation not possible because of invalid Direct Debit State for " + requestVo.getContract(), e );
            return createResponse( NO_PENDING_SEPA_MANDATE_FOUND, requestVo );
        } catch( SepaMandateException e ) {
            log.error( "Sepa mandate " + requestVo.getSepaMandateId() + " not found", e );
            return createResponse( NO_PENDING_SEPA_MANDATE_FOUND, requestVo );
        } catch( Exception e ) {
            log.error(
                "An error occurred while confirming Sepa mandate " + requestVo.getSepaMandateId() + " for " + requestVo.getContract() + ".",
                e );
            return createResponseFromException( e, requestVo );
        }
    }

    @Override
    public CustomerCareServicesResponseVo deregisterPaymentMethod( DeregisterPaymentMethodRequestVo requestVo ) {
        log.info( "DeregisterPaymentMethod was called for contract " + requestVo.getContract()
                + " and reference ID " + requestVo.getReferenceId() );
        return createResponse( REQUEST_SUCCESSFUL, requestVo );
    }

    @Override
    public CustomerCareServicesResponseVo resetRegistrationData( ResetRegistrationDataRequestVo requestVo ) {
        Contract contract = requestVo.getContract();
        Channel channel = requestVo.getChannel();
        String agent = requestVo.getAgent();
        ResultVO resultVo = CustomerCareValidatorUtils.checkMsisdnAndVendor( requestVo.getVersionInfo() ).validate( requestVo );
        if( resultVo.isFailure() ) {
            return createResponse( resultVo, requestVo );
        }

        try {
            registrationResetService.resetRegistration( contract, channel, agent, Optional.<String>absent() );
        } catch( RegistrationResetException rre ) { // NOSONAR
            RegistrationResetErrorType resetErrorType = rre.getErrorType();
            CustomerCareResultCode resultCode = toResultCode( resetErrorType );
            Log.error( log, "Reset registration data failed for contract ", contract, " because ", resultCode.getDocumentation(),
                ", error type: ", resetErrorType );
            return createResponse( resultCode, requestVo );
        } catch( Exception e ) {
            log.error( "Reset registration data failed for contract " + contract, e );
            return createResponse( GENERAL_SYSTEM_ERROR, requestVo );
        }
        return new CustomerCareServicesResponseVo( requestVo, CustomerCareResultCode.REQUEST_SUCCESSFUL );
    }

    private CustomerCareResultCode toResultCode( RegistrationResetErrorType resetErrorType ) {
        CustomerCareResultCode resultCode = GENERAL_SYSTEM_ERROR;
        if( resetErrorType == null ) {
            return resultCode;
        }
        switch( resetErrorType ) {
            case WRONG_CONTRACT_STATUS:
            case NO_EXTERNAL_IDENTITY_ID_FOUND:
                resultCode = INVALID_LIFECYCLE_STATE;
                break;
            case IDM_PERMISSION_REJECTED:
                resultCode = OPERATION_REJECTED_BY_CUSTOMER_CHECKING;
                break;
            case IN_RESET_SUPPRESSION_PERIOD:
                resultCode = USE_CASE_NOT_ALLOWED_FOR_CUSTOMER;
                break;
            default:
                resultCode = GENERAL_SYSTEM_ERROR;
                break;
        }
        return resultCode;
    }

    @Override
    public CustomerCareServicesResponseVo notifyAboutSuccessfulReverification( NotifyAboutSuccessfulReverificationRequestVo requestVo ) {
        ResultVO resultVo = CustomerCareValidatorUtils.checkMsisdnAndVendor( requestVo.getVersionInfo() )
            .validate( requestVo );
        if( resultVo.isFailure() ) {
            return createResponse( resultVo, requestVo );
        }
        try {
            idvFraudManagementService.startFullReverificationWorkflow( requestVo.getContract(), requestVo.getIdVerificationDataVo(),
                requestVo.getAgent() );
        } catch( ContractNotActiveException e ) {
            log.warn( "Reverification workflow not started for contract " + requestVo.getContract(), e );
            return createResponse( CUSTOMER_IS_NOT_ACTIVE, requestVo );
        } catch( NoAssociatedIdentityException e ) {
            log.warn( "Reverification workflow not started for contract " + requestVo.getContract(), e );
            return createResponse( IDENTITY_DATA_NOT_PRESENT, "Identity data could not be found in the system", requestVo );
        } catch( WrongIdvFraudStatusException e ) {
            log.warn( "Reverification workflow not started for contract " + requestVo.getContract(), e );
            return createResponse( CURRENT_IDV_FRAUD_STATUS_PROHIBITS_OPERATION, requestVo );
        } catch( WrongIdvStatusException e ) {
            log.warn( "Reverification workflow not started for contract " + requestVo.getContract(), e );
            return createResponse( CURRENT_IDV_STATUS_PROHIBITS_OPERATION, requestVo );
        } catch( WorkflowLockNotAcquiredException e ) {
            log.warn( "Reverification workflow not started for contract " + requestVo.getContract(), e );
            return createResponse( GENERAL_SYSTEM_ERROR, "A request to unbar the customer after reverification is already running",
                requestVo );
        }
        return createResponse( REQUEST_SUCCESSFUL, requestVo );
    }

    @Override
    public CustomerCareServicesResponseVo verifyAvailability( CustomerCareServicesRequestVo requestVo ) {
        CustomerCareServicesResponseWithAvailabilityVo response = new CustomerCareServicesResponseWithAvailabilityVo();
        CustomerCareVersion requestVersion = requestVo.getVersionInfo();
        response.setAvailable( !isPreviousVersion( requestVersion ) || isPreviousCustomerCareVersionActive() );
        fillWithSuccessResult( response, requestVo );
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo modifyRegistrationData( ModifyRegistrationDataRequestVo requestVo ) {
        return new RequestProcessor<ModifyRegistrationDataRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                ResultVO resultVo = CustomerCareValidatorUtils
                    .checkMsisdnAndVendor( requestVo.getVersionInfo() )
                    .next( checkClientIsKnown() )
                    .next( checkSalutationIsValid() )
                    .validate( requestVo );

                Contract contract = requestVo.getContract();
                if( resultVo.isFailure() ) {
                    CustomerCareServicesResponseVo response = createResponse( resultVo, requestVo );
                    response.setContract( contract );
                    responseVo = response;
                    return;
                }

                try {
                    identityPersonalDataService.verifyContractStatusAndModifyPersonalData( contract,
                        idRegistrationDataVoConverter.fromCustomerCareRequest( requestVo ), requestVo.getAgent() );
                } catch( PersonalDataModificationException e ) {
                    log.error( "Modify personal data for " + contract + " failed.", e );
                    switch( e.getErrorCode() ) {
                        case WRONG_CONTRACT_STATUS:
                            responseVo = createResponse( INVALID_LIFECYCLE_STATE, requestVo );
                            break;
                        case IDVS_MODIFICATION_NOT_ALLOWED:
                            responseVo = createResponse( OPERATION_REJECTED_BY_CUSTOMER_CHECKING, requestVo );
                            break;
                        default:
                            log.warn( "The error code " + e.getErrorCode() + " is not mapped to the CustomerCare error code" );
                            responseVo = createResponse( UNMAPPED_ERROR, requestVo );
                    }
                    return;
                } catch( Exception e ) {
                    log.error( "Modify personal data for " + contract + " failed due to an exception.", e );
                    responseVo = createResponseFromException( e, requestVo );
                    return;
                }
                responseVo = createResponse( REQUEST_SUCCESSFUL, requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getCustomerDataForDataPortability( GetCustomerDataForDataPortabilityRequestVo requestVo ) {
        return new RequestProcessor<GetCustomerDataForDataPortabilityRequestVo, CustomerCareServicesResponseVo>( requestVo ) {
            @Override
            public void call() {
                responseVo = beanUtils.getCustomerDataForDataPortability( requestVo );
            }
        }.processRequest();
    }

    @Override
    public CustomerCareServicesResponseVo getPreContractualInformation( GetPreContractualInformationRequestVo requestVo ) {
        GetPreContractualInformationResultVo response = new GetPreContractualInformationResultVo();
        try {
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkProductIdNotNull( PRODUCT_DOES_NOT_EXIST, PARAM_PRODUCTID ) )
                .validate( requestVo );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVo, resultVo );
            }

            populateWithSuccessResultAndContractData( requestVo, response );
        } catch( Exception e ) {
            response = fillErrorResponseWithCommonValuesAndContractData( requestVo,
                GENERAL_SYSTEM_ERROR, new GetPreContractualInformationResultVo() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo getKittedProducts( GetKittedProductsRequestVo requestVo ) {
        GetKittedProductsResultVo response = new GetKittedProductsResultVo();
        try {
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull( WRONG_OR_MISSING_MANDATORY_PARAMETERS, PARAM_MSISDN ) )
                .next( checkContractOrIccIdNotNull() )
                .next( checkCustomerActive( CUSTOMER_IS_NOT_ACTIVE ) )
                .next( checkContractNotNull() )
                .next( checkIccid( ICCID_DOES_NOT_EXIST_IN_THE_SYSTEM ) )
                .next( checkBrandIdMatchesCustomersVendor() )
                .next( checkKittedProduct( NO_KITTED_PRODUCTS_FOUND ) )
                .validate( requestVo );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVo, resultVo );
            }

            populateWithSuccessResultAndContractData( requestVo, response );
        } catch( Exception e ) {
            response = fillErrorResponseWithCommonValuesAndContractData( requestVo,
                GENERAL_SYSTEM_ERROR, new GetKittedProductsResultVo() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo getNonEECCRelevantProductsForBrand( GetNonEECCRelevantProductsForBrandRequestVo requestVo ) {
        GetNonEECCRelevantProductsForBrandResultVo response = new GetNonEECCRelevantProductsForBrandResultVo();
        try {
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkBrandIdMatchesCustomersVendor() )
                .validate( requestVo );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVo, resultVo );
            }

            populateWithSuccessResultAndContractData( requestVo, response );
        } catch( Exception e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVo,
                GENERAL_SYSTEM_ERROR, new GetNonEECCRelevantProductsForBrandResultVo() );
        }
        return response;
    }

    @Override
    public CustomerCareServicesResponseVo requestEmailAddressPerSms( RequestEmailAddressPerSmsRequestVo requestVo ) {
        RequestEmailAddressPerSmsResultVo response = new RequestEmailAddressPerSmsResultVo();
        try {
            ResultVO resultVo = CustomerCareValidatorUtils.forType( CustomerCareServicesRequestVo.class )
                .next( checkContractNotNull() )
                .next( checkCustomerActive( MSISDN_NOT_ACTIVE ) )
                .next( checkBrandIdMatchesCustomersVendor() )
                .validate( requestVo );

            if( resultVo.isFailure() ) {
                return createErrorResponseAndFillCommonValuesAndContractData( requestVo, resultVo );
            }

            populateWithSuccessResultAndContractData( requestVo, response );
        } catch( Exception e ) { // NOSONAR
            response = fillErrorResponseWithCommonValuesAndContractData( requestVo,
                GENERAL_SYSTEM_ERROR, new RequestEmailAddressPerSmsResultVo() );
        }
        return response;
    }

}